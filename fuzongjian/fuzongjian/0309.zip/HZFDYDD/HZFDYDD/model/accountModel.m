//
//  accountModel.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/30.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "accountModel.h"

@implementation accountModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
   
    if ([key isEqualToString:@"id"]) {
        self.Id = value;
    }else{
         NSLog(@"个人金额没有找到的key---%@",key);
    }
}
@end

//
//  ableModel.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ableModel.h"

@implementation ableModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.Nid = value;
    }else if([key isEqualToString:@"description"]){
        self.Description = value;
    }else{
        NSLog(@"没有找到的key---%@",key);
    }
}

@end

//
//  messageModel.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/12.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "messageModel.h"

@implementation messageModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.Mid = value;
    }else{
        NSLog(@"没有找到的key----%@",key);
    }
}

@end

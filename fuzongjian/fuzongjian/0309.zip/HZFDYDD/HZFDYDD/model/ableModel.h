//
//  ableModel.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ableModel : NSObject
@property(nonatomic, copy) NSString * Description; //描述
@property(nonatomic, strong) NSNumber * hospitalId;//医院id
@property(nonatomic, copy) NSString * serviceDel;//服务人员是否删除
@property(nonatomic, copy) NSString * replyTime;//订单被接时间
@property(nonatomic, copy) NSString * payTime;//付款时间
@property(nonatomic, strong) NSNumber * status;//状态
@property(nonatomic, copy) NSString * money;//金额
@property(nonatomic, copy) NSString * duration;//持续时间
@property(nonatomic, copy) NSString * patientName;//患者名字
@property(nonatomic, copy) NSString * userRating;//用户评价id
@property(nonatomic, copy) NSString * userId;//用户id
@property(nonatomic, copy) NSString * endtime;//结束时间
@property(nonatomic, copy) NSString * serviceRating;//服务评鉴id
@property(nonatomic, copy) NSString * creationTime;//创建时间
@property(nonatomic, copy) NSString * endType;//结束原因
@property(nonatomic, strong) NSNumber * Nid;//订单id
@property(nonatomic, copy) NSString * serviceUser;//服务人员id
@property(nonatomic, copy) NSString * contactsName;//联系人
@property(nonatomic, copy) NSString * contactsPhone;//联系人方式
@property(nonatomic, copy) NSString * serviceType;//服务类型id  1 VIP 2 普通  3 专业
@property(nonatomic, copy) NSString * userDel;//用户是否删除
@property(nonatomic, copy) NSString * healthRecord;//健康档案
@property(nonatomic, copy) NSString * serviceContent;//服务内容
@property(nonatomic, copy) NSString * startTime;//开始时间
@property(nonatomic, copy) NSString * orderLevel;//订单等级  0
@property(nonatomic, copy) NSString * hospitalName;//医院名字

@property(nonatomic,copy)NSString * serviceTypeName;//服务类型
@property(nonatomic,copy)NSString * green;
@property(nonatomic,copy)NSString * red;
@property(nonatomic,copy)NSString * blue;


@property(nonatomic,copy) NSString *shuttle;//是否接送
@property(nonatomic,copy) NSString *shuttlePlace;//接送地点
@property(nonatomic,copy) NSString *complaintId;//投诉lID
@property(nonatomic,copy) NSString *shuttleDetail;//接送详情

@property(nonatomic,copy) NSString *sericon;//是否接送
@property(nonatomic,copy) NSString *serphone;//接送地点
@property(nonatomic,copy) NSString *city;//投诉lID
@property(nonatomic,copy) NSString *cityId;//接送详情
@property(nonatomic,copy) NSString *sername;//接送详情

//[ableModel.m:19行] 没有找到的key---shuttle
//[ableModel.m:19行] 没有找到的key---shuttlePlace
//[ableModel.m:19行] 没有找到的key---complaintId
//[ableModel.m:19行] 没有找到的key---shuttleDetail



//Description,hospital,serviceDel,replyTime,payTime,status,money,duration,patientName,userRating,userId,endtime,serviceRating,creationTime,endType,Id,serviceUser,contactsName,contactsPhone,serviceType,userDel,healthRecord,serviceContent,startTime,orderLevel,

@end

//
//  accountModel.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/30.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface accountModel : NSObject

@property(nonatomic, copy) NSString * firstDay; //月初日期
@property(nonatomic, copy) NSString * lastDay;//月末日期
@property(nonatomic, strong) NSString * serviceTime;//服务时长
@property(nonatomic, copy) NSString * allmoney;//总收入
@property(nonatomic, copy) NSString * charge;//代缴费
@property(nonatomic, strong) NSNumber * realEarn;//实际收入
@property(nonatomic,copy)NSString * Id;
@end

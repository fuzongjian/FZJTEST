//
//  messageModel.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/12.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface messageModel : NSObject
@property(nonatomic,strong)NSString * content;
@property(nonatomic,strong)NSString * createTime;
@property(nonatomic,strong)NSString * Mid;

@property(nonatomic,strong)NSString * title;
@property(nonatomic,strong)NSString * userId;
@property(nonatomic,strong)NSString * userType;

@end

//
//  chooseModel.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/26.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>
@class PHAsset;
@interface chooseModel : NSObject
@property(nonatomic,strong)PHAsset * asset;
@property(nonatomic,assign)BOOL selected;

@property(nonatomic,strong)NSString * imageName;
@property(nonatomic,strong)UIImage * image;

@end

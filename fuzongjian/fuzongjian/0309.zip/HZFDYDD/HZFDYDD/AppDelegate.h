//
//  AppDelegate.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/10.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  NSString+Extension.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/24.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)
+(BOOL)stringContainsEmoji:(NSString *)string;
@end

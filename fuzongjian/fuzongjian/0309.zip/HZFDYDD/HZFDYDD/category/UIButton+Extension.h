//
//  UIButton+Extension.h
//  testButton
//
//  Created by fdkj0002 on 16/1/18.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>



@interface UIButton (Extension)

/**
 *  标题、颜色、字体大小、
 */
@property(nonatomic,strong) NSString * buttonTitle;
@property(nonatomic,strong) UIColor * titleColor;
@property(nonatomic,assign) CGFloat titleFont;

-(void)setTitleSystemFont:(CGFloat)font;
-(void)setTitleBlodFont:(CGFloat)font;
/**
 *  点击事件的block
 */
@property(assign) void(^clickAction)(void);
/**
 *  创建Button
 *
 *  @return Button
 */
/**
 *  系统样式
 */
+(instancetype)createSystemButton;
+(instancetype)createSystemButtonTitle:(NSString *)title;
/**
 *  自定义样式
 */
+(instancetype)createCustomButton;
+(instancetype)createCustomButtonTitle:(NSString *)title;
+(instancetype)createCustomButtonImage:(UIImage *)image;

/**
 *  设置背景图片及状态    图片
 */
-(void)setHighLightedImage:(UIImage *)HighLightedImage;
-(void)setNormalImage:(UIImage *)NormalImage;
-(void)setSelectedImage:(UIImage *)SelectedImage;
-(void)setDisabledImage:(UIImage *)DisabledImage;
/**
 *  设置背景图片及状态    图片名字
 */
-(void)setHighLightedImageName:(NSString *)HighLightedImageName;
-(void)setNormalImageName:(NSString *)NormalImageName;
-(void)setSelectedImageName:(NSString *)SelectedImageName;
-(void)setDisabledImageName:(NSString *)DisabledImageName;

/**
 *  重新条用点击事件
 */
-(void)clickEvent;

-(void)setBorderWidth:(CGFloat)width andBoredColorR:(CGFloat)r G:(CGFloat)g B:(CGFloat)b;


@end

//
//  UIButton+Extension.m
//  testButton
//
//  Created by fdkj0002 on 16/1/18.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UIButton+Extension.h"

static char actionChar;

@implementation UIButton (Extension)

@dynamic buttonTitle;
@dynamic clickAction;
@dynamic titleColor;
@dynamic titleFont;
/**
 *  系统样式
 */
+(instancetype)createSystemButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeSystem];
    return button;
}
+(instancetype)createSystemButtonTitle:(NSString *)title{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.buttonTitle = title;
    return button;
}

/**
 *  自定义样式
 */
+(instancetype)createCustomButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    return button;
}
+(instancetype)createCustomButtonTitle:(NSString *)title{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.buttonTitle = title;
    return button;
}
+(instancetype)createCustomButtonImage:(UIImage *)image{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setNormalImage:image];
    return button;
}

/**
 *  字体
 */
-(void)setTitleSystemFont:(CGFloat)font{
    self.titleLabel.font = [UIFont systemFontOfSize:font];
}
-(void)setTitleBlodFont:(CGFloat)font{
    self.titleLabel.font = [UIFont boldSystemFontOfSize:font];
}
-(CGFloat)titleFont{
    return self.titleLabel.font.pointSize;
}
-(void)setTitleFont:(CGFloat)titleFont{
    self.titleLabel.font = [UIFont systemFontOfSize:titleFont];
}
/**
 *  标题
 */
-(NSString *)buttonTitle{
    NSString * title = self.titleLabel.text;
    return title;
}
-(void)setButtonTitle:(NSString *)buttonTitle{
    [self setTitle:buttonTitle forState:UIControlStateNormal];
}
/**
 *  标题颜色
 */
-(UIColor *)titleColor{
    UIColor * color = self.titleLabel.textColor;
    return color;
}
-(void)setTitleColor:(UIColor *)titleColor{
    [self setTitleColor:titleColor forState:UIControlStateNormal];
}
/**
 *  设置背景图片  图片
 */
-(void)setHighLightedImage:(UIImage *)HighLightedImage{
    [self setBackgroundImage:HighLightedImage forState:UIControlStateHighlighted];
}
-(void)setNormalImage:(UIImage *)NormalImage{
    [self setBackgroundImage:NormalImage forState:UIControlStateNormal];
}
-(void)setSelectedImage:(UIImage *)SelectedImage{
    [self setBackgroundImage:SelectedImage forState:UIControlStateSelected];
}
-(void)setDisabledImage:(UIImage *)DisabledImage{
    [self setBackgroundImage:DisabledImage forState:UIControlStateDisabled];
}
/**
 *  设置背景图片  图片名字
 */
-(void)setHighLightedImageName:(NSString *)HighLightedImageName{
    [self setBackgroundImage:[UIImage imageNamed:HighLightedImageName] forState:UIControlStateHighlighted];
}
-(void)setNormalImageName:(NSString *)NormalImageName{
    [self setBackgroundImage:[UIImage imageNamed:NormalImageName] forState:UIControlStateNormal];
}
-(void)setSelectedImageName:(NSString *)SelectedImageName{
    [self setBackgroundImage:[UIImage imageNamed:SelectedImageName] forState:UIControlStateSelected];
}
-(void)setDisabledImageName:(NSString *)DisabledImageName{
    [self setBackgroundImage:[UIImage imageNamed:DisabledImageName] forState:UIControlStateDisabled];
}
/**
 *
 *
 *  @param object#> <#object#> description#>  被关联的对象
 *  @param key#>    <#key#> description#> 要关联的对象的键值，一般设置为静态的，用于获取关联对象的值
 *  @param value#>  <#value#> description#>要传得值，一般是静态变量
 *  @param policy#> <#policy#> description#>
 *
 *  @return 关联时采用的协议，有assign，retain，copy等协议 点击进去选取枚举
 */
//objc_setAssociatedObject(<#id object#>, <#const void *key#>, <#id value#>, <#objc_AssociationPolicy policy#>)
-(void(^)(void))clickAction{
    void(^action)(void) = objc_getAssociatedObject(self, &actionChar);
    if (!action) {
        action = nil;
        objc_setAssociatedObject(self, &actionChar, action, OBJC_ASSOCIATION_COPY_NONATOMIC);
    }
    return action;
}
-(void)setClickAction:(void (^)(void))clickAction{
    
    [self addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    //将clickAction与self绑定
    objc_setAssociatedObject(self, &actionChar, clickAction, OBJC_ASSOCIATION_COPY_NONATOMIC);
}
-(void)btnClick{
    if (self.clickAction) {
        self.clickAction();
    }
}
-(void)clickEvent{
    if (self.clickAction) {
        self.clickAction();
    }
}
-(void)setBorderWidth:(CGFloat)width andBoredColorR:(CGFloat)r G:(CGFloat)g B:(CGFloat)b{
    [self.layer setBorderWidth:width];
    CGColorSpaceRef spaceColor = CGColorSpaceCreateDeviceRGB();
    CGColorRef refColor = CGColorCreate(spaceColor, (CGFloat[]){1,r/255.0f,g/255.0f,b/255.0f});
    [self.layer setBorderColor:refColor];
    CGColorRelease(refColor);
}
@end

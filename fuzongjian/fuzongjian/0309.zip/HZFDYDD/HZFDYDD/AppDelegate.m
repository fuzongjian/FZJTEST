//
//  AppDelegate.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/10.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "AppDelegate.h"
#import "XGPush.h"

#import "SDImageCache.h"

#import "UMCheckUpdate.h"
#import "Reachability.h"

#import "GifViewViewController.h"
#import "homeTabBarController.h"
#import "leftViewController.h"

#import <BaiduMapAPI_Map/BMKMapComponent.h>

@interface AppDelegate ()<BMKGeneralDelegate,UIAlertViewDelegate>
@property(nonatomic,strong)BMKMapManager * mapManager;
/**
 *  更新的路径
 */
@property(nonatomic,strong)NSString * uploadPath;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
   
    
//    //设置根视图
//    DrawerViewController * drawer = [[DrawerViewController alloc]initWithRootViewController:[[homeTabBarController alloc]init] andLeftViewController:[[leftViewController alloc]init] andRightViewController:nil];
    
    GifViewViewController *controller = [[GifViewViewController alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
    
   
    self.window.rootViewController = nav;
    
    //百度地图
    _mapManager = [[BMKMapManager alloc]init];
    BOOL ret = [_mapManager start:MAPKEY generalDelegate:self];
    if (ret) {
        NSLog(@"百度地图初始化成功"); 
    }
    /**
     *  友盟自动更新
     */
    [self UmengUpdate];
/********************/

    
/********************/
    
    /**
     *  推送
     */    
    if (IOSVERSION >= 8.0)
    {
        [self registerPushForIOS8];
    }
    else
    {
        [self registerNofitication];
    }
    
    
    [self registerInternetStateNotificationCenter];
    
    
    
    return YES;
    
    
}

-(void)UmengUpdate{
//    [UMCheckUpdate checkUpdateWithAppkey:UPDATEKEY channel:nil];
//    [UMCheckUpdate checkUpdate:@"新版本--" cancelButtonTitle:nil otherButtonTitles:@"确定" appkey:UPDATEKEY channel:nil];
    
    NSDictionary * dic = [[NSBundle mainBundle] infoDictionary];
    NSLog(@"--------%@",[dic objectForKey:@"CFBundleVersion"]);
   
    
    [UMCheckUpdate checkUpdateWithDelegate:self selector:@selector(recivedUmengCheckData:) appkey:UPDATEKEY channel:nil];
    
    
    
}
-(void)recivedUmengCheckData:(NSDictionary *)checkDic{
    NSLog(@"---%@--%@",checkDic,[checkDic objectForKey:@"update_log"]);
    if ([[checkDic objectForKey:@"path"] length]) {
        self.uploadPath = [checkDic objectForKey:@"path"];
    }
    float nowVersion = [[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"] floatValue];//获取build版本号
    if (nowVersion != [[checkDic objectForKey:@"version"] floatValue]) {
        [self uploadNewVersion:checkDic];
    }
}
-(void)uploadNewVersion:(NSDictionary *)dic{
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:[dic objectForKey:@"update_log"] message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alertView show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.uploadPath]];
    }
}
/*******************推送*******************/

- (void) registerNofitication {
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound)];
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}

- (void)registerPushForIOS8{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= _IPHONE80_
    
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
#endif
}

#ifdef __IPHONE_8_0
//ios8需要调用内容
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"]){
        NSLog(@"fuzongjian");
    }
    else if ([identifier isEqualToString:@"answerAction"]){
        NSLog(@"fuzongyang");
    }
    NSLog(@"---%@",userInfo);
    
}

#endif

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    NSLog(@"My token is: %@", deviceToken);
    
    NSString *strToken = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    strToken = [strToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    
//    [NSUserDefaults :@"Token" Value:strToken];
    
     NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
    [userInfo setObject:strToken forKey:@"token"];
    

}



-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"注册推送服务时，发生以下错误： %@",error);
}

/*******************推送*******************/



- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application{
    
    NSLog(@"收到内存警告了");
    
    [[SDImageCache sharedImageCache] clearDisk];
    
    [[SDImageCache sharedImageCache] clearMemory];
}




- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    
    [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:ENTERBACKGROUND];
    
    NSLog(@"进入后台了呀");
    
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    //取消徽章
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

/**
 *  判断网络的通知
 */
-(void)registerInternetStateNotificationCenter{
    Reachability * reach = [Reachability reachabilityWithHostname:@"www.baidu.com"];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    [reach startNotifier];
}
-(void)reachabilityChanged:(NSNotification *)notify{
    Reachability * reach = [notify object];
    StateManager * manager = [StateManager defaultManager];
    if (![reach isReachable]) {
        manager.reachState = 0;
    }else if(reach.isReachableViaWiFi){
        manager.reachState = 1;
    }else{
        manager.reachState = 2;
    }
}
-(void)dealloc{
        [[NSNotificationCenter defaultCenter]removeObserver:self name:kReachabilityChangedNotification object:nil];
}
@end

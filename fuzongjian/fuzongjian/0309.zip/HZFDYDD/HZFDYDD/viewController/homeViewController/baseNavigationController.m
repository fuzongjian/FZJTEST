//
//  baseNavigationController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "baseNavigationController.h"

@interface baseNavigationController ()

@end

@implementation baseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configBaseNavigationControllerUI];
}

-(void)configBaseNavigationControllerUI{
    
    [self.navigationController.navigationBar setBackgroundColor:RGBCOLOR(240, 240, 240)];

}

//设置标题

-(void)setCustomTitle:(NSString *)title{
    
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 50)];
    label.text = title;
    label.textColor = [UIColor redColor];
    label.font = [UIFont systemFontOfSize:20];
    self.navigationItem.titleView = label;
}

//头像点击事件
-(void)iconBtnClicked:(UIBarButtonItem *)btn{
    
    NSLog(@"头像点击事件");
}
//下班点击事件
-(void)rightBtnClicked{
    
    NSLog(@"下班点击事件");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  homeTabBarController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "homeTabBarController.h"
#import "baseNavigationController.h"
#import "ableViewController.h"
#import "historyViewController.h"
#import "ongoingViewController.h"


#import "leftViewController.h"
#import "protocolViewController.h"

@interface homeTabBarController ()<UITextFieldDelegate>
@property(nonatomic,strong)UIView * bigView;
@property(nonatomic,strong)UITextField * numberField;
@property(nonatomic,strong)UITextField * testField;

@property(nonatomic,strong)NSTimer * timer;
@property(nonatomic,strong)UIButton * registerBtn;//登陆按钮
@property(nonatomic,strong)UIButton * getCode;//获取验证码按钮

@property(nonatomic,assign)NSInteger  secondCount;//计时

@property(nonatomic,strong)StateManager * stateManager;//单例共享数据
@end

@implementation homeTabBarController

@synthesize drawer;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _stateManager = [StateManager defaultManager];
    
    [self configHomeTabBarControllerUI];
    [self registerNotificationCenter];
    [self configStartLoginView];
    [self startConfigOrLoginView];
    
    
}
#pragma mark--每次进入app都要判断上次是否退出
-(void)startConfigOrLoginView{
    
    NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
    
    NSLog(@"--进入app判断--%d",[[userInfo objectForKey:LOGINSTATE] intValue] );
    

    if (![[userInfo objectForKey:LOGINSTATE] intValue]) {
        
        _bigView.alpha = 1.0;
        _numberField.text = [userInfo objectForKey:PHONE];
        
    }else{

        _bigView.alpha = 0.0;
    }
     _stateManager.userId = [userInfo objectForKey:@"user"];
     _stateManager.userNumber = [userInfo objectForKey:PHONE];
}
#pragma mark--登陆界面
-(void)configStartLoginView{
    
    _bigView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    _bigView.backgroundColor = RGBCOLOR(255, 255, 255);
//     [[UIApplication sharedApplication].keyWindow addSubview:_bigView];
    [self.view addSubview:_bigView];
    
    // _bigView添加点击手势
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture)];
    [_bigView addGestureRecognizer:tap];
    tap.numberOfTapsRequired = 1;
    
    //手机号
    
    UIView * numberView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(70), SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40))];
    numberView.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    numberView.layer.masksToBounds = YES;
    numberView.backgroundColor = RGBCOLOR(244, 244, 244);
    [_bigView addSubview:numberView];
    
    //电话图标
    UIImageView * phone = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(20))];
    phone.image = [UIImage imageNamed:@"phone"];
    [numberView addSubview:phone];
    
    _numberField = [[UITextField alloc]initWithFrame:CGRectMake(phone.origin.x + phone.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), numberView.size.width - phone.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(30))];
    _numberField.placeholder = @"请输入手机号";
    _numberField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    _numberField.keyboardType = UIKeyboardTypePhonePad;
    _numberField.delegate = self;
    [numberView addSubview:_numberField];
    
    
    //验证码
    UIView * lockerView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), numberView.origin.y + numberView.size.height + FIXWIDTHORHEIGHT(10), SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40))];
    lockerView.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    lockerView.layer.masksToBounds = YES;
    lockerView.backgroundColor = RGBCOLOR(244, 244, 244);
    [_bigView addSubview:lockerView];
    
    //锁的图标
    UIImageView * lock = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(20))];
    lock.image = [UIImage imageNamed:@"locker"];
    [lockerView addSubview:lock];
    
    _testField = [[UITextField alloc]initWithFrame:CGRectMake(lock.origin.x + lock.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), lockerView.size.width - lock.size.width - FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(30))];
    _testField.placeholder = @"请输入验证码";
    _testField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    _testField.keyboardType = UIKeyboardTypePhonePad;
    _testField.delegate = self;
    [lockerView addSubview:_testField];
    
    
    //获取验证码按钮
    UIButton * getCode = [UIButton buttonWithType:UIButtonTypeCustom];
    getCode.frame = CGRectMake(_testField.origin.x + _testField.size.width + FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(3), lockerView.size.width - (_testField.origin.x + _testField.size.width + FIXWIDTHORHEIGHT(2)), FIXWIDTHORHEIGHT(34));
    [getCode setTitle:@"获取验证码" forState:UIControlStateNormal];
    [getCode setTitleColor:RGBCOLOR(230, 142, 144) forState:UIControlStateNormal];
    getCode.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12)];
    [lockerView addSubview:getCode];
    getCode.layer.cornerRadius = 17;
    getCode.layer.masksToBounds = YES;
    _getCode = getCode;
    [getCode addTarget:self action:@selector(getCodeBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    //设置按钮边角红线
//    [getCode.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//    CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){0.8,0,0,0.8});
//    [getCode.layer setBorderColor:color];
    [getCode setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255.0 * 0.8];
    //设置登陆按钮
    UIButton * registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    registerBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(30), lockerView.origin.y + lockerView.size.height + FIXWIDTHORHEIGHT(10), SCREEN_WIDTH - 60, FIXWIDTHORHEIGHT(40));
    [registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [registerBtn setTitle:@"登录" forState:UIControlStateNormal];
    registerBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    registerBtn.layer.masksToBounds = YES;
    registerBtn.backgroundColor = [UIColor redColor];
    registerBtn.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(18)];
    [registerBtn addTarget:self action:@selector(registerBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    _registerBtn = registerBtn;
    [_bigView addSubview:registerBtn];
    
    
    //下面的logo设置
    UIImageView * logo = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.34, SCREEN_HEIGHT * 0.8, SCREEN_WIDTH * 0.32, SCREEN_HEIGHT * 0.18)];
    logo.image = [UIImage imageNamed:@"logo1"];
    [_bigView addSubview:logo];
    
    //下方用户协议
    
    UIView * protocol = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), registerBtn.origin.y + registerBtn.size.height + FIXWIDTHORHEIGHT(10), SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), 30)];
    [_bigView addSubview:protocol];
    
    
    //红点点
    UIButton * smallRed = [UIButton buttonWithType:UIButtonTypeCustom];
    smallRed.frame = CGRectMake(0, FIXWIDTHORHEIGHT(12), FIXWIDTHORHEIGHT(6), FIXWIDTHORHEIGHT(6));
    smallRed.layer.cornerRadius = FIXWIDTHORHEIGHT(3);
    smallRed.layer.masksToBounds = YES;
    [smallRed setBackgroundColor:[UIColor redColor]];
    [protocol addSubview:smallRed];
    
    UILabel * custom = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(6), FIXWIDTHORHEIGHT(5), protocol.size.width * 0.55, FIXWIDTHORHEIGHT(20))];
    custom.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12.1)];
    custom.textColor = RGBCOLOR(138, 138, 138);
    custom.text = @"注册即视为您已经同意";
    [protocol addSubview:custom];
    
    UIButton * protocolBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    protocolBtn.frame = CGRectMake(custom.origin.x + custom.size.width - FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(5), protocol.size.width * 0.45, FIXWIDTHORHEIGHT(20));
    [protocolBtn setTitle:@"布袋医仕用户协议" forState:UIControlStateNormal];
    protocolBtn.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12.5)];
    [protocolBtn setTitleColor:RGBCOLOR(231, 97, 102) forState:UIControlStateNormal];
    [protocolBtn addTarget:self action:@selector(protocolBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [protocol addSubview:protocolBtn];
}

-(void)configHomeTabBarControllerUI{
    
    _secondCount = 60;
    
    ableViewController * ableView = [[ableViewController alloc]init];
    ableView.superDelegate = self;
    baseNavigationController * able = [[baseNavigationController alloc]initWithRootViewController:ableView];
    able.tabBarItem = [self createName:@"可接订单" withImage:@"available" withSelectImg:@"available"];
    
    
    historyViewController * historyView = [[historyViewController alloc]init];
    historyView.superDelegate = self;
    baseNavigationController * history = [[baseNavigationController alloc]initWithRootViewController:historyView];
    history.tabBarItem = [self createName:@"历史订单" withImage:@"history" withSelectImg:@"history"];
    
    ongoingViewController * ongoingView = [[ongoingViewController alloc]init];
    ongoingView.superDelegate = self;
    baseNavigationController * ongoing = [[baseNavigationController alloc]initWithRootViewController:ongoingView];
    ongoing.tabBarItem = [self createName:@"进行中" withImage:@"going" withSelectImg:@"going"];
    
    self.viewControllers = @[ongoing,able,history];

    self.selectedViewController = able;
    self.tabBar.tintColor = [UIColor grayColor];
    
}
-(UITabBarItem *)createName:(NSString *)name withImage:(NSString *)iName withSelectImg:(NSString *)sename{
    
    return [[UITabBarItem alloc]initWithTitle:name image:[[UIImage imageNamed:iName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:sename] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
}

//打开左侧抽屉
-(void)openLeft{
    
    if (!self.drawer.isOpen) {
        
        [self.drawer openLeftDrawer];
      
        
    }
    
}
//打开右侧抽屉
-(void)openRight{
    
}
//关闭抽屉
-(void)close{
    if (self.drawer.isOpen) {
        
        [self.drawer closeDrawer];
        
        
    }
    
}
#pragma mark--获取电话号码输入框代理方法
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//    NSLog(@"长度%d",string.length);
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField == _testField) {
        _registerBtn.enabled = YES;
    }
    return YES;
}
#pragma mark  获取验证码点击事件(接口)
-(void)getCodeBtnClicked{
    
    _getCode.enabled = YES;
 
/*************************获取验证码接口*****************************************/
    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    /**
     *  用户电话号码
     */
    [dic setObject:_numberField.text forKey:PHONE];
    /**
     *  用户类型 1为客户 2为服务人员
     */
    [dic setObject:@2 forKey:@"type"];
    
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,TESTCODE] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            [_numberField resignFirstResponder];
            [_testField becomeFirstResponder];
            //开启定时器
            if (!_timer) {
                _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerCount) userInfo:nil repeats:YES];
            }
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        
        NSLog(@"----%@",error);
        
    }];
    
    NSLog(@"%@",_numberField.text);

    
    NSLog(@"获取验证码");
    
    
    
}
#pragma mark --计时器
-(void)timerCount{
    if (_secondCount > 0) {
        [_getCode setTitle:[NSString stringWithFormat:@"%ds后可重发",(int)_secondCount] forState:UIControlStateNormal];
    }else{
        [self realeseTimer];
    }
    _secondCount --;
}
/**
 *  释放定时器
 */
-(void)realeseTimer{
    
    [_getCode setTitle:@"获取验证码" forState:UIControlStateNormal];
    _getCode.enabled = YES;
    _secondCount = 59;
    //时间到关闭释放定时器
    [_timer invalidate];
    _timer = nil;
    _testField.text = nil;
    
}
#pragma mark  登陆按钮的点击事件（接口）
-(void)registerBtnClicked{

    [_numberField resignFirstResponder];
    [_testField resignFirstResponder];
    
    
/*************************登陆接口(登陆成功单例保存用户ID)*****************************************/
    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:_numberField.text forKey:PHONE];//电话号码
    [dic setObject:_testField.text forKey:@"verifycode"];//验证码
    /**
     *  1表示用户 2表示服务人员
     */
    [dic setObject:@2 forKey:@"type"];
    /**
     *  1为安卓 2为ios
     */
    [dic setObject:@2 forKey:@"ptype"];
    /**
     *  设备token用于推送
     */
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"token"] length]) {
        [dic setObject:[[NSUserDefaults standardUserDefaults] objectForKey:@"token"] forKey:@"token"];

    }
    
    __weak __typeof(self) weakSelf = self;
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,LOGIN] body:dic block:^(id backData) {
        
        if ([[backData objectForKey:@"status"] intValue]) {//判断是否登陆成功
            [weakSelf loginSuccessChangeStatus:[backData objectForKey:@"result"]];
            [weakSelf realeseTimer];
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
        NSLog(@"success:%@",[backData objectForKey:@"msg"]);
        
    } error:^(NSError *error) {
        
    }];
    
    NSLog(@"注册按钮的点击事件");
}
#pragma mark--登陆成功的状态改变及数据处理(用的是测试的userId)
-(void)loginSuccessChangeStatus:(NSDictionary *)dic{

    NSLog(@"%@",dic);
    //数据保存
    NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
    
    if ([[[dic objectForKey:@"servicer"] objectForKey:@"icon"] length]) {
       [userInfo setObject:[[dic objectForKey:@"servicer"] objectForKey:@"icon"] forKey:ICONPATH];//头像路径保存
    }
    if ([[[dic objectForKey:@"servicer"] objectForKey:@"status"] intValue] == 1) {
        [userInfo setObject:@1 forKey:WORKSTATE];
    }else{
        [userInfo setObject:@0 forKey:WORKSTATE];
    }
    [userInfo setObject:@1 forKey:LOGINSTATE];
    [userInfo setObject:[[dic objectForKey:@"servicer"] objectForKey:@"name"]forKey:NAME];
    [userInfo setObject:[[dic objectForKey:@"servicer"] objectForKey:@"id"] forKey:@"user"];//保存用户的id
    [userInfo setObject:_numberField.text forKey:PHONE];//保存用户的手机号码

    _stateManager.userNumber = _numberField.text;//单例保存手机号码共享数据
    _stateManager.userId = [userInfo objectForKey:@"user"];//单例保存用户的id 实现数据的共享
    NSLog(@"%@---%@",_numberField.text,_stateManager.userId);
    _bigView.alpha = 0;
    self.tabBar.hidden = NO;
    self.tabBar.userInteractionEnabled = YES;
    
    /**
     *  消息中心发送通知，更改状态
     */
    [[NSNotificationCenter defaultCenter] postNotificationName:UPLOADPERSONDATA object:nil];
}
#pragma mark 用户协议按钮的点击事件
-(void)protocolBtnClicked{
    
    
    protocolViewController * protocol = [[protocolViewController alloc] init];
    
    [self presentViewController:protocol animated:YES completion:nil];
    
    
    NSLog(@"用户协议按钮的点击事件");
}
#pragma mark 手势的点击事件
-(void)tapGesture{
    [_numberField resignFirstResponder];
    [_testField resignFirstResponder];
}
#pragma mark--协议方法的实现
-(void)openOrCloseDrawer:(BOOL)state{
    if (state) {
        [self openLeft];
    }else{
        [self close];
    }
}
#pragma mark   消息中心的注册及销毁(网络判断)

-(void)registerNotificationCenter{
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(closeData:) name:@"close" object:nil];
    
    
}
-(void)closeData:(NSNotification *)notify{
    
    if ([[notify.userInfo objectForKey:@"close"] intValue]) {
        
        NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
        [userInfo setObject:@0 forKey:LOGINSTATE];
        NSLog(@"-----退出登陆-----%d",[[userInfo objectForKey:LOGINSTATE] intValue]);
        _bigView.alpha = 1.0;
        
        self.tabBar.hidden = YES;
    }
    
    [self.drawer closeDrawer];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"close" object:nil];

}
#pragma mark ----登陆成功获取个人信息并发送出去
-(void)getPersonDataAndPoster{

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

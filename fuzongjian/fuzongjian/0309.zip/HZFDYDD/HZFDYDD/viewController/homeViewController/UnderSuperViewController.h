//
//  UnderSuperViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnderSuperViewController : UIViewController

-(void)setBackButton:(NSString *)backStr;

-(void)setSureButton:(NSString *)sureStr;

-(void)setBackButtonImage:(NSString *)imageName;

-(void)setSureButtonImage:(NSString *)imageName;

-(void)setTitleWithString:(NSString *)str;

@end

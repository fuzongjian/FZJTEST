//
//  superViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "superViewController.h"
#import "personDataController.h"
@interface superViewController ()
@property(nonatomic,assign)float fontSize;
@end

@implementation superViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configSuperViewControllerUI];
    [self registerNotification];
}
//配置左侧头像按钮
-(void)configSuperViewControllerUI{
    
    //设置字体大小
    _fontSize = FIXWIDTHORHEIGHT(18);
    
    //设置头像按钮
    
    UIButton * iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    iconBtn.frame = CGRectMake(0, 0, 45, 45);
    [iconBtn addTarget:self action:@selector(iconBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [iconBtn setBackgroundImage:[UIImage imageNamed:@"me"] forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:iconBtn];
    
    
    
    //设置下班按钮
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBtn setTitle:@"下班" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    rightBtn.frame = CGRectMake(0, 0, 40, 40);
    [rightBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    _rightBtn = rightBtn;
    
    _state = YES;
    
    
    //上班视图创建
    
    //[self gotoWorkView];
    
}


#pragma mark -- 头像点击事件侧滑

-(void)iconBtnClicked:(UIButton *)btn{
    
    if (![[StateManager defaultManager] drawerState]) {
        if(self.navigationController)
        {
            if(self.navigationController.tabBarController)
            {
                if([self.navigationController.tabBarController respondsToSelector:@selector(openLeft)])
                {
                    [self.navigationController.tabBarController performSelector:@selector(openLeft)];
                }
            }
        }

    }else{
        if(self.navigationController)
        {
            if(self.navigationController.tabBarController)
            {
                if([self.navigationController.tabBarController respondsToSelector:@selector(close)])
                {
                    [self.navigationController.tabBarController performSelector:@selector(close)];
                }
            }
        }
    }
    
    NSLog(@"头像点击事件");
}
#pragma mark -- 下班点击事件
-(void)rightBtnClicked{
    
    self.rightBtn.hidden = YES;
    StateManager * manager = [StateManager defaultManager];
    manager.workState = NO;
    NSLog(@"工作状态--%d",manager.workState);
    NSLog(@"下班点击事件");
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    if(self.navigationController)
    {
        if(self.navigationController.tabBarController)
        {
            if([self.navigationController.tabBarController respondsToSelector:@selector(close)])
            {
                [self.navigationController.tabBarController performSelector:@selector(close)];
            }
        }
    }
    _state = YES;
}
-(void)setCustomTitle:(NSString *)title{
    
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 50)];
    label.text = title;
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor redColor];
    label.font = [UIFont systemFontOfSize:_fontSize];
    
    self.navigationItem.titleView = label;

}
#pragma mark   消息中心的注册及销毁
-(void)registerNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(uploadPersonData:) name:UPLOADPERSONDATA object:nil];
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UPLOADPERSONDATA object:nil];
}
-(void)uploadPersonData:(NSNotification *)notify{
   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  protocolViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/26.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "protocolViewController.h"
@interface protocolViewController ()<UIWebViewDelegate>
@end


@implementation protocolViewController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"用户协议"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    title.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [self.view addSubview:title];
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
    UIWebView * webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IPDERSS,PROTOCOL]]]];
    webView.delegate = self;
    [self.view addSubview:webView];
    
    
}
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [SVProgressHUD dismiss];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{

}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
    NSLog(@"3");
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
}
@end

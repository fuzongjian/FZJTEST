//
//  homeTabBarController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "superViewController.h"

@interface homeTabBarController : UITabBarController<DrawerChildViewController,openOrClose>

//因为自定义的tabbar才能保存抽屉,所以我们让tabbar作为中间层的事件传递媒介
//打开左侧抽屉
-(void)openLeft;
//打开右侧抽屉
-(void)openRight;
//关闭抽屉
-(void)close;

@end

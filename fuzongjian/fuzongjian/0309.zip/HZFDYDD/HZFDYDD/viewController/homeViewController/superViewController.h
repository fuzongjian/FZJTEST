//
//  superViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
/*协议方法*/
@protocol openOrClose <NSObject>

-(void)openOrCloseDrawer:(BOOL)state;

@end


@interface superViewController : UIViewController
@property(nonatomic,assign)BOOL state;//头像点击状态
@property(nonatomic,strong)UIImageView * imgView;
@property(nonatomic,strong)UIButton * rightBtn;

@property(nonatomic,assign)id<openOrClose>superDelegate;//代理


-(void)setCustomTitle:(NSString *)title;

@end

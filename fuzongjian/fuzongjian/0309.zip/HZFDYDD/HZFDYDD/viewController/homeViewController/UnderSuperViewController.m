//
//  UnderSuperViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderSuperViewController.h"

@interface UnderSuperViewController ()

@end

@implementation UnderSuperViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)setBackButton:(NSString *)backStr{
    UIButton * back = [UIButton buttonWithType:UIButtonTypeSystem];
    back.frame = CGRectMake(0, 0, 50, 50);
    [back setTitle:backStr forState:UIControlStateNormal];
    back.titleLabel.font = [UIFont systemFontOfSize:20];
    [back addTarget:self action:@selector(superBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
    
}
-(void)setBackButtonImage:(NSString *)imageName{
    UIButton * back = [UIButton buttonWithType:UIButtonTypeSystem];
    back.frame = CGRectMake(0, 0, 40, 40);
    [back setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [back addTarget:self action:@selector(superBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
}
-(void)setSureButton:(NSString *)sureStr{
    
    UIButton * sure = [UIButton buttonWithType:UIButtonTypeSystem];
    sure.frame = CGRectMake(0, 0, 50, 50);
    [sure setTitle:sureStr forState:UIControlStateNormal];
    sure.titleLabel.font = [UIFont systemFontOfSize:20];
    [sure addTarget:self action:@selector(superSureBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:sure];
}
-(void)setSureButtonImage:(NSString *)imageName{
    UIButton * sure = [UIButton buttonWithType:UIButtonTypeSystem];
    sure.frame = CGRectMake(0, 0, 50, 50);
    [sure setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:sure];
    
}

-(void)superBackBtnClicked{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)superSureBtnClicked{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)setTitleWithString:(NSString *)str{
    UILabel * lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 44)];
    lable.font = [UIFont systemFontOfSize:20];
    lable.text = str;
    lable.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = lable;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

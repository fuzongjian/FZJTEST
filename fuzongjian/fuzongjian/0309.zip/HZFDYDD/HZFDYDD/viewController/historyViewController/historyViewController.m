//
//  historyViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "historyViewController.h"
#import "historyCustomCell.h"
#import "historyDetailController.h"
#import "historyModel.h"


@interface historyViewController ()<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate>
@property(nonatomic,strong)UITableView * historyTable;
@property(nonatomic,strong)NSMutableArray * dataArr;
@property(nonatomic,strong)StateManager * stateManager;
/**
 *  判断有没有下一页
 */
@property(nonatomic,assign)BOOL nextPage;

@end

@implementation historyViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    static BOOL enterState = 0;
    
    if (!enterState) {
        
        enterState = !enterState;
        
    }else{
        
        /*  判断是否为上班状态  */
        [self judgeWorkState];
        [self loadHistoryViewControllerData];
        
    }
    
    
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
 [self stopMJRefresh:YES andMessage:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _stateManager = [StateManager defaultManager];
    
    /*  判断是否为上班状态  */    
    [self judgeWorkState];

    
    [self configHistoryViewControllerUI];
    
    [self addHeaderAndFooterMJRefesh];
    
    [self loadHistoryViewControllerData];
    
}
//- (nullable NSArray<NSString *> *)actionsForTarget:(nullable id)target forControlEvent:(UIControlEvents)controlEvent;
#pragma mark --
#pragma mark 初始化UI
-(void)configHistoryViewControllerUI{
    [self setCustomTitle:@"历史订单"];
    self.view.backgroundColor = [UIColor whiteColor];
    _dataArr = [NSMutableArray array];
    
    /*创建table*/
    
    _historyTable = [[UITableView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(2), SCREEN_WIDTH, SCREEN_HEIGHT - FIXWIDTHORHEIGHT(2)) style:UITableViewStylePlain];
    [self.view addSubview:_historyTable];
    _historyTable.delegate = self;
    _historyTable.dataSource = self;
    //去掉分割线 滚动条
    _historyTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _historyTable.showsVerticalScrollIndicator = NO;
    _historyTable.backgroundColor = RGBCOLOR(240, 240, 240);
    _historyTable.tableFooterView = [UIView new];

    //添加手势
    UISwipeGestureRecognizer * swipeLight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeLight)];
    swipeLight.direction = UISwipeGestureRecognizerDirectionRight;
    [_historyTable addGestureRecognizer:swipeLight];
    UISwipeGestureRecognizer * swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionLeft;
    [_historyTable addGestureRecognizer:swipeRight];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHistoryView)];
    tap.numberOfTapsRequired = 1;
    tap.delegate = self;
    [_historyTable addGestureRecognizer:tap];
    
}
#pragma mark  --  增加上拉下拉刷新
-(void)addHeaderAndFooterMJRefesh{
    __weak __typeof(self) weakSelf = self;

    /**
     *  下拉刷新
     */
    _historyTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [weakSelf loadHistoryViewControllerData];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([weakSelf.historyTable.mj_header isRefreshing]) {
                [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
                
            }
        });
    }];
    
    /**
     *  上拉刷新
     */
    _historyTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [weakSelf footerRefreshing];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([weakSelf.historyTable.mj_footer isRefreshing]) {
                [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
            }
        });
        
    }];
    
}

#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载(接口)
-(void)loadHistoryViewControllerData{
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    __weak __typeof(self) weakSelf = self;
    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    [AFNConnection GetHistoryData:[NSString stringWithFormat:@"%@%@",IPDERSS,HISTORYORDER] body:dic block:^(id backData) {

        _nextPage = [[backData objectForKey:@"nextpage"] intValue];
        weakSelf.dataArr = [NSMutableArray arrayWithArray:[backData objectForKey:@"dataArr"]];
        
        if (weakSelf.dataArr.count) {
            [weakSelf stopMJRefresh:YES andMessage:@"加载成功..."];
            [_historyTable reloadData];
        }else{
            [weakSelf stopMJRefresh:NO andMessage:@"没有历史订单"];
            [_historyTable reloadData];
        }
        
    } error:^(NSError *error) {
        [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
        NSLog(@"数据加载error:%@",error);
    }];
}
#pragma mark -- 上拉存储数据  下拉 不存储
-(void)footerRefreshing{
    
    __weak __typeof(self) weakSelf = self;

    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    
    if (_nextPage) {
        
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
        historyModel * model = [_dataArr lastObject];
        [dic setObject:model.creationTime forKey:@"createtime"];
        
        [AFNConnection GetHistoryData:[NSString stringWithFormat:@"%@%@",IPDERSS,HISTORYORDER] body:dic block:^(id backData) {
            
            _nextPage = [[backData objectForKey:@"nextpage"] intValue];
            NSArray * array = [backData objectForKey:@"dataArr"];

            if (array.count) {
                [weakSelf stopMJRefresh:YES andMessage:@"加载成功..,"];
                [weakSelf.dataArr addObjectsFromArray:array];
                [_historyTable reloadData];
            }else{
                [weakSelf stopMJRefresh:NO andMessage:@"没有历史订单"];
            }
        } error:^(NSError *error) {
            [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
        }];

        
    }else{
        [weakSelf stopMJRefresh:NO andMessage:@"已经是最后一页了"];
    }
  
}

#pragma mark--停止上拉下拉刷新

-(void)stopMJRefresh:(BOOL)state andMessage:(NSString *)message{

    if (!state && ([_historyTable.mj_header isRefreshing]||[_historyTable.mj_footer isRefreshing])) {
        [SVProgressHUD showErrorWithStatus:message];
    }
    
    if ([_historyTable.mj_footer isRefreshing]) {
        [_historyTable.mj_footer endRefreshing];
    }
    if ([_historyTable.mj_header isRefreshing]) {
        [_historyTable.mj_header endRefreshing];
    }
}

#pragma mark--
#pragma mark 事件
#pragma mark --上班状态的判断
-(void)judgeWorkState{
    
    if (_stateManager.workState) {
        
        self.rightBtn.hidden = YES;
        
    }else{
        
        self.rightBtn.hidden = YES;
    }
}
#pragma mark--添加手势实现的方法
-(void)swipeRight{
    [self.superDelegate openOrCloseDrawer:NO];
}
-(void)swipeLight{
    [self.superDelegate openOrCloseDrawer:YES];
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    static NSString * historyId = @"historyId";
    
    historyCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:historyId];
    if (!cell) {
        cell = [[historyCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:historyId];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = RGBCOLOR(240, 240, 240);
    
    historyModel * model = _dataArr[indexPath.row];
    cell.sum.text = [NSString stringWithFormat:@"%@",model.money];
    cell.durationTime.text = [NSString stringWithFormat:@"服务时长:%.f小时",[model.duration floatValue]];
    cell.aimHospital.text = [NSString stringWithFormat:@"目标医院:%@",model.hospitalName];
    cell.startTime.text = [NSString stringWithFormat:@"开始时间:%@",model.startTime];
    if ([model.shuttle intValue]) {
        cell.shuttleView.alpha = 1.0;
    }else{
        cell.shuttleView.alpha = 0.0;
    }
    
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return FIXWIDTHORHEIGHT(100);
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
       if (!_stateManager.drawerState) {
        
        historyDetailController * historyDetail = [[historyDetailController alloc]init];
        historyModel * model = _dataArr[indexPath.row];
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
        [dic setObject:model.Nid forKey:@"orderid"];
        historyDetail.dic = dic;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:historyDetail animated:YES];
        self.hidesBottomBarWhenPushed = NO;
        
    }else{
        [self closeDrawer];
    }
    
}
-(void)closeDrawer{
    if(self.navigationController)
    {
        if(self.navigationController.tabBarController)
        {
            if([self.navigationController.tabBarController respondsToSelector:@selector(close)])
            {
                [self.navigationController.tabBarController performSelector:@selector(close)];
            }
        }
    }
}
-(void)tapHistoryView{
    if (_stateManager.drawerState) {
        [self closeDrawer];
    }
}
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (_stateManager.drawerState) {
        return YES;
    }else{
        return NO;
    }
}
#pragma mark--
#pragma mark 通知注册及销毁

#pragma mark --- 重写父类的通知方法（登陆后发出的通知）
-(void)uploadPersonData:(NSNotification *)notify{
        NSLog(@"重写父类的通知方法（登陆后发出的通知）");
    [self loadHistoryViewControllerData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  historyCustomCell.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/13.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface historyCustomCell : UITableViewCell
@property(nonatomic,strong)UILabel * sum;//总额
@property(nonatomic,strong)UILabel * aimHospital;//目标医院
@property(nonatomic,strong)UILabel * startTime;//开始时间
@property(nonatomic,strong)UILabel * durationTime;//服务时间
@property(nonatomic,strong)UILabel * star;//服务等级
@property(nonatomic,strong)UIView * starView;//背景颜色

@property(nonatomic,strong)UIView * shuttleView;
@property(nonatomic,strong)UILabel * shuttle;

@end

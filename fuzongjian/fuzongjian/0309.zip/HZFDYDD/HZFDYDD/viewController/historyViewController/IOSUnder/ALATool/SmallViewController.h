//
//  SmallViewController.h
//  FZJALAPhotos
//
//  Created by fdkj0002 on 16/1/31.
//  Copyright © 2016年 FZJ.com. All rights reserved.
//

#import "SuperViewController.h"
#import "FZJALAPhotosTool.h"
#import "UnderSuperViewController.h"
@interface SmallViewController : UnderSuperViewController
@property(nonatomic,strong)ALAssetsGroup * group;
@property(nonatomic,assign)NSInteger index;
@property(nonatomic,assign)NSInteger addNum;
@property(nonatomic,strong)NSArray * dataArray;
@property(nonatomic,copy)void(^getPhotoArrayFromAlbum)(NSArray * photoArray);
@property(nonatomic,assign)NSInteger clickFrom;
@property(nonatomic,strong)NSString * titleName;
@end

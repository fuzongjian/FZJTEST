//
//  UnderBigViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderBigViewController.h"
#import "UnderPhotoModel.h"
#import "FZJBigPhotoCell.h"
#import "FZJALAPhotosTool.h"
#define margin 30
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define iPHone6Plus ([UIScreen mainScreen].bounds.size.height == 736) ? YES : NO
#define iPHone6 ([UIScreen mainScreen].bounds.size.height == 667) ? YES : NO
#define iPHone5 ([UIScreen mainScreen].bounds.size.height == 568) ? YES : NO
#define iPHone4oriPHone4s ([UIScreen mainScreen].bounds.size.height == 480) ? YES : NO
@interface UnderBigViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate>
@property(nonatomic,strong)UICollectionView * bigCollect;
@property(nonatomic,strong)UILabel * titleLable;
@property(nonatomic,strong)UILabel * displayLable;
@property(nonatomic,strong)UIButton * select;
@property(nonatomic,assign)float current;
@end

@implementation UnderBigViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self.bigCollect setContentOffset:CGPointMake((self.clickNum) * (SCREEN_WIDTH + margin), 0)];
    _titleLable.text = [NSString stringWithFormat:@"%d/%d",(int)(self.clickNum + 1),(int)self.chooseArray.count];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self setSureButton:@"删除"];
    [self setBackButton:@"返回"];
    UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowLayout.minimumLineSpacing = margin;
    flowLayout.sectionInset = UIEdgeInsetsMake(0, margin/2, 0, margin/2);
    flowLayout.itemSize = self.view.frame.size;
    
    _bigCollect = [[UICollectionView alloc] initWithFrame:CGRectMake(-margin/2, 0, SCREEN_WIDTH + margin, SCREEN_HEIGHT) collectionViewLayout:flowLayout];
    [_bigCollect registerNib:[UINib nibWithNibName:@"FZJBigPhotoCell" bundle:nil] forCellWithReuseIdentifier:@"BigPhotoCell"];
    _bigCollect.pagingEnabled = YES;
    _bigCollect.dataSource = self;
    _bigCollect.delegate = self;
    [self.view addSubview:_bigCollect];
    [self setTitleLable];
    // Do any additional setup after loading the view.
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.chooseArray.count;
}
-(UICollectionViewCell * )collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    FZJBigPhotoCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigPhotoCell" forIndexPath:indexPath];
    cell.ImageView.image = nil;
    UnderPhotoModel * model = self.chooseArray[indexPath.row];
    [cell showIndicator];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[FZJALAPhotosTool standardFZJALAPhotosTool] getFullScreenImageByALAssetUrl:model.url Completion:^(UIImage *image) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.ImageView.image = image;
                [cell hideIndicator];
            });
        }];
    });

    cell.ScrollView.delegate = self;
    [self addGestureTapToScrollView:cell.ScrollView];
    return cell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == (UIScrollView *)self.bigCollect) {
        CGFloat current = scrollView.contentOffset.x / (SCREEN_WIDTH + margin) + 1;
        _titleLable.text = [NSString stringWithFormat:@"%.f/%d",current,(int)self.chooseArray.count];
        _current = current - 1;
    }
}
-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    FZJBigPhotoCell * WillCell = (FZJBigPhotoCell *)cell;
    WillCell.ScrollView.zoomScale = 1;
}
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return scrollView.subviews[0];
}
-(void)addGestureTapToScrollView:(UIScrollView *)scrollView{
    UITapGestureRecognizer * singleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapOnScrollView:)];
    singleTap.numberOfTapsRequired = 1;
    [scrollView addGestureRecognizer:singleTap];
    
    UITapGestureRecognizer * doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTapOnScrollView:)];
    doubleTap.numberOfTapsRequired = 2;
    [scrollView addGestureRecognizer:doubleTap];
}
-(void)singleTapOnScrollView:(UITapGestureRecognizer *)singleTap{
    if (self.navigationController.navigationBar.isHidden) {
        [self showNavBarAndStatusBar];
    }else{
        [self hideNavBarAndStatusBar];
    }
}
-(void)showNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
}
-(void)hideNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = YES;
    [UIApplication sharedApplication].statusBarHidden = YES;
}
-(void)doubleTapOnScrollView:(UITapGestureRecognizer *)doubleTap{
    
    UIScrollView * scrollView = (UIScrollView *)doubleTap.view;
    CGFloat scale = 1;
    if (scrollView.zoomScale != 3) {
        scale = 3;
    }else{
        scale = 1;
    }
    [self CGRectForScale:scale WithCenter:[doubleTap locationInView:doubleTap.view] ScrollView:scrollView Completion:^(CGRect Rect) {
        [scrollView zoomToRect:Rect animated:YES];
    }];
}
-(void)CGRectForScale:(CGFloat)scale WithCenter:(CGPoint)center ScrollView:(UIScrollView *)scrollView Completion:(void(^)(CGRect Rect))completion{
    CGRect Rect;
    Rect.size.height = scrollView.frame.size.height / scale;
    Rect.size.width  = scrollView.frame.size.width  / scale;
    Rect.origin.x    = center.x - (Rect.size.width  /2.0);
    Rect.origin.y    = center.y - (Rect.size.height /2.0);
    completion(Rect);
}
//删除数据
-(void)superSureBtnClicked{
    UnderPhotoModel * model = self.chooseArray[(NSInteger)_current];
    [self.chooseArray removeObject:model];
    [self.bigCollect reloadData];
    [self uploadDisplay];
}
-(void)uploadDisplay{
   _titleLable.text = [NSString stringWithFormat:@"%.f/%d",_current,(int)self.chooseArray.count];
}
//重写父类的返回方法
-(void)superBackBtnClicked{
    if (self.returnUploadNewPhoto) {
        self.returnUploadNewPhoto(self.chooseArray);
    }
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)setTitleLable{
    _titleLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    _titleLable.text = [NSString stringWithFormat:@"%d/%d",(int)self.clickNum,(int)self.chooseArray.count];
    _titleLable.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = _titleLable;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

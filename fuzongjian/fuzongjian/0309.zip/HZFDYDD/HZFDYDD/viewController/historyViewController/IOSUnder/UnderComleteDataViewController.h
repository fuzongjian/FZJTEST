//
//  UnderComleteDataViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderSuperViewController.h"

typedef  void (^uploadSuccess)(BOOL state);
@interface UnderComleteDataViewController : UnderSuperViewController

@property(nonatomic,strong)NSDictionary * detailOrder;

@property(nonatomic,assign)BOOL serviceEnd;

@property(nonatomic,assign)NSInteger clickFrom;

@property(nonatomic,copy)uploadSuccess block;

-(void)returnSuccessState:(uploadSuccess)stateBlock;

@end

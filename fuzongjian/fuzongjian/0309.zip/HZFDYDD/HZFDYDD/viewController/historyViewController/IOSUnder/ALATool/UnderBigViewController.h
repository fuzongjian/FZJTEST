//
//  UnderBigViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderSuperViewController.h"

@interface UnderBigViewController : UnderSuperViewController

@property(nonatomic,copy)void(^returnUploadNewPhoto)(NSArray * photoArray);
@property(nonatomic,strong)NSMutableArray * chooseArray;
@property(nonatomic,assign)NSInteger clickNum;

@end

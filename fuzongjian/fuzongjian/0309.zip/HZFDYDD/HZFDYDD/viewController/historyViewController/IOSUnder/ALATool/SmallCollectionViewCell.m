//
//  SmallCollectionViewCell.m
//  FZJALAPhotos
//
//  Created by fdkj0002 on 16/1/31.
//  Copyright © 2016年 FZJ.com. All rights reserved.
//

#import "SmallCollectionViewCell.h"

@implementation SmallCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end

//
//  UnderComleteDataViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderComleteDataViewController.h"
#import "chooseViewController.h"
#import "chooseDetailController.h"
#import "bigPhotoViewController.h"
#import "DisplayCollectionViewCell.h"
#import "UnderPhotoModel.h"
#import "FZJALAPhotosTool.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "UnderTableViewController.h"
#import "UnderBigViewController.h"
#import <Photos/PHAsset.h>//
#import <Photos/PHFetchResult.h>//相册相关
#import <Photos/PHFetchOptions.h>//
#import <Photos/PHCollection.h>//
#import <photos/PHImageManager.h>//

//#define weakSelf 
//__weak __typeof(self)weakSelf = self;

@interface UnderComleteDataViewController ()<UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,PHPhotoLibraryChangeObserver,UICollectionViewDelegate,UICollectionViewDataSource,UIGestureRecognizerDelegate>
@property(nonatomic,strong)UITextView * bgTextView;
@property(nonatomic,strong)UITextView * textView;
@property(nonatomic,strong)UIView * backgroundView;
@property(nonatomic,strong)UIView * popView;//弹出视图
@property(nonatomic,strong)UIView * bigPhotoView;//大图浏览
@property(nonatomic,strong)NSMutableDictionary * dataDic;//相册名对应相册
@property(nonatomic,strong)NSMutableArray * photoTitle;//存放相册名

@property(nonatomic,strong)UIView * btnBackgroundView;//背后半透明的遮盖
@property(nonatomic,strong)UIView * btnPopView;//弹出视图；

@property(nonatomic,strong)UIButton * addBtnTwo;
@property(nonatomic,strong)UIImageView * bgImageViewTwo;
@property(nonatomic,strong)UIButton * addBtnThree;
@property(nonatomic,strong)UIImageView * bgImageViewThree;
@property(nonatomic,strong)UIButton * addBtnFour;
@property(nonatomic,strong)UIImageView * bgImageViewFour;
/***************************照片相关*****************************/
@property(nonatomic,assign)NSInteger num;//记录点击了第几个添加照片按钮
@property(nonatomic,assign)NSInteger clickNum;//记录点击了第几组的大图浏览
@property(nonatomic,strong)NSArray * photoArr;

@property(nonatomic,strong)NSMutableArray * photoArrTwo;
@property(nonatomic,strong)NSMutableArray * photoArrThree;
@property(nonatomic,strong)NSMutableArray * photoArrFour;

@property(nonatomic,strong)UIScrollView * scrollTwo;
@property(nonatomic,strong)UIScrollView * scrollThree;
@property(nonatomic,strong)UIScrollView * scrollFour;

@property(nonatomic,strong)UICollectionView * collectOne;
@property(nonatomic,strong)UICollectionView * collectTwo;
@property(nonatomic,strong)UICollectionView * collectThree;

/**
 *  用于存放上传时的所有图片
 */
@property(nonatomic,strong)NSMutableArray * allArr;
/**
 *  用于存放上传是返回的所有图片的路径
 */
@property(nonatomic,strong)NSMutableArray * photoPath;
/**
 *  用户是否同意
 */
@property(nonatomic,assign)BOOL userAgreeState;

@property (nonatomic, strong) PHCachingImageManager *imageManager;
@property(nonatomic,strong)PHImageManager * managerImage;


/**
 *  保证PHPhotoLibraryChangeObserver代理方法只进入依次
 */
@property(nonatomic,assign)BOOL takeState;


/****************************照片相关****************************/

/**
 *  键盘是否弹出
 */
@property(nonatomic,assign)BOOL keyBoardOpen;

@end

@implementation UnderComleteDataViewController

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    _photoArr = [NSArray array];
    _photoTitle = [NSMutableArray array];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configCompleteDataControllerUI];
    [self registerCompleteDataControllerNotificationCenter];
    NSLog(@"------%@",_detailOrder);
}
#pragma mark --
#pragma mark 初始化UI
-(void)configCompleteDataControllerUI{
    
    
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    //注册实施监听相册变化
    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
    [self registerNOtificationToKeyBoard];
    _userAgreeState = YES;
    
    self.imageManager = [[PHCachingImageManager alloc] init];
    self.managerImage = [[PHImageManager alloc]init];
    
    //    [self.imageManager stopCachingImagesForAllAssets];
    
    
    _num = 0;
    _clickNum = 0;
    _dataDic = [NSMutableDictionary dictionary];
    _photoTitle = [NSMutableArray array];
    
    _photoArrTwo = [NSMutableArray array];
    _photoArrThree = [NSMutableArray array];
    _photoArrFour = [NSMutableArray array];
    
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(historyBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    //设置标题
    self.navigationItem.titleView = [Tool setCustomViewTitle:@"修改就诊资料"];
    
    
    //创建一个scrollView充当容器
    
    float height = 135,margin = 0;
    if (iPHone6) {
        
        margin = 90;
    }
    if (iPHone6Plus) {
        
        margin = 140;
    }
    
    UIScrollView * scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(3), SCREEN_WIDTH, SCREEN_HEIGHT - FIXWIDTHORHEIGHT(3))];
    scroll.backgroundColor = RGBCOLOR(240, 240, 240);
    scroll.contentSize = CGSizeMake(SCREEN_WIDTH, FIXWIDTHORHEIGHT(height * 4 + 40 + 50 + margin));
    [self.view addSubview:scroll];
    
    //定义标题字体大小、颜色、标题与图标的间隔
    float dataFontSize = FIXWIDTHORHEIGHT(15);
    float marginWidth = FIXWIDTHORHEIGHT(7);
    UIColor * dataColor = RGBCOLOR(46, 46, 46);
    
#pragma mark--医嘱
    /*   医嘱   */
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    bgViewOne.userInteractionEnabled = YES;
    [scroll addSubview:bgViewOne];
    
    //分割线
    UIView * viewOne = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewOne.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewOne addSubview:viewOne];
    
    //头标题和图标
    UIImageView * imageOne = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageOne.image = [UIImage imageNamed:@"advice"];
    [bgViewOne addSubview:imageOne];
    UILabel * lableOne = [[UILabel alloc]initWithFrame:CGRectMake(imageOne.origin.x + imageOne.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableOne.text = @"医嘱";
    lableOne.font = [UIFont systemFontOfSize:dataFontSize];
    lableOne.textColor = dataColor;
    [bgViewOne addSubview:lableOne];
    
    //就医情况描述
    _bgTextView = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), viewOne.origin.y + FIXWIDTHORHEIGHT(5), bgViewOne.size.width - FIXWIDTHORHEIGHT(40), bgViewOne.size.height - viewOne.origin.y - FIXWIDTHORHEIGHT(15))];
    _bgTextView.font = [UIFont systemFontOfSize:dataFontSize];
    _bgTextView.textColor = RGBCOLOR(160, 160, 160);
    _bgTextView.text = @"就医者本次就医情况描述";
    [bgViewOne addSubview:_bgTextView];
    
    _textView = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), viewOne.origin.y + FIXWIDTHORHEIGHT(5), bgViewOne.size.width - FIXWIDTHORHEIGHT(40), bgViewOne.size.height - viewOne.origin.y - FIXWIDTHORHEIGHT(15))];
    _textView.backgroundColor = [UIColor clearColor];
    _textView.font = [UIFont systemFontOfSize:dataFontSize];
    _textView.delegate = self;
    [bgViewOne addSubview:_textView];
    
#pragma mark--病历照
    /*   病例照   */
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 1), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    bgViewTwo.userInteractionEnabled = YES;
    [scroll addSubview:bgViewTwo];
    //分割线
    UIView * viewTwo = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewTwo.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewTwo addSubview:viewTwo];
    //头标题和图标
    UIImageView * imageTwo = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageTwo.image = [UIImage imageNamed:@"report"];
    [bgViewTwo addSubview:imageTwo];
    UILabel * lableTwo = [[UILabel alloc]initWithFrame:CGRectMake(imageTwo.origin.x + imageTwo.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableTwo.text = @"病历照";
    lableTwo.font = [UIFont systemFontOfSize:dataFontSize];
    lableTwo.textColor = dataColor;
    [bgViewTwo addSubview:lableTwo];
    
    UIButton * btnTwo = [UIButton buttonWithType:UIButtonTypeCustom];
    btnTwo.frame = CGRectMake(FIXWIDTHORHEIGHT(20), viewTwo.origin.y + FIXWIDTHORHEIGHT(6), FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
    btnTwo.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    btnTwo.layer.masksToBounds = YES;
    [btnTwo setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
    [btnTwo addTarget:self action:@selector(btnTwoAddPhotoClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewTwo addSubview:btnTwo];
    
    _bgImageViewTwo = bgViewTwo;
    _addBtnTwo = btnTwo;
    
    [self addCollectionViewToImageView:_bgImageViewTwo Completion:^(UICollectionView *collect) {
        _collectOne = collect;
    }];
#pragma mark--处方照
    /*   处方照   */
    UIImageView * bgViewThree = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 2), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewThree.userInteractionEnabled = YES;
    bgViewThree.image = [UIImage imageNamed:@"bg-5"];
    [scroll addSubview:bgViewThree];
    //分割线
    UIView * viewThree = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewThree.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewThree addSubview:viewThree];
    //头标题和图标
    UIImageView * imageThree = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageThree.image = [UIImage imageNamed:@"prescription"];
    [bgViewThree addSubview:imageThree];
    UILabel * lableThree = [[UILabel alloc]initWithFrame:CGRectMake(imageThree.origin.x + imageThree.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableThree.text = @"处方照";
    lableThree.font = [UIFont systemFontOfSize:dataFontSize];
    lableThree.textColor = dataColor;
    [bgViewThree addSubview:lableThree];
    
    _addBtnThree = [UIButton buttonWithType:UIButtonTypeCustom];
    _addBtnThree.frame = CGRectMake(FIXWIDTHORHEIGHT(20), viewTwo.origin.y + FIXWIDTHORHEIGHT(6), FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
    _addBtnThree.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _addBtnThree.layer.masksToBounds = YES;
    [_addBtnThree setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
    [_addBtnThree addTarget:self action:@selector(btnThreeAddPhotoClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewThree addSubview:_addBtnThree];
    _bgImageViewThree = bgViewThree;
    
    [self addCollectionViewToImageView:_bgImageViewThree Completion:^(UICollectionView *collect) {
        _collectTwo = collect;
    }];
#pragma mark--药品照
    /*   药品照   */
    UIImageView * bgViewFour = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 3), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewFour.image = [UIImage imageNamed:@"bg-5"];
    bgViewFour.userInteractionEnabled = YES;
    [scroll addSubview:bgViewFour];
    //分割线
    UIView * viewFour = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewFour.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewFour addSubview:viewFour];
    //头标题和图标
    UIImageView * imageFour = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageFour.image = [UIImage imageNamed:@"medicals"];
    [bgViewFour addSubview:imageFour];
    UILabel * lableFour = [[UILabel alloc]initWithFrame:CGRectMake(imageFour.origin.x + imageFour.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableFour.text = @"药品照";
    lableFour.font = [UIFont systemFontOfSize:dataFontSize];
    lableFour.textColor = dataColor;
    [bgViewFour addSubview:lableFour];
    
    _addBtnFour = [UIButton buttonWithType:UIButtonTypeCustom];
    _addBtnFour.frame = CGRectMake(FIXWIDTHORHEIGHT(20), viewTwo.origin.y + FIXWIDTHORHEIGHT(6), FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
    _addBtnFour.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _addBtnFour.layer.masksToBounds = YES;
    [_addBtnFour setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
    [_addBtnFour addTarget:self action:@selector(btnFourAddPhotoClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewFour addSubview:_addBtnFour];
    _bgImageViewFour = bgViewFour;

    [self addCollectionViewToImageView:_bgImageViewFour Completion:^(UICollectionView *collect) {
        _collectThree = collect;
    }];
    
    /*   用户拒绝上传相关照片   */
    
    UIButton * btnN = [UIButton buttonWithType:UIButtonTypeCustom];
    btnN.frame = CGRectMake(FIXWIDTHORHEIGHT(80), bgViewFour.origin.y + bgViewFour.size.height + FIXWIDTHORHEIGHT(12.5), FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(15));
    [btnN setBackgroundImage:[UIImage imageNamed:@"noSelected"] forState:UIControlStateNormal];//noSelected
    [scroll addSubview:btnN];
    
    UIButton * btnY = [UIButton buttonWithType:UIButtonTypeCustom];
    btnY.frame = CGRectMake(FIXWIDTHORHEIGHT(80), bgViewFour.origin.y + bgViewFour.size.height + FIXWIDTHORHEIGHT(12.5), FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(15));
    [btnY setBackgroundImage:[UIImage imageNamed:@"selected"] forState:UIControlStateNormal];//noSelected
    [scroll addSubview:btnY];
    btnY.hidden = YES;
    btnN.tag = 1747447;
    btnY.tag = 1747448;
    [btnN addTarget:self action:@selector(agreeOrRefuseBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btnY addTarget:self action:@selector(agreeOrRefuseBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(btnY.origin.x + btnY.size.width + FIXWIDTHORHEIGHT(5), bgViewFour.origin.y + bgViewFour.size.height, FIXWIDTHORHEIGHT(150), FIXWIDTHORHEIGHT(40))];
    lable.text = @"用户拒绝上传相关照片";
    lable.textColor = RGBCOLOR(108, 108, 108);
    lable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(14)];
    [scroll addSubview:lable];
    
    /*   完成按钮   */
    UIButton * finish = [UIButton buttonWithType:UIButtonTypeCustom];
    finish.frame = CGRectMake(FIXWIDTHORHEIGHT(30), lable.origin.y + lable.size.height, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    [finish setTitle:@"完 成" forState:UIControlStateNormal];
    [finish setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    finish.backgroundColor = [UIColor redColor];
    finish.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    finish.layer.masksToBounds = YES;
    finish.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(18)];
    [finish addTarget:self action:@selector(finish) forControlEvents:UIControlEventTouchUpInside];
    [scroll addSubview:finish];
    
    [self addGestureTap:bgViewOne];
    [self addGestureTap:bgViewTwo];
    [self addGestureTap:bgViewThree];
    [self addGestureTap:bgViewFour];
    
}
-(void)addCollectionViewToImageView:(UIImageView *)imageView Completion:(void(^)(UICollectionView * collect))completion{
    
    UICollectionViewFlowLayout * flowLayOut = [[UICollectionViewFlowLayout alloc] init];
    
    [flowLayOut setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    
    UICollectionView * collection = [[UICollectionView alloc] initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40), imageView.size.width - FIXWIDTHORHEIGHT(110), FIXWIDTHORHEIGHT(90)) collectionViewLayout:flowLayOut];
    [imageView addSubview:collection];
    collection.showsHorizontalScrollIndicator = NO;
    collection.delegate = self;
    collection.dataSource = self;
    collection.backgroundColor = [UIColor whiteColor];
    [collection registerNib:[UINib nibWithNibName:@"DisplayCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"display"];
    completion(collection);
}
#pragma mark--
#pragma mark 数据请求
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (collectionView == _collectOne) {
        return self.photoArrTwo.count;
    }else if (collectionView == _collectTwo){
        return self.photoArrThree.count;
    }else{
        return self.photoArrFour.count;
    }
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    DisplayCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"display" forIndexPath:indexPath];
    UnderPhotoModel * model;
    cell.ImageView.image = nil;
    if (collectionView == _collectOne) {
        model = self.photoArrTwo[indexPath.row];
    }else if (collectionView == _collectTwo){
        model = self.photoArrThree[indexPath.row];
    }else{
        model = self.photoArrFour[indexPath.row];
    }
    [[FZJALAPhotosTool standardFZJALAPhotosTool] getThumbnailImageByALAssetUrl:model.url Completion:^(UIImage *image) {
        cell.ImageView.image = image;
    }];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UnderBigViewController * underBig = [[UnderBigViewController alloc] init];
    underBig.clickNum = indexPath.row;
    if (collectionView == _collectOne) {
        underBig.chooseArray = self.photoArrTwo;
    }else if (collectionView == _collectTwo){
        underBig.chooseArray = self.photoArrThree;
    }else{
        underBig.chooseArray = self.photoArrFour;
    }
    __weak __typeof(self)weakSelf = self;
    underBig.returnUploadNewPhoto = ^(NSArray * photoArray){
        [weakSelf uploadPhotoArray:photoArray collection:collectionView];
    };
    [self.navigationController pushViewController:underBig animated:YES];
    
}
-(void)uploadPhotoArray:(NSArray *)array collection:(UICollectionView *)collect{
    if (collect == _collectOne) {
        self.photoArrTwo = [NSMutableArray arrayWithArray:array];
    }else if (collect == _collectTwo){
        self.photoArrThree = [NSMutableArray arrayWithArray:array];
    }else{
        self.photoArrFour = [NSMutableArray arrayWithArray:array];
    }
    [collect reloadData];
}
/**
 *  单元格的大小
 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake(FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
}
/**
 *  上下左右的间隔
 */
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5));//上左下右
    
}
/**
 *  单元格最小间距
 */
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return FIXWIDTHORHEIGHT(5);
}
/**
 *  单元格最小行距
 */
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return FIXWIDTHORHEIGHT(5);
}

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件

#pragma mark -- 背景图片添加手势 收缩键盘
-(void)addGestureTap:(UIImageView *)imageView{
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTap)];
    tap.numberOfTapsRequired = 1;
    tap.delegate = self;
    [imageView addGestureRecognizer:tap];
}
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (self.keyBoardOpen) {
        return YES;
    }else{
        return NO;
    }
}
-(void)registerNOtificationToKeyBoard{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardDidShow) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyBoardDidHiden) name:UIKeyboardDidHideNotification object:nil];
}
-(void)keyBoardDidShow{
    self.keyBoardOpen = YES;
}
-(void)keyBoardDidHiden{
    self.keyBoardOpen = NO;
}
-(void)imageTap{
    NSLog(@"asdfasdf");
    [_textView resignFirstResponder];
}
#pragma mark--病历照照片添加按钮点击事件
-(void)btnTwoAddPhotoClicked{
    NSLog(@"病历照照片添加按钮点击事件");
    
    _num = 1;
    [_textView resignFirstResponder];
    
    if (_photoArrTwo.count < 10) {
        
        [self choosePhotoPopView];
        
    }else{
        
        [SVProgressHUD showErrorWithStatus:@"病历照最多上传10张"];
    }
    
    
}
#pragma mark--处方照照片添加按钮点击事件
-(void)btnThreeAddPhotoClicked{
    _num = 2;
    [_textView resignFirstResponder];
    if (_photoArrThree.count < 10) {
        
        [self choosePhotoPopView];
        
    }else{
        
        [SVProgressHUD showErrorWithStatus:@"处方照最多上传10张"];
    }
    
}
#pragma mark--药品照照片添加按钮点击事件
-(void)btnFourAddPhotoClicked{
    _num = 3;
    [_textView resignFirstResponder];
    if (_photoArrFour.count < 10) {
        
        [self choosePhotoPopView];
        
    }else{
        
        [SVProgressHUD showErrorWithStatus:@"药品照最多上传10张"];
    }
    
}
#pragma mark--选择照片弹出视图
-(void)choosePhotoPopView{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    [self addTapGestureToBackgroundView:bgView];
    _backgroundView = bgView;
    
    
    //弹出的选择框
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = 5;
    popView.layer.masksToBounds = YES;
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    _popView = popView;
    
    float btnHeight = (popView.size.height - (20 + 20 + 5 + 5 ))/3.0;
    
    for (int i = 0; i < 3; i ++) {
        UIButton  * btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(20, 20 + (btnHeight + 5) * i , popView.size.width - 40, btnHeight);
        
        btn.layer.cornerRadius = btnHeight/2.0;
        btn.layer.masksToBounds = YES;
        
//        [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//        CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//        CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
//        [btn.layer setBorderColor:color];
        [btn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
        
        [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        if (i == 0) {
            [btn setImage:[[UIImage imageNamed:@"camera"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"拍照" forState:UIControlStateNormal];
            
        }else if (i == 1){
            [btn setImage:[[UIImage imageNamed:@"photo"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"从手机相册添加" forState:UIControlStateNormal];
        }else{
            
            [btn setTitle:@"取消" forState:UIControlStateNormal];
        }
        
        btn.tag = 4892472 + i;
        [btn addTarget:self action:@selector(takePhotoOrAlbumOrCancleBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [popView addSubview:btn];
    }
    
    
}
#pragma mark--拍照、从手机相册添加、取消的按钮点击事件
-(void)takePhotoOrAlbumOrCancleBtnClicked:(UIButton *)btn{
    switch (btn.tag) {
        case 4892472:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            [self takePhotoFromiphone];
            break;
        case 4892473:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            [self takePhotoFromAlbum];
            break;
        case 4892474:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            break;
        default:
            break;
    }
}
-(void)addTapGestureToBackgroundView:(UIView *)View{
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureClicked)];
    tap.numberOfTapsRequired = 1;
    [View addGestureRecognizer:tap];
}
-(void)tapGestureClicked{
    [_backgroundView removeFromSuperview];
    [_popView removeFromSuperview];
}

#pragma mark--从手机拍照
-(void)takePhotoFromiphone{
    
    if ([self judgeIsHaveCameraAuthority]) {
        
        _takeState = YES;
        
        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UIImagePickerController * picker = [[UIImagePickerController alloc]init];
            picker.delegate = self;
            picker.allowsEditing = NO;
            picker.sourceType = sourceType;
            [self.view.window.rootViewController presentViewController:picker animated:YES completion:nil];
            
        }else{
            NSLog(@"该设备没有摄像头");
        }
        
    }else{
        
        [SVProgressHUD showErrorWithStatus:@"请在iPhone的\"设置-隐私-相机\"中允许访问相机"];
    }
}
#pragma mark--从相册取照片
-(void)takePhotoFromAlbum{
    
    if ([self judgeIsHavePhotoAblumAuthority]) {//如果有相册使用权,进入相册拿到照片跳转到下一个界面
        
        [self enterAlbum];
        
    }else{
        
        [SVProgressHUD showErrorWithStatus:@"请在iPhone的\"设置-隐私-相册\"中允许访问相册"];
        
    }
    
    
}
#pragma mark--进入相册跳转到下一界面
-(void)enterAlbum{
    
    UnderTableViewController * under = [[UnderTableViewController alloc] init];
    __weak __typeof (self) weakSelf = self;
    under.getPhotoArrayFromAlbum = ^(NSArray * photoArray){
        [weakSelf addPhotoArray:photoArray];
    };
    under.clickFrom = self.clickFrom;
    if (_num == 1) {
        under.addNum = 10 - self.photoArrTwo.count;
    }else if (_num == 2){
        under.addNum = 10 - self.photoArrThree.count;
    }else{
        under.addNum = 10 - self.photoArrFour.count;
    }
    [self.navigationController pushViewController:under animated:YES];
    
}
-(void)addPhotoArray:(NSArray * )array{
    if (_num == 1) {
        [self.photoArrTwo addObjectsFromArray:array];
        [_collectOne reloadData];
    }else if (_num ==2){
        [self.photoArrThree addObjectsFromArray:array];
        [_collectTwo reloadData];
    }else{
        [self.photoArrFour addObjectsFromArray:array];
        [_collectThree reloadData];
    }
}
#pragma mark - 判断软件是否有相册、相机访问权限
- (BOOL)judgeIsHavePhotoAblumAuthority
{
    ALAuthorizationStatus state = [ALAssetsLibrary authorizationStatus];
    if (state == ALAuthorizationStatusRestricted || state == ALAuthorizationStatusDenied) {
        return NO;
    }
    return YES;
}
- (BOOL)judgeIsHaveCameraAuthority
{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied) {
        return NO;
    }
    return YES;
}
#pragma mark--照片代理
/**
 *  将照片写入相册
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{

    
    UIImage * image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    ALAssetsLibrary * library = [[ALAssetsLibrary alloc] init];

    __weak __typeof (self) weakSelf = self;
    [library writeImageToSavedPhotosAlbum:[image CGImage] orientation:(ALAssetOrientation)image.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error) {
        if (!error) {
            UnderPhotoModel * model = [[UnderPhotoModel alloc] init];
            model.url = assetURL;
            if (_num == 1) {
                [weakSelf.photoArrTwo addObject:model];
                [weakSelf.collectOne reloadData];
            }else if (_num == 2){
                [weakSelf.photoArrThree addObject:model];
                [weakSelf.collectTwo reloadData];
            }else{
                [weakSelf.photoArrFour addObject:model];
                [weakSelf.collectThree reloadData];
            }
        }
    }];
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
/**
 *  照相取消按钮 退出照相
 */
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

#pragma mark--相册监听
-(void)photoLibraryDidChange:(PHChange *)changeInstance{
    
}

#pragma mark--自定义拍照界面

#pragma mark  返回按钮事件
-(void)historyBackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
#pragma mark--用户拒绝上传相关照片按钮点击事件
-(void)agreeOrRefuseBtnClicked:(UIButton *)btn{
    UIButton * btnN = [self.view viewWithTag:1747447];
    UIButton * btnY = [self.view viewWithTag:1747448];
    if (btn.tag == 1747447) {
        btnN.hidden = YES;
        btnY.hidden = NO;
        [self createAlertPopView];
        NSLog(@"用户同意");
    }else{
        btnN.hidden = NO;
        btnY.hidden = YES;
        _userAgreeState = YES;
        NSLog(@"用户拒绝");
    }
}
#pragma mark--勾选用户拒绝上传相关图片弹出视图
-(void)createAlertPopView{
    float popFontSize = FIXWIDTHORHEIGHT(19);
    UIColor * color = RGBCOLOR(105, 105, 105);
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    _btnBackgroundView = bgView;
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.3, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.4)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    _btnPopView = popView;
    
    
    UIImageView * warnImage = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, FIXWIDTHORHEIGHT(5), popView.size.width * 0.3, popView.size.width * 0.3)];
    warnImage.image = [UIImage imageNamed:@"warning"];
    [popView addSubview:warnImage];
    
    
    UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(popView.size.width * 0.05, popView.size.width * 0.3 - FIXWIDTHORHEIGHT(10) , popView.size.width * 0.9, popView.size.height * 0.5)];
    lable.font = [UIFont systemFontOfSize:popFontSize];
    lable.text = @"您勾选了用户拒绝上传相关照片，是否征得用户同意?如若没有征得用户同意，用户有权举报。";
    lable.textColor = color;
    lable.numberOfLines = 0;
    [popView addSubview:lable];
    
    
    //[btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//    CGColorRef borderColor = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
    // [btn.layer setBorderColor:color];
    
    
    UIButton * cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancleBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(10), popView.size.height * 0.8, popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), popView.size.height * 0.14);
    cancleBtn.layer.cornerRadius = popView.size.height * 0.07;
    cancleBtn.layer.masksToBounds = YES;
    [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
    cancleBtn.titleLabel.font = [UIFont systemFontOfSize:popFontSize];
    [cancleBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [cancleBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [cancleBtn.layer setBorderColor:borderColor];
    [cancleBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [cancleBtn addTarget:self action:@selector(popViewCancleBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [popView addSubview:cancleBtn];
    
    UIButton * sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(popView.size.width * 0.5 + FIXWIDTHORHEIGHT(5), popView.size.height * 0.8, popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), popView.size.height * 0.14);
    sureBtn.layer.cornerRadius = popView.size.height * 0.07;
    sureBtn.layer.masksToBounds = YES;
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    sureBtn.titleLabel.font = [UIFont systemFontOfSize:popFontSize];
    [sureBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [sureBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [sureBtn.layer setBorderColor:borderColor];
    [sureBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [sureBtn addTarget:self action:@selector(popViewSureBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    [popView addSubview:sureBtn];
    
    
}
#pragma mark-- 勾选用户拒绝上传相关图片弹出视图 确定按钮点击事件
-(void)popViewSureBtnClicked{
    _userAgreeState = NO;
    [_btnPopView removeFromSuperview];
    [_btnBackgroundView removeFromSuperview];
    NSLog(@"弹出视图的确定点击事件");
}
#pragma mark-- 勾选用户拒绝上传相关图片弹出视图 取消按钮点击事件
-(void)popViewCancleBtnClicked{
    UIButton * btnN = [self.view viewWithTag:1747447];
    UIButton * btnY = [self.view viewWithTag:1747448];
    btnN.hidden = NO;
    btnY.hidden = YES;
    _userAgreeState = YES;
    [_btnPopView removeFromSuperview];
    [_btnBackgroundView removeFromSuperview];
}
#pragma mark--完成按钮点击事件  ------  (图片上传 ，)
-(void)finish{
    
    
    if (self.userAgreeState) { //用户同意上传
        
        _photoPath = [NSMutableArray array];
        _allArr = [NSMutableArray array];
        
        [_allArr addObjectsFromArray:_photoArrTwo];
        [_allArr addObjectsFromArray:_photoArrThree];
        [_allArr addObjectsFromArray:_photoArrFour];
        
        if (_allArr.count != 0) {
            
            if ([StateManager defaultManager].reachState == 0) {
                [SVProgressHUD showErrorWithStatus:@"网络不可用"];
                return;
            }
            [self uploadPhotoFromAllArray];
            
        }else{
            
            [SVProgressHUD showErrorWithStatus:@"请上传资料"];
        }
        
    }else{//用户拒绝上传照片
        
        
        [self usertRefuse];
        
    }
    
    
    
    NSLog(@"完成按钮点击事件");
}

#pragma mark--图片上传到服务器并拿到图片路径
-(void)uploadPhotoFromAllArray{
    
    __weak __typeof (self) weakSelf = self;
    
    static  NSInteger num = 0;
    [SVProgressHUD showWithStatus:[NSString stringWithFormat:@"图片上传%d/%d",(int)num + 1,(int)_allArr.count]];
    [[FZJALAPhotosTool standardFZJALAPhotosTool] getFullScreenImageByALAssetUrl:[_allArr[num] url] Completion:^(UIImage *image) {
        if (image) {
            NSData * data = UIImageJPEGRepresentation(image, 0.1);
            [AFNConnection UploadPhotoPath:[NSString stringWithFormat:@"%@%@",IPDERSS,UPLOADPHOTO] body:nil data:data block:^(id backData) {
                
                if ([[backData objectForKey:@"status"] intValue]) {
                    
                    [weakSelf.photoPath addObject:[[backData objectForKey:@"result"] objectForKey:@"path"]];
                    NSLog(@"%@",_photoPath);
                    if (num != _allArr.count - 1) {
                        num ++;
                        [weakSelf performSelector:@selector(uploadPhotoFromAllArray)];
                    }else{
                        num = 0;
                        [weakSelf uploadHistoyData];
                        [SVProgressHUD showWithStatus:@"资料上传..."];
                    }
                }else{
                    num = 0;
                    [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
                    NSLog(@"--%@",[backData objectForKey:@"msg"]);
                }
            } error:^(NSError *error) {
                num = 0;
                [SVProgressHUD showErrorWithStatus:@"图片上传失败"];
                NSLog(@"图片上传到服务器并拿到图片路径error:%@",error);
            }];
        }

    }];
}
#pragma mark --- 上传资料
-(void)uploadHistoyData{
    
    __weak __typeof(self)weakSelf = self;
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    
    
    /**
     *  分别存放三种图片的路径 方便上传资料
     */
    NSMutableArray * arrOne = [NSMutableArray array];
    NSMutableArray * arrTwo = [NSMutableArray array];
    NSMutableArray * arrThree = [NSMutableArray array];
    
    for (int i = 0; i < _photoPath.count; i ++) {
        if (i < _photoArrTwo.count) {
            [arrOne addObject:_photoPath[i]];
        }else if(i < _photoArrTwo.count + _photoArrThree.count ){
            [arrTwo addObject:_photoPath[i]];
        }else{
            [arrThree addObject:_photoPath[i]];
        }
    }
    
    
    NSMutableArray * keys = [NSMutableArray arrayWithObjects:@"orderid",@"fromtype",@"userid",@"servicerid",@"patientname",@"hospitalid",@"hospitalname",@"visitingtime",@"advice",@"caspic",@"prepic",@"drugpic",nil];
    
    NSMutableArray * values = [NSMutableArray arrayWithObjects:[_detailOrder objectForKey:@"id"],@2,@([[_detailOrder objectForKey:@"userId"] intValue]),@([[StateManager defaultManager].userId intValue]),[_detailOrder objectForKey:@"patientName"],@([[_detailOrder objectForKey:@"hospitalId"] intValue]),[_detailOrder objectForKey:@"hospitalName"],[_detailOrder objectForKey:@"startTime"],_textView.text,arrOne,arrTwo,arrThree, nil];
    
    if (!self.serviceEnd) {//表示修改健康档案
        [keys addObject:@"recordid"];
        [values addObject:@([[_detailOrder objectForKey:@"healthRecord"] intValue])];
        
        [keys removeObject:@"orderid"];
        [values removeObject:[_detailOrder objectForKey:@"id"]];
    }
    
    NSDictionary * dic = [NSDictionary dictionaryWithObjects:values forKeys:keys];
    NSLog(@"--%@",dic);
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,HEALTH] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {//资料上传成功的话 更改审核状态
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (weakSelf.serviceEnd && weakSelf.block) {
                    weakSelf.block(YES);
                }
                NSArray * arr = weakSelf.navigationController.viewControllers;
                [weakSelf.navigationController popToViewController:arr[1] animated:YES];
            });
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
            NSLog(@"--%@",[backData objectForKey:@"msg"]);
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"上传失败"];
        NSLog(@"上传健康档案error:%@",error);
    }];
    
}
-(void)usertRefuse{
    __weak __typeof(self) weakSelf = self;
    //    用户拒绝上传（新增健康档案）（需要字段）订单id，客户id，服务人员id，fromtype，"refusesub":4（必须为4）
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:[_detailOrder objectForKey:@"id"] forKey:@"orderid"];//订单id
    [dic setObject:@([[_detailOrder objectForKey:@"userId"] intValue]) forKey:@"userid"];
    [dic setObject:@([[StateManager defaultManager].userId intValue]) forKey:@"servicerid"];
    [dic setObject:@4 forKey:@"refusesub"];
    
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,HEALTH] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                NSArray * arr = weakSelf.navigationController.viewControllers;
                [weakSelf.navigationController popToViewController:arr[1] animated:YES];
            });
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"失败"];
    }];
    
}
-(void)returnSuccessState:(uploadSuccess)stateBlock{
    self.block = stateBlock;
}
#pragma mark--
#pragma mark  代理
#pragma mark--textView代理方法
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if (![text isEqualToString:@""]) {
        _bgTextView.hidden = YES;
    }
    if ([text isEqualToString:@""] && range.length == 1 && range.location == 0) {
        _bgTextView.hidden = NO;
    }
    return YES;
}

#pragma mark--
#pragma mark 通知注册及销毁
-(void)registerCompleteDataControllerNotificationCenter{
}
-(void)dealloc{

    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end



//
//  historyCheckViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/19.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface historyCheckViewController : UIViewController
@property(nonatomic,strong)NSDictionary * detailOrder;
@property(nonatomic,strong)NSDictionary * dic;
@end

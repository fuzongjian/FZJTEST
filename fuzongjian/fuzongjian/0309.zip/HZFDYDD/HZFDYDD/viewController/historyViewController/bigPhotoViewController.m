//
//  bigPhotoViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/24.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "bigPhotoViewController.h"

#import "ZLBigImageCell.h"





@import PhotosUI;//一定要加

@interface bigPhotoViewController()<UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate>
@property(nonatomic,assign)NSInteger number;//当前是第几张图片
@property(nonatomic,strong)UILabel * middle;//导航栏中间动态显示图片张数
@property(nonatomic,strong)UIButton * rightBtn;//右边按钮
@property(nonatomic,assign)NSInteger sum;//照片的总数

@property(nonatomic,strong)UIScrollView * myScroll;
@property(nonatomic,strong)UICollectionView * collect;

@property(nonatomic,strong)UIScrollView * selectScroll;
@property(nonatomic,strong)NSMutableArray * NewBigPhoto;

@property CGRect previousPreheatRect;
@property (nonatomic, strong) PHCachingImageManager *imageManager;



@end

@implementation bigPhotoViewController


-(void)viewDidLoad{
    [super viewDidLoad];
    [self configBigPhotoViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configBigPhotoViewControllerUI{
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;

    _sum = _bigPhotoArr.count;
    _NewBigPhoto = [NSMutableArray arrayWithArray:_bigPhotoArr];
    
    [self initNav];
    [self initCollection];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [_collect setContentOffset:CGPointMake(_clickNum * (SCREEN_WIDTH + 30), 0)];
}
-(void)initCollection{
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.minimumLineSpacing = 30;
    layout.sectionInset = UIEdgeInsetsMake(0, 15, 0, 15);
    layout.itemSize = self.view.bounds.size;
    
    _collect = [[UICollectionView alloc]initWithFrame:CGRectMake(-15, 0,SCREEN_WIDTH + 30, SCREEN_HEIGHT) collectionViewLayout:layout];
    [_collect registerNib:[UINib nibWithNibName:@"ZLBigImageCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    _collect.dataSource = self;
    _collect.delegate = self;
    _collect.pagingEnabled = YES;
    [self.view addSubview:_collect];
    
}
-(void)initNav{
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(bigPhotoBackBtn) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    
    UILabel * titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, FIXWIDTHORHEIGHT(100), 44)];
    titleLable.text = [NSString stringWithFormat:@"1/%d",(int)_NewBigPhoto.count];
    titleLable.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLable;
    _middle = titleLable;
    
    _rightBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    _rightBtn.frame = CGRectMake(0, 0, 44, 44);
    [_rightBtn setTitle:@"删除" forState:UIControlStateNormal];
    _rightBtn.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [_rightBtn addTarget:self action:@selector(rightBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:_rightBtn];
    
}
#pragma mark--
#pragma mark 数据请求
-(void)returnBlock:(returnPhotoArr )block{
    self.returnBlock = block;
}
-(void)returnQulityBlock:(returnPhotoArr)block{
    self.qulityBlock = block;
}
#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)bigPhotoBackBtn{
    
    if (self.qulityBlock != nil && self.qualityState) {
        
        self.qulityBlock(_bigPhotoArr);
        
    }
    
    if (self.returnBlock != nil && !self.qualityState) {
        
        self.returnBlock(_bigPhotoArr);
        
    }

    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark--右边按钮点击事件
-(void)rightBtnClicked:(UIButton *)btn{
    [_bigPhotoArr removeObjectAtIndex:_number];
    if (_bigPhotoArr.count) {
        [_collect reloadData];
        _middle.text = [NSString stringWithFormat:@"%d/%d",(int)(_number + 1),(int)_bigPhotoArr.count];
    }else{
        [self bigPhotoBackBtn];
    }
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _bigPhotoArr.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ZLBigImageCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.imageView.image = nil;
    PHAsset * asset = _bigPhotoArr[indexPath.row];
    [cell showIndicator];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:asset size:PHImageManagerMaximumSize resizeMode:PHImageRequestOptionsResizeModeNone completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.imageView.image = result;
                [cell hideIndicator];
            });
        }];
    });
    cell.scrollView.delegate = self;
    [self addDoubleTapOnScrollView:cell.scrollView];
    return cell;
}
#pragma mark--添加单击、双击手势
- (void)addDoubleTapOnScrollView:(UIScrollView *)scrollView{
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapAction:)];
    [scrollView addGestureRecognizer:singleTap];
    
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapAction:)];
    doubleTap.numberOfTapsRequired = 2;
    [scrollView addGestureRecognizer:doubleTap];
    
    [singleTap requireGestureRecognizerToFail:doubleTap];
}
#pragma mark--单击判断隐藏状态栏
- (void)singleTapAction:(UITapGestureRecognizer *)tap
{
    if (self.navigationController.navigationBar.isHidden) {
        [self showStatusBarAndNavBar];
    } else {
        [self hidStatusBarAndNavBar];
    }
}
#pragma mark--双击放大
- (void)doubleTapAction:(UITapGestureRecognizer *)tap{
    UIScrollView *scrollView = (UIScrollView *)tap.view;
    _selectScroll = scrollView;
    CGFloat scale = 1;
    if (scrollView.zoomScale != 3.0) {
        scale = 3;
    } else {
        scale = 1;
    }
    CGRect zoomRect = [self zoomRectForScale:scale withCenter:[tap locationInView:tap.view]];
    [scrollView zoomToRect:zoomRect animated:YES];
}
- (CGRect)zoomRectForScale:(float)scale withCenter:(CGPoint)center
{
    CGRect zoomRect;
    zoomRect.size.height = _selectScroll.frame.size.height / scale;
    zoomRect.size.width  = _selectScroll.frame.size.width  / scale;
    zoomRect.origin.x    = center.x - (zoomRect.size.width  /2.0);
    zoomRect.origin.y    = center.y - (zoomRect.size.height /2.0);
    return zoomRect;
}
#pragma mark - UICollectionViewDelegate
-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    ZLBigImageCell * newCell = (ZLBigImageCell *)cell;
    newCell.scrollView.zoomScale = 1;
}

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{//返回一个放大或者缩小的视图  多次执行（0可放大或缩小）

    return scrollView.subviews[0];
    
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == (UIScrollView *)_collect) {
        //改变标题名字
        _number = scrollView.contentOffset.x / (SCREEN_WIDTH + 30);
        _middle.text = [NSString stringWithFormat:@"%d/%d",(int)(_number + 1),(int)_bigPhotoArr.count];
    }
}

#pragma mark - 显示隐藏导航条状态栏
- (void)showStatusBarAndNavBar
{
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
}

- (void)hidStatusBarAndNavBar
{
    self.navigationController.navigationBar.hidden = YES;
    [UIApplication sharedApplication].statusBarHidden = YES;
}


#pragma mark--
#pragma mark 通知注册及销毁


@end

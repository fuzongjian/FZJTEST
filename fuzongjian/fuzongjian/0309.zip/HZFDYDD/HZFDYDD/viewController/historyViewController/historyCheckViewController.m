//
//  historyCheckViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/19.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "historyCheckViewController.h"
#import "completeDataController.h"
#import "historyCheckCell.h"
#import "UIImageView+WebCache.h"
#import "InternetImageController.h"
#import "DisplayCollectionViewCell.h"
#import "UnderComleteDataViewController.h"
@interface historyCheckViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
@property(nonatomic,strong)UITextView * bgTextView;
@property(nonatomic,strong)UICollectionView * collectOne;
@property(nonatomic,strong)UICollectionView * collectTwo;
@property(nonatomic,strong)UICollectionView * collectThree;

@property(nonatomic,strong)NSMutableArray * arrryOne;
@property(nonatomic,strong)NSMutableArray * arrayTwo;
@property(nonatomic,strong)NSMutableArray * arrayThree;

@property(nonatomic,strong) UIScrollView * scrollViewOne;
@property(nonatomic,strong) UIScrollView * scrollViewTwo;
@property(nonatomic,strong) UIScrollView * scrollViewThree;

@end
@implementation historyCheckViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self loadHistoryCheckViewControllerData];
}
-(void)viewDidLoad{
    [super viewDidLoad];
    [self configCheckViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configCheckViewControllerUI{
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    _arrayThree = [NSMutableArray array];
    _arrayTwo = [NSMutableArray array];
    _arrryOne = [NSMutableArray array];
    
    //设置标题
    self.navigationItem.titleView = [Tool setCustomViewTitle:@"就诊资料详情"];
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(historyBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    
    //创建一个scrollView充当容器
    
    float height = 135,margin = 0;
    if (iPHone6) {
        
        margin = 90;
    }
    if (iPHone6Plus) {
        
        margin = 140;
    }
    
    UIScrollView * scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(3), SCREEN_WIDTH, SCREEN_HEIGHT - FIXWIDTHORHEIGHT(3))];
    scroll.backgroundColor = RGBCOLOR(240, 240, 240);
    scroll.contentSize = CGSizeMake(SCREEN_WIDTH, FIXWIDTHORHEIGHT(height * 4 + 40 + 50 + margin));
    [self.view addSubview:scroll];
    
    //定义标题字体大小、颜色、标题与图标的间隔
    float dataFontSize = FIXWIDTHORHEIGHT(15);
    float marginWidth = FIXWIDTHORHEIGHT(7);
    UIColor * dataColor = RGBCOLOR(46, 46, 46);

#pragma mark--医嘱
    /*   医嘱   */
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    bgViewOne.userInteractionEnabled = YES;
    [scroll addSubview:bgViewOne];
    
    //分割线
    UIView * viewOne = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewOne.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewOne addSubview:viewOne];
    
    //头标题和图标
    UIImageView * imageOne = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageOne.image = [UIImage imageNamed:@"advice"];
    [bgViewOne addSubview:imageOne];
    UILabel * lableOne = [[UILabel alloc]initWithFrame:CGRectMake(imageOne.origin.x + imageOne.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableOne.text = @"医嘱";
    lableOne.font = [UIFont systemFontOfSize:dataFontSize];
    lableOne.textColor = dataColor;
    [bgViewOne addSubview:lableOne];
    
    //就医情况描述
    _bgTextView = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), viewOne.origin.y + FIXWIDTHORHEIGHT(5), bgViewOne.size.width - FIXWIDTHORHEIGHT(40), bgViewOne.size.height - viewOne.origin.y - FIXWIDTHORHEIGHT(15))];
    _bgTextView.font = [UIFont systemFontOfSize:dataFontSize];
    _bgTextView.textColor = RGBCOLOR(160, 160, 160);
    _bgTextView.text = @"就医者本次就医情况描述";
    _bgTextView.editable = NO;
    [bgViewOne addSubview:_bgTextView];

    
#pragma mark--病历照
    /*   病例照   */
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 1), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    bgViewTwo.userInteractionEnabled = YES;
    bgViewTwo.tag = 10000;
    [scroll addSubview:bgViewTwo];
    //分割线
    UIView * viewTwo = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewTwo.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewTwo addSubview:viewTwo];
    //头标题和图标
    UIImageView * imageTwo = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageTwo.image = [UIImage imageNamed:@"report"];
    [bgViewTwo addSubview:imageTwo];
    UILabel * lableTwo = [[UILabel alloc]initWithFrame:CGRectMake(imageTwo.origin.x + imageTwo.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableTwo.text = @"病历照";
    lableTwo.font = [UIFont systemFontOfSize:dataFontSize];
    lableTwo.textColor = dataColor;
    [bgViewTwo addSubview:lableTwo];
    
    
//    __weak historyCheckViewController * weakSelf = self;//block避免循环引用
//    [weakSelf addScrollViewOneToImageView:bgViewTwo completion:^(UIScrollView *scroll) {
//        _scrollViewOne = scroll;
//        [weakSelf addGestureToScrollView:_scrollViewOne andNum:0];
//    }];
    
    [self addCollectionViewToImageView:bgViewTwo Completion:^(UICollectionView *collect) {
        _collectOne = collect;
    }];
#pragma mark--处方照
    /*   处方照   */
    UIImageView * bgViewThree = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 2), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewThree.image = [UIImage imageNamed:@"bg-5"];
    bgViewThree.userInteractionEnabled = YES;
    bgViewThree.tag = 10001;
    [scroll addSubview:bgViewThree];
    //分割线
    UIView * viewThree = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewThree.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewThree addSubview:viewThree];
    //头标题和图标
    UIImageView * imageThree = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageThree.image = [UIImage imageNamed:@"prescription"];
    [bgViewThree addSubview:imageThree];
    UILabel * lableThree = [[UILabel alloc]initWithFrame:CGRectMake(imageThree.origin.x + imageThree.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableThree.text = @"处方照";
    lableThree.font = [UIFont systemFontOfSize:dataFontSize];
    lableThree.textColor = dataColor;
    [bgViewThree addSubview:lableThree];
    
//    [weakSelf addScrollViewOneToImageView:bgViewThree completion:^(UIScrollView *scroll) {
//        _scrollViewTwo = scroll;
//        [weakSelf addGestureToScrollView:_scrollViewTwo andNum:1];
//    }];
    [self addCollectionViewToImageView:bgViewThree Completion:^(UICollectionView *collect) {
        _collectTwo = collect;
    }];
#pragma mark--药品照
    /*   药品照   */
    UIImageView * bgViewFour = [[UIImageView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(height * 3), SCREEN_WIDTH, FIXWIDTHORHEIGHT(height))];
    bgViewFour.image = [UIImage imageNamed:@"bg-5"];
    bgViewFour.userInteractionEnabled = YES;
    bgViewThree.tag = 10002;
    [scroll addSubview:bgViewFour];
    //分割线
    UIView * viewFour = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewFour.backgroundColor = RGBCOLOR(241, 240, 241);
    [bgViewFour addSubview:viewFour];
    //头标题和图标
    UIImageView * imageFour = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(11.5), FIXWIDTHORHEIGHT(17), FIXWIDTHORHEIGHT(17))];
    imageFour.image = [UIImage imageNamed:@"medicals"];
    [bgViewFour addSubview:imageFour];
    UILabel * lableFour = [[UILabel alloc]initWithFrame:CGRectMake(imageFour.origin.x + imageFour.size.width + marginWidth, 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40))];
    lableFour.text = @"药品照";
    lableFour.font = [UIFont systemFontOfSize:dataFontSize];
    lableFour.textColor = dataColor;
    [bgViewFour addSubview:lableFour];
//    [weakSelf addScrollViewOneToImageView:bgViewFour completion:^(UIScrollView *scroll) {
//        _scrollViewThree = scroll;
//        [weakSelf addGestureToScrollView:_scrollViewThree andNum:2];
//    }];
    [self addCollectionViewToImageView:bgViewFour Completion:^(UICollectionView *collect) {
        _collectThree = collect;
    }];
    /*   修改就诊资料按钮   */
    UIButton * finish = [UIButton buttonWithType:UIButtonTypeCustom];
    finish.frame = CGRectMake(FIXWIDTHORHEIGHT(30), bgViewFour.bottom + FIXWIDTHORHEIGHT(25), SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    [finish setTitle:@"修改就诊资料" forState:UIControlStateNormal];
    [finish setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    finish.backgroundColor = [UIColor redColor];
    finish.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    finish.layer.masksToBounds = YES;
    finish.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(18)];
    [finish addTarget:self action:@selector(revise) forControlEvents:UIControlEventTouchUpInside];
    [scroll addSubview:finish];
    
}
//创建ScrollView
-(void)addScrollViewOneToImageView:(UIImageView *)imageView completion:(void(^)(UIScrollView * scroll))completion{
    UIScrollView * scrollView = [[UIScrollView alloc] init];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.bounces = YES;
    scrollView.frame = CGRectMake(FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(40), imageView.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(90));
    scrollView.contentSize = CGSizeMake(imageView.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(90));
    [imageView addSubview:scrollView];
    completion(scrollView);
}

-(void)addCollectionViewToImageView:(UIImageView *)imageView Completion:(void(^)(UICollectionView * collect))completion{

    UICollectionViewFlowLayout * flowLayOut = [[UICollectionViewFlowLayout alloc] init];
    
    [flowLayOut setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    
    UICollectionView * collection = [[UICollectionView alloc] initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(40), imageView.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(90)) collectionViewLayout:flowLayOut];
    [imageView addSubview:collection];
    collection.showsHorizontalScrollIndicator = NO;
    collection.delegate = self;
    collection.dataSource = self;
    collection.backgroundColor = [UIColor whiteColor];
    [collection registerClass:[historyCheckCell class] forCellWithReuseIdentifier:@"cell"];
    [collection registerNib:[UINib nibWithNibName:@"DisplayCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"display"];
    completion(collection);
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载
-(void)loadHistoryCheckViewControllerData{
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    
    [SVProgressHUD showWithStatus:@"数据加载中..."];
    NSLog(@"-101-%@",self.detailOrder);//
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,HEALTHINFO] body:[NSDictionary dictionaryWithObject:[self.detailOrder objectForKey:@"healthRecord"] forKey:@"recordid"] block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD dismiss];
            NSLog(@"%@",backData);
            [self reloadData:[backData objectForKey:@"result"]];
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"查看失败"];
    }];
}
-(void)reloadData:(NSDictionary *)dic{
    
    _arrryOne = [NSMutableArray arrayWithArray:[dic objectForKey:@"caspic"]];
    _arrayTwo = [NSMutableArray arrayWithArray:[dic objectForKey:@"prepic"]];
    _arrayThree = [NSMutableArray arrayWithArray:[dic objectForKey:@"drugpic"]];
    
    _bgTextView.text = [[dic objectForKey:@"record"] objectForKey:@"doctorAdvice"];
    _bgTextView.textColor = [UIColor blackColor];
    [_collectOne reloadData];
    [_collectTwo reloadData];
    [_collectThree reloadData];
    
}
-(void)tapOneBtn:(NSInteger)clickNum{
    NSLog(@"tapOneBtn");
    if (_arrryOne.count != 0) {
        [self internetBigPhotoView:_arrryOne ClickNum:clickNum];
    }
}
-(void)tapTwoBtn:(NSInteger)clickNum{
    NSLog(@"tapTwoBtn");
    if (_arrayTwo.count != 0) {
        [self internetBigPhotoView:_arrayTwo ClickNum:clickNum];
    }
}
-(void)tapThreeBtn:(NSInteger)clickNum{
    NSLog(@"tapThreeBtn");
    if (_arrayThree.count != 0) {
        [self internetBigPhotoView:_arrayThree ClickNum:clickNum];
    }
}
-(void)internetBigPhotoView:(NSMutableArray *)photoArr ClickNum:(NSInteger)clickNum{
    InternetImageController * internet = [[InternetImageController alloc] init];
    internet.photoArr = photoArr;
    internet.clickNum = clickNum;
    [self.navigationController pushViewController:internet animated:YES];
}
#pragma mark--
#pragma mark 事件
#pragma mark--返回按钮
-(void)historyBackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark --- 修改就诊资料<判断手机系统，跳转不同的选择器>
-(void)revise{
    
    if (IOSVERSION >= 8.0) {
        completeDataController * completeData = [[completeDataController alloc]init];
        completeData.detailOrder = _detailOrder;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:completeData animated:YES];
    }else{
        UnderComleteDataViewController * under = [[UnderComleteDataViewController alloc] init];
        under.detailOrder = _detailOrder;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:under animated:YES];
    }
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    if (collectionView == _collectOne) {
        return _arrryOne.count;
    }else if (collectionView == _collectTwo){
        return _arrayTwo.count;
    }else{
        return _arrayThree.count;
    }
    
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    DisplayCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"display" forIndexPath:indexPath];
    cell.ImageView.image = nil;
    if (collectionView == _collectOne) {
        [cell.ImageView sd_setImageWithURL:[NSURL URLWithString:_arrryOne[indexPath.row]] placeholderImage:nil];
    }else if(collectionView == _collectTwo){
        [cell.ImageView sd_setImageWithURL:[NSURL URLWithString:_arrayTwo[indexPath.row]] placeholderImage:nil];
    }else{
        [cell.ImageView sd_setImageWithURL:[NSURL URLWithString:_arrayThree[indexPath.row]] placeholderImage:nil];
    }
    
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (collectionView ==_collectOne) {
        [self tapOneBtn:indexPath.row];
    }else if (collectionView == _collectTwo){
        [self tapTwoBtn:indexPath.row];
    }else{
        [self tapThreeBtn:indexPath.row];
    }
}
/**
 *  单元格的大小
 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake(FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
}
/**
 *  上下左右的间隔
 */
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(5));//上左下右
    
}
/**
 *  单元格最小间距
 */
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return FIXWIDTHORHEIGHT(5);
}
/**
 *  单元格最小行距
 */
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return FIXWIDTHORHEIGHT(5);
}

-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    NSLog(@"didReceiveMemoryWarning----");
}


#pragma mark--
#pragma mark 通知注册及销毁
#pragma mark--弹出提示窗口
@end

//
//  bigPhotoViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/24.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@import UIKit;
@import Photos;


typedef  void (^returnPhotoArr)(NSMutableArray * arr);

@interface bigPhotoViewController : UIViewController
@property(nonatomic,strong)NSMutableArray * bigPhotoArr;

@property(nonatomic,assign)BOOL qualityState;

@property(nonatomic,assign)NSInteger clickNum;

@property(nonatomic,copy)returnPhotoArr  returnBlock;

@property(nonatomic,copy)returnPhotoArr qulityBlock;

-(void)returnBlock:(returnPhotoArr )block;

-(void)returnQulityBlock:(returnPhotoArr)block;

@end

//
//  chooseDetailCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/22.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "chooseDetailCell.h"

@interface chooseDetailCell ()

@end

@implementation chooseDetailCell
- (void)setThumbnailImage:(UIImage *)thumbnailImage {
    
    _thumbnailImage = thumbnailImage;
    self.bgView.image = thumbnailImage;
    
}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self configChooseDetailCellUI];
        
    }
    return self;
}
-(void)configChooseDetailCellUI{
    
    
    self.state = NO;
    
    CGRect frame ;
   
    if (iPHone6) {
        frame = CGRectMake(0, 0, 87, 87);
    }else if (iPHone6Plus){
        frame = CGRectMake(0, 0, 97, 97);
    }else{
        frame = CGRectMake(0, 0, 100, 100);
    }
       
    _bgView = [[UIImageView alloc]initWithFrame:frame];
    _bgView.image = [UIImage imageNamed:@"logo1"];
    [self addSubview:_bgView];
    
    CGFloat size = 20;
    
    _cellBtn = [UIButton createCustomButton];
    _cellBtn.frame = CGRectMake(_bgView.origin.x + _bgView.size.width - FIXWIDTHORHEIGHT(size), 0, FIXWIDTHORHEIGHT(size), FIXWIDTHORHEIGHT(size));
    [_cellBtn setNormalImage:[UIImage imageNamed:@"No"]];
    [_cellBtn setSelectedImage:[UIImage imageNamed:@"YES"]];
    [self addSubview:_cellBtn];
#warning 修改-----
//    _btnN = [UIButton buttonWithType:UIButtonTypeSystem];
//    _btnN.frame = CGRectMake(_bgView.origin.x + _bgView.size.width - FIXWIDTHORHEIGHT(size), 0, FIXWIDTHORHEIGHT(size), FIXWIDTHORHEIGHT(size));
//    [_btnN setBackgroundImage:[UIImage imageNamed:@"No"] forState:UIControlStateNormal];
//    [_btnN addTarget:self action:@selector(btnNClicked) forControlEvents:UIControlEventTouchUpInside];
//    [self addSubview:_btnN];
//    
//    _btnY = [UIButton buttonWithType:UIButtonTypeSystem];
//    _btnY.frame = CGRectMake(_bgView.origin.x + _bgView.size.width - FIXWIDTHORHEIGHT(size), 0, FIXWIDTHORHEIGHT(size), FIXWIDTHORHEIGHT(size));
//    [_btnY setBackgroundImage:[UIImage imageNamed:@"YES"] forState:UIControlStateNormal];
//    [self addSubview:_btnY];
//    [_btnY addTarget:self action:@selector(btnYClicked) forControlEvents:UIControlEventTouchUpInside];
//    _btnY.hidden = YES;
    
}
-(void)btnNClicked{
    
    _btnN.hidden = YES;
    _btnY.hidden = NO;
    self.state = YES;
    
    if (_cellDelegate != nil && [_cellDelegate respondsToSelector:@selector(customBtnClicked:)]) {
        
        [_cellDelegate customBtnClicked:_cellRow];
        
    }
}
-(void)btnYClicked{
    _btnN.hidden = NO;
    _btnY.hidden = YES;
    
    self.state = NO;
    
    if (_cellDelegate != nil && [_cellDelegate respondsToSelector:@selector(customBtnClicked:)]) {
        
        [_cellDelegate customBtnClicked:_cellRow];
        
    }
    
}
@end

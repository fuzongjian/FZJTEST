//
//  chooseViewController.h
//  FZJChoosePhoto
//
//  Created by fdkj0002 on 15/12/21.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chooseViewController : UIViewController
@property(nonatomic,strong)NSDictionary * data;
@property(nonatomic,strong)NSArray * arr;
@property(nonatomic,assign)NSInteger addNum;


@property(nonatomic,assign)BOOL serviceEnd;

@property(nonatomic,copy)void(^superReturnPhotoArray)(NSMutableArray * array);


@end

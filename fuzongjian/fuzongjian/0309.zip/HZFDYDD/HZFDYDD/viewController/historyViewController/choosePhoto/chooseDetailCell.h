//
//  chooseDetailCell.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/22.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>


/*定义一个协议来区分表格的点击事件和表格上按钮的点击事件*/

@protocol customCellBtnClicked <NSObject>

-(void)customBtnClicked:(NSInteger)cellRow;

@end

@interface chooseDetailCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView * bgView;
@property(nonatomic,assign)BOOL state;
@property(nonatomic,strong)UIButton * btnN;
@property(nonatomic,strong)UIButton * btnY;

@property(nonatomic,strong)UIButton * cellBtn;



@property (nonatomic, copy) NSString *representedAssetIdentifier;
@property (nonatomic, strong) UIImage *thumbnailImage;
@property (nonatomic, strong) UIImage *livePhotoBadgeImage;


/*定义相关属性，记录点击的行数*/
@property(nonatomic,assign)id<customCellBtnClicked>cellDelegate;
@property(nonatomic,assign)NSInteger cellRow;

@end

//
//  chooseDetailController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/22.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

@import UIKit;
@import Photos;

@interface chooseDetailController : UIViewController

@property(nonatomic,strong)PHFetchResult * fetchResult;
@property(nonatomic,strong)NSString * detailTitle;
@property(nonatomic,strong)NSMutableArray * dataArray;
@property(nonatomic,assign)NSInteger addNum;//本次最多可选择
@property(nonatomic,copy)void(^superReturnPhotoArray)(NSMutableArray * array);
@property(nonatomic,assign)BOOL serviceEnd;

@end

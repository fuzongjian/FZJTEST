//
//  chooseDetailController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/22.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "chooseDetailController.h"
#import "chooseDetailCell.h"
#import "completeDataController.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import "NewBigPhotoViewController.h"

#import "chooseModel.h"

@import PhotosUI;//一定要加

@interface chooseDetailController ()<UICollectionViewDataSource,UICollectionViewDelegate,customCellBtnClicked>
@property(nonatomic,strong)UICollectionView * collect;
@property(nonatomic,strong)NSMutableArray * selectArr;
@property(nonatomic,strong)PHFetchResult * result;
@property(nonatomic,strong)NSMutableArray * dataArr;

@property(nonatomic,strong)UIView * toolView;//显示选择状态
@property(nonatomic,strong)UIButton * preview;
@property(nonatomic,strong)UIButton * finish;
@property(nonatomic,strong)UILabel * numLable;//显示张数


@property CGRect previousPreheatRect;
@property (nonatomic, strong) PHCachingImageManager *imageManager;

@end

@implementation chooseDetailController



-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    _toolView.alpha = 0;
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    _toolView.alpha = 1;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configChooseDetailControllerUI];
}
- (void)dealloc {
    
    //[[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
    
}
#pragma mark --
#pragma mark 初始化UI
-(void)configChooseDetailControllerUI{
    
    _selectArr = [NSMutableArray array];
    _dataArr = [NSMutableArray array];
    _result = [[PHFetchResult alloc]init];
    
    
    //设置标题
    self.view.backgroundColor = [UIColor whiteColor];
    UILabel * detail = [Tool setCustomViewTitle:self.detailTitle];
    detail.textColor = [UIColor blackColor];
    self.navigationItem.titleView = detail;
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(historyBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    
    //取消按钮设置
    UIButton  * cancle = [UIButton buttonWithType:UIButtonTypeSystem];
    cancle.frame = CGRectMake(0, 0, 44, 44);
    [cancle setTitle:@"取消" forState:UIControlStateNormal];
    cancle.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:cancle];
    [cancle addTarget:self action:@selector(cancleBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    //创建collectionVew
    UICollectionViewFlowLayout * flowLayOut = [[UICollectionViewFlowLayout alloc]init];
    [flowLayOut setScrollDirection: UICollectionViewScrollDirectionVertical];
    _collect = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 49) collectionViewLayout:flowLayOut];
    [self.view addSubview:_collect];
    _collect.delegate = self;
    _collect.dataSource = self;
    _collect.backgroundColor = [UIColor whiteColor];
    
    
    //注册
    [self.collect registerClass:[chooseDetailCell class] forCellWithReuseIdentifier:@"cell"];
    
    /*    照片完成和预览     */
    _toolView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 49, SCREEN_WIDTH, 49)];
    _toolView.backgroundColor = [UIColor whiteColor];
    [[UIApplication sharedApplication].keyWindow addSubview:_toolView];
    
    //显示选择张数
    UILabel * numLable = [[UILabel alloc]initWithFrame:CGRectMake(_toolView.size.width * 0.3, 0, _toolView.size.width * 0.4, 49)];
    numLable.text = [NSString stringWithFormat:@"0/%d",(int)self.addNum];
    numLable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    numLable.textAlignment = NSTextAlignmentCenter;
    numLable.textColor = [UIColor blueColor];
    [_toolView addSubview:numLable];
    _numLable = numLable;
    
    //完成按钮
    UIButton * finish = [UIButton buttonWithType:UIButtonTypeSystem];
    finish.frame = CGRectMake(SCREEN_WIDTH - 49, 0, 49, 49);
    [finish setTitle:@"完成" forState:UIControlStateNormal];
    finish.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [finish addTarget:self action:@selector(finishBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [_toolView addSubview:finish];
    _finish = finish;
    _finish.enabled = NO;
    
//    //预览按钮
//    UIButton * preview = [UIButton buttonWithType:UIButtonTypeSystem];
//    preview.frame = CGRectMake(5, 0, 30, 30);
//    preview.titleLabel.textAlignment = NSTextAlignmentCenter;
//    [preview setTitle:@"预览" forState:UIControlStateNormal];
//    preview.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(11)];
//    [preview addTarget:self action:@selector(previewBtnClicked) forControlEvents:UIControlEventTouchUpInside];
//    [_toolView addSubview:preview];
//    _preview = preview;
//    _preview.enabled = NO;
    
    
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark--返回按钮
-(void)historyBackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark--取消按钮设置
-(void)cancleBtnClicked{
    
    NSArray * arr = self.navigationController.viewControllers;
    
    [self.navigationController popToViewController:arr[2] animated:YES];
    
//    if (self.serviceEnd) {
//        
//    }else{
//        [self.navigationController popToViewController:arr[3] animated:YES];
//    }
    
}
#pragma mark--完成按钮设置
-(void)finishBtnClicked{
    
    if (self.superReturnPhotoArray) {
        self.superReturnPhotoArray(_selectArr);
    }
    
    
    NSArray * arr = self.navigationController.viewControllers;
    NSLog(@"---%@",arr);
    
    [self.navigationController popToViewController:arr[2] animated:YES];
    
//    if (self.serviceEnd) {
//        
//    }else{
//        [self.navigationController popToViewController:arr[2] animated:YES];
//    }

}



#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.fetchResult.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * identify = @"cell";
    chooseDetailCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
    [cell sizeToFit];
    if (!cell) {
        NSLog(@"------------");
    }
    
    chooseModel * model = _dataArray[indexPath.row];
    PHAsset *asset = model.asset;
    cell.representedAssetIdentifier = asset.localIdentifier;
    
    cell.bgView.contentMode = UIViewContentModeScaleAspectFill;
    cell.bgView.clipsToBounds = YES;//裁剪超出父视图范围的子视图部分   NO，不裁剪子视图

    CGSize size = cell.frame.size;
    size.width *= [UIScreen mainScreen].scale;
    size.height *= [UIScreen mainScreen].scale;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:_fetchResult[indexPath.row] size:size resizeMode:PHImageRequestOptionsResizeModeExact completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.bgView.image = result;
            });
        }];
    });
 
    
    cell.cellBtn.tag = indexPath.row;
    [cell.cellBtn addTarget:self action:@selector(cellBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    cell.cellBtn.selected = [self theSelectArrIsHaveCurrentAsset:[_fetchResult objectAtIndex:indexPath.row]];


    cell.cellDelegate = self;
    cell.cellRow = indexPath.row;
    
    
    if (model.selected) {
        cell.btnN.hidden = YES;
        cell.btnY.hidden = NO;
    }else{
        cell.btnN.hidden = NO;
        cell.btnY.hidden = YES;
    }
    
    return cell;
}
-(BOOL)theSelectArrIsHaveCurrentAsset:(PHAsset *)currentAsset{
    for (PHAsset * asset in _selectArr) {
        if ([[asset valueForKey:@"filename"] isEqualToString:[currentAsset valueForKey:@"filename"]]) {
            return YES;
        }
    }
    return NO;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (iPHone6) {
        return CGSizeMake(87, 87);
    }else if (iPHone6Plus){
        return CGSizeMake(97, 97);
    }else{
        return CGSizeMake(100, 100);
    }
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(5, 5, 0, 5);//上左下右
    
}
// 单元格最小间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}
// 单元格最小行距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NewBigPhotoViewController * newBig = [[NewBigPhotoViewController alloc] init];
    newBig.addNum = self.addNum;
    __weak __typeof(self)weakSelf = self;
    newBig.returnPhotoArray = ^(NSMutableArray * photoArray){
        weakSelf.selectArr = [NSMutableArray arrayWithArray:photoArray];
        [weakSelf.collect reloadData];
        [weakSelf uploadNumLable];
    };
    
    newBig.choosePhotoArray = self.selectArr;
    newBig.fetchResult = self.fetchResult;
    newBig.clickInteger = indexPath.row;
    newBig.detailTitle = self.detailTitle;
    [self.navigationController pushViewController:newBig animated:YES];
}
-(void)cellBtnClicked:(UIButton *)cellBtn{
    cellBtn.selected = !cellBtn.selected;
    if (cellBtn.selected) {
        [cellBtn.layer addAnimation:[AnimationTool addAnimateToButton] forKey:nil];
        if (_selectArr.count == _addNum) {
            cellBtn.selected = NO;
            [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"本次最多选择%d张",(int)_addNum]];
        }else{
            [_selectArr addObject:[_fetchResult objectAtIndex:cellBtn.tag]];
        }
    }else{
        [self search:[_fetchResult objectAtIndex:cellBtn.tag] WillDeleteAsset:^(PHAsset *asset) {
            [_selectArr removeObject:asset];
        }];
    }
    [self uploadNumLable];
}
-(void)search:(PHAsset *)searchAsset WillDeleteAsset:(void(^)(PHAsset * asset))completion{
    for (PHAsset * asset in _selectArr) {
        if ([[asset valueForKey:@"filename"] isEqualToString:[searchAsset valueForKey:@"filename"]]) {
            completion(asset);
            return;
        }
    }
}
-(void)uploadNumLable{
    
    if (_selectArr.count == 0) {
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _preview.enabled = NO;
        _finish.enabled = NO;
    }else{
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _preview.enabled = YES;
        _finish.enabled = YES;
    }
}
-(void)reloadData:(NSMutableArray *)array{
    
}
/*     实现自定义cell的协议方法    */
-(void)customBtnClicked:(NSInteger)cellRow{
    
    chooseModel * model = _dataArray[cellRow];
    
    PHAsset * asset = model.asset;
    //取到外面该行的cell
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:cellRow inSection:0];
    chooseDetailCell * cell = (chooseDetailCell *)[_collect cellForItemAtIndexPath:indexPath];

    if(cell.state && _selectArr.count == self.addNum){
        cell.btnN.hidden = NO;
        cell.btnY.hidden = YES;
        [self dontHaveNoAuthority:[NSString stringWithFormat:@"本次最多选择%d张",(int)self.addNum]];
    }else{
        if (_selectArr.count == 0) {
            
            model.selected = YES;
            [_selectArr addObject:asset];
            
        }else if(cell.state){//选中状态
            //遍历数组寻找该cell对应数据，如果数据没有则添加
            if(![self searchDataFrom:asset]){
                [_selectArr addObject:asset];
                model.selected = YES;
            }
            
        }else if (!cell.state){
            //遍历数组寻找该cell对应数据，如果数据有则删除
            if ([self searchDataFrom:asset]) {
                for (int i = (int)_selectArr.count - 1 ; i > 0 || i == 0; i --) {
                    
                    if ([[asset valueForKey:@"filename"] isEqualToString:[_selectArr[i] valueForKey:@"filename"]]) {
                        model.selected = NO;
                        [_selectArr removeObject:_selectArr[i]];
                    }
                }
            }
            
        }

    }
    
  
    if (_selectArr.count == 0) {
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _preview.enabled = NO;
        _finish.enabled = NO;
    }else{
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _preview.enabled = YES;
        _finish.enabled = YES;
    }
    
//    NSLog(@"点了第%d行的按钮",cellRow);
//    NSLog(@"--1--%d--%@",_selectArr.count,_selectArr);
    
}
-(BOOL)searchDataFrom:(PHAsset *)fetchResult{
    
    for (PHAsset * result in _selectArr) {
        if ([[result valueForKey:@"filename"] isEqualToString:[fetchResult valueForKey:@"filename"] ]) {
            return YES;
        }
    }
    return NO;
}


#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark--选择的照片超出了  弹出窗口
-(void)dontHaveNoAuthority:(NSString *)message{
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.9;
    bgView.tag = 41025787;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [bgView addSubview:popView];
    //    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    
    UIImageView * success = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, popView.size.height * 0.1, popView.size.width * 0.3, popView.size.width * 0.3)];
    success.image = [UIImage imageNamed:@"warning"];
    [popView addSubview:success];
    
    UILabel * warn = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(5),success.size.height, popView.size.width - FIXWIDTHORHEIGHT(10), popView.size.height - popView.size.width * 0.3)];
    warn.text = message;
    warn.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
    warn.numberOfLines = 0;
    warn.textAlignment = NSTextAlignmentCenter;
    [popView addSubview:warn];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapBtn:)];
    tap.numberOfTapsRequired = 1;
    [bgView addGestureRecognizer:tap];
    
}
-(void)tapBtn:(UITapGestureRecognizer *)tap{
    
    for (UIView * view in [UIApplication sharedApplication].keyWindow.subviews) {
        if (view.tag == 41025787) {
            [view removeFromSuperview];
        }
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  chooseViewController.m
//  FZJChoosePhoto
//
//  Created by fdkj0002 on 15/12/21.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "chooseViewController.h"
#import "chooseCustomCell.h"
#import "chooseDetailController.h"

#import "chooseModel.h"

#import <Photos/PHFetchResult.h>
#import <Photos/PHAsset.h>
#import <photos/PHImageManager.h>
@interface chooseViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView * chooseTable;
@property(nonatomic,strong)NSArray * titleArr;
@end

@implementation chooseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self configChooseViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configChooseViewControllerUI{
    self.view.backgroundColor = [UIColor whiteColor];
    
    //设置标题
    UILabel * album = [Tool setCustomViewTitle:@"相簿"];
    album.textColor = [UIColor blackColor];
    self.navigationItem.titleView = album;
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(historyBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    _chooseTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [self.view addSubview:_chooseTable];
    _chooseTable.dataSource = self;
    _chooseTable.delegate = self;
    _chooseTable.tableFooterView = [UIView new];
    _chooseTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    _titleArr = [self.data objectForKey:@"title"];

}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark--返回按钮
-(void)historyBackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _arr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * photo = @"photo";
    
    chooseCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:photo];
    if (!cell) {
        cell = [[chooseCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:photo];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSeparatorStyleNone;
    
    cell.iconImage.contentMode = UIViewContentModeScaleAspectFill;
    cell.iconImage.clipsToBounds = YES;
    
    
    PhotoAblumList * ablumList = _arr[indexPath.row];
    cell.title.text = ablumList.title;
    cell.subTitle.text = [NSString stringWithFormat:@"%d",(int)ablumList.count];
    CGSize size = CGSizeMake(80, 80);
    NSLog(@"----%.f",[UIScreen mainScreen].scale);
    size.width *= [UIScreen mainScreen].scale;
    size.height *= [UIScreen mainScreen].scale;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:ablumList.headImageAsset size:size resizeMode:PHImageRequestOptionsResizeModeExact completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                 cell.iconImage.image = result;
            });
        }];
    });
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return 100;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    chooseDetailController * chooseDetail = [[chooseDetailController alloc]init];
    
    PhotoAblumList * ablumList = _arr[indexPath.row];
    
    chooseDetail.detailTitle = ablumList.title;
    chooseDetail.serviceEnd = self.serviceEnd;
    
    chooseDetail.fetchResult = [[PhotoTool sharePhotoTool] fetchAssetsInAssetCollection:ablumList.assetCollection ascending:YES];
    
    PHFetchResult * fetch = [[PhotoTool sharePhotoTool] fetchAssetsInAssetCollection:ablumList.assetCollection ascending:YES];
    NSMutableArray * dataArr = [NSMutableArray array];
    for (PHAsset * asset in fetch) {
        chooseModel * model = [[chooseModel alloc]init];
        model.asset = asset;
        model.selected = NO;
        [dataArr addObject:model];
    }
    chooseDetail.dataArray = dataArr;
    chooseDetail.addNum = self.addNum;
    chooseDetail.superReturnPhotoArray = self.superReturnPhotoArray;
    
    [self.navigationController pushViewController:chooseDetail animated:YES];
    
//    imageDetailController * imageDetail = [[imageDetailController alloc]init];
//    imageDetail.fetchResult = [_data objectForKey:_titleArr[indexPath.row]];
//    imageDetail.detailTitle = _titleArr[indexPath.row];
//    [self presentViewController:imageDetail animated:YES completion:nil];
}
#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

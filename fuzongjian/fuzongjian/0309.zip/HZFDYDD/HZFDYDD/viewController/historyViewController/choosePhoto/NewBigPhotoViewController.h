//
//  NewBigPhotoViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/2.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderSuperViewController.h"

@interface NewBigPhotoViewController : UnderSuperViewController
@property(nonatomic,strong)PHFetchResult * fetchResult;
@property(nonatomic,copy)void(^returnPhotoArray)(NSMutableArray * array);
@property(nonatomic,strong)NSMutableArray * choosePhotoArray;
@property(nonatomic,assign)NSInteger clickInteger;
@property(nonatomic,assign)NSInteger addNum;

@property(nonatomic,strong)NSString * detailTitle;

@end

//
//  chooseCustomCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/22.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "chooseCustomCell.h"

@implementation chooseCustomCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configChooseCustomCellUI];
    }
    return  self;
}
-(void)configChooseCustomCellUI{
    
    _iconImage = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 80, 80)];
    _iconImage.image = [UIImage imageNamed:@"logo1"];
    _iconImage.layer.cornerRadius = 5;
    _iconImage.layer.masksToBounds = YES;
    [self.contentView addSubview:_iconImage];
    
    _title = [[UILabel alloc]initWithFrame:CGRectMake(110, 5, 150, 40)];
    _title.text = @"adf";
    _title.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [self.contentView addSubview:_title];
    
    _subTitle = [[UILabel alloc]initWithFrame:CGRectMake(110, 55, 150, 40)];
    _subTitle.text = @"adf";
    _subTitle.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(13)];
    [self.contentView addSubview:_subTitle];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

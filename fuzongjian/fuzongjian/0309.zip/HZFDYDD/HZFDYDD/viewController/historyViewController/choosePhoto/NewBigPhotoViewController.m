//
//  NewBigPhotoViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/2.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "NewBigPhotoViewController.h"
#import "FZJBigPhotoCell.h"

#define margin 30
@interface NewBigPhotoViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate>
@property(nonatomic,strong)UICollectionView * collect;
@property(nonatomic,strong)UILabel * titleLable;
@property(nonatomic,strong)UILabel * displayLable;
@property(nonatomic,strong)UIButton * select;
@property(nonatomic,assign)float current;
@property(nonatomic,strong)UIButton * rightBtn;
@end

@implementation NewBigPhotoViewController
-(void)viewWillAppear:(BOOL)animated{
    [_collect setContentOffset:CGPointMake(_clickInteger * (SCREEN_WIDTH + margin), 0)];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.minimumLineSpacing = 30;
    layout.sectionInset = UIEdgeInsetsMake(0, 15, 0, 15);
    layout.itemSize = self.view.bounds.size;
    
    _collect = [[UICollectionView alloc]initWithFrame:CGRectMake(-15, 0,SCREEN_WIDTH + 30, SCREEN_HEIGHT) collectionViewLayout:layout];
    [_collect registerNib:[UINib nibWithNibName:@"FZJBigPhotoCell" bundle:nil] forCellWithReuseIdentifier:@"BigPhotoCell"];
    _collect.dataSource = self;
    _collect.delegate = self;
    _collect.pagingEnabled = YES;
    [self.view addSubview:_collect];
    
    
    [self setBackButtonImage:@"back"];
    [self setTitleWithString:self.detailTitle];
    [self addDisplayLable];
    [self setSureButton];
    
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.fetchResult.count;
}
-(UICollectionViewCell * )collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    FZJBigPhotoCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigPhotoCell" forIndexPath:indexPath];
    cell.ImageView.image = nil;
    [cell showIndicator];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:self.fetchResult[indexPath.row] size:PHImageManagerMaximumSize resizeMode:PHImageRequestOptionsResizeModeNone completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.ImageView.image = result;
                [cell hideIndicator];
            });
        }];
    });
    _select.selected = [self currentPhoto:indexPath.row];
    cell.ScrollView.delegate = self;
    [self addGestureTapToScrollView:cell.ScrollView];
    return cell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == (UIScrollView *)self.collect) {
        CGFloat current = scrollView.contentOffset.x / (SCREEN_WIDTH + margin) + 1;
        _titleLable.text = [NSString stringWithFormat:@"%.f/%d",current,(int)self.fetchResult.count];
        _current = current - 1;
    }
}
-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    FZJBigPhotoCell * WillCell = (FZJBigPhotoCell *)cell;
    WillCell.ScrollView.zoomScale = 1;
}
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return scrollView.subviews[0];
}
-(void)addGestureTapToScrollView:(UIScrollView *)scrollView{
    UITapGestureRecognizer * singleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapOnScrollView:)];
    singleTap.numberOfTapsRequired = 1;
    [scrollView addGestureRecognizer:singleTap];
    
    UITapGestureRecognizer * doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTapOnScrollView:)];
    doubleTap.numberOfTapsRequired = 2;
    [scrollView addGestureRecognizer:doubleTap];
}
-(void)singleTapOnScrollView:(UITapGestureRecognizer *)singleTap{
    if (self.navigationController.navigationBar.isHidden) {
        [self showNavBarAndStatusBar];
    }else{
        [self hideNavBarAndStatusBar];
    }
}
-(void)showNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
}
-(void)hideNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = YES;
    [UIApplication sharedApplication].statusBarHidden = YES;
}
-(void)doubleTapOnScrollView:(UITapGestureRecognizer *)doubleTap{
    
    UIScrollView * scrollView = (UIScrollView *)doubleTap.view;
    CGFloat scale = 1;
    if (scrollView.zoomScale != 3) {
        scale = 3;
    }else{
        scale = 1;
    }
    [self CGRectForScale:scale WithCenter:[doubleTap locationInView:doubleTap.view] ScrollView:scrollView Completion:^(CGRect Rect) {
        [scrollView zoomToRect:Rect animated:YES];
    }];
}
-(void)CGRectForScale:(CGFloat)scale WithCenter:(CGPoint)center ScrollView:(UIScrollView *)scrollView Completion:(void(^)(CGRect Rect))completion{
    CGRect Rect;
    Rect.size.height = scrollView.frame.size.height / scale;
    Rect.size.width  = scrollView.frame.size.width  / scale;
    Rect.origin.x    = center.x - (Rect.size.width  /2.0);
    Rect.origin.y    = center.y - (Rect.size.height /2.0);
    completion(Rect);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setSureButton{
    UIButton * sure = [UIButton buttonWithType:UIButtonTypeCustom];
    _select = sure;
    sure.frame = CGRectMake(0, 0, 30, 30);
    [sure setBackgroundImage:[UIImage imageNamed:@"No"] forState:UIControlStateNormal];
    [sure setBackgroundImage:[UIImage imageNamed:@"YES"] forState:UIControlStateSelected];
    [sure addTarget:self action:@selector(sureBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:sure];
}
-(void)sureBtnClicked:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        [sender.layer addAnimation:[AnimationTool addAnimateToButton] forKey:nil];
        if (_choosePhotoArray.count == _addNum) {
            sender.selected = NO;
            [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"本次最多选择%d张",(int)_addNum]];
            return;
        }
        [self.choosePhotoArray addObject:[self.fetchResult objectAtIndex:(NSInteger)_current]];
        [self uploadDisplay];
    }else{
        for (PHAsset * asset in self.choosePhotoArray) {
            if ([[asset valueForKey:@"filename"] isEqualToString:[[self.fetchResult objectAtIndex:(NSInteger)_current] valueForKey:@"filename"]]) {
                [self.choosePhotoArray removeObject:asset];
                [self uploadDisplay];
                return;
            }
        }
    }
}

-(void)uploadDisplay{
    self.displayLable.text = [NSString stringWithFormat:@"%d/%d",(int)self.choosePhotoArray.count,(int)self.addNum];
}
-(void)setTitleLable{
    _titleLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    _titleLable.text = [NSString stringWithFormat:@"%d/%d",(int)self.clickInteger,(int)self.fetchResult.count];
    _titleLable.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = _titleLable;
}
-(void)addDisplayLable{
    
    UILabel * display = [[UILabel alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 44, SCREEN_WIDTH, 44)];
    display.font = [UIFont systemFontOfSize:20];
    display.textAlignment = NSTextAlignmentCenter;
    display.textColor = [UIColor blackColor];
    display.text = [NSString stringWithFormat:@"%d/%d",(int)self.choosePhotoArray.count,(int)self.addNum];
    display.backgroundColor = [UIColor whiteColor];
    _displayLable = display;
    [self.view addSubview:display];
    
}
-(BOOL)currentPhoto:(NSInteger)integer{
    for (PHAsset * asset in self.choosePhotoArray) {
        if ([[asset valueForKey:@"filename"] isEqualToString:[self.fetchResult[integer] valueForKey:@"filename"]]) {
            return YES;
        }
    }
    return NO;
}
-(void)superBackBtnClicked{
    if (self.returnPhotoArray && self.choosePhotoArray.count != 0) {
        self.returnPhotoArray(self.choosePhotoArray);
    }
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)rightBtnClicked:(UIButton *)btn{
    if (btn.selected) {
//        self.choosePhotoArray addObject:self
    }
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

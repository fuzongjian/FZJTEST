//
//  InternetImageController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/21.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "InternetImageController.h"
#import "UIImageView+WebCache.h"
#import "ZLBigImageCell.h"
#define margin 30

@interface InternetImageController ()<UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate>
/**
 *  大图展示以供选择
 */
@property(nonatomic,strong)UICollectionView * bigCollect;

@property(nonatomic,assign)NSInteger number;

@property(nonatomic,strong)UILabel * middleTitle;

@property(nonatomic,strong) UIButton * save;
@end

@implementation InternetImageController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configInternetImageControllerUI];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.bigCollect setContentOffset:CGPointMake((self.clickNum) * (SCREEN_WIDTH + margin), 0)];
    self.middleTitle.text = [NSString stringWithFormat:@"%d/%d",(int)self.clickNum + 1,(int)self.photoArr.count];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configInternetImageControllerUI{
    __weak __typeof(self) weakSelf = self;
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flowLayout.minimumLineSpacing = margin;
    flowLayout.sectionInset = UIEdgeInsetsMake(0, margin/2, 0, margin/2);
    flowLayout.itemSize = self.view.size;
    
    _bigCollect = [[UICollectionView alloc] initWithFrame:CGRectMake(-margin/2, 0, SCREEN_WIDTH + margin, SCREEN_HEIGHT) collectionViewLayout:flowLayout];
    [_bigCollect registerNib:[UINib nibWithNibName:@"ZLBigImageCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    _bigCollect.pagingEnabled = YES;
    _bigCollect.dataSource = self;
    _bigCollect.delegate = self;
    [self.view addSubview:_bigCollect];
    
    UILabel * title = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    title.text = [NSString stringWithFormat:@"1/%d",(int)self.photoArr.count];
    title.textAlignment = NSTextAlignmentCenter;
    _middleTitle = title;
    self.navigationItem.titleView = title;
    
    
    //返回按钮设置
    UIButton * back = [UIButton createCustomButtonImage:[UIImage imageNamed:@"back"]];
    back.frame = CGRectMake(0, 0, 30, 30);
    [back setClickAction:^{
        [weakSelf bigPhotoBackBtn];
    }];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:back];
    
    //保存按钮
    UIButton * save = [UIButton createSystemButtonTitle:@"保存"];
    save.frame = CGRectMake(0, 0, 50,30);
    [save setClickAction:^{
        [weakSelf savePhototoiPhone];
    }];
    _save = save;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:save];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)bigPhotoBackBtn{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)savePhototoiPhone{
    _save.enabled = NO;
    UIImage * cacheImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:_photoArr[_number]];
    if (cacheImage) {
        UIImageWriteToSavedPhotosAlbum(cacheImage, self , @selector(image:didFinishSavingWithError:contextInfo:), nil);//保存图片到照片库
    }
}
/**
 *  图片保存到本地后的回调
 */
- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo{
    if(!error){
        [SVProgressHUD showSuccessWithStatus:@"保存成功"];
    }else{
        [SVProgressHUD showErrorWithStatus:@"保存失败"];
        _save.enabled = YES;
    }
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.photoArr.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    ZLBigImageCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:self.photoArr[indexPath.row]]];
    
    cell.scrollView.delegate = self;

    [self addGestureTapToScrollView:cell.scrollView];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    ZLBigImageCell * WillCell = (ZLBigImageCell *)cell;
    WillCell.scrollView.zoomScale = 1;
}
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return scrollView.subviews[0];
}
#pragma mark ---  scrollView 添加手势
-(void)addGestureTapToScrollView:(UIScrollView *)scrollView{
    UITapGestureRecognizer * singleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapOnScrollView:)];
    singleTap.numberOfTapsRequired = 1;
    [scrollView addGestureRecognizer:singleTap];
    
    UITapGestureRecognizer * doubleTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doubleTapOnScrollView:)];
    doubleTap.numberOfTapsRequired = 2;
    [scrollView addGestureRecognizer:doubleTap];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == (UIScrollView *)_bigCollect) {
        //改变标题名字
        _number = scrollView.contentOffset.x / (SCREEN_WIDTH + 30);
        _middleTitle.text = [NSString stringWithFormat:@"%d/%d",(int)(_number + 1),(int)self.photoArr.count];
        _save.enabled = YES;
    }
}

/**
 *  隐藏导航栏和NavgationBar
 *
 *  @param singleTap 单击
 */
-(void)singleTapOnScrollView:(UITapGestureRecognizer *)singleTap{
    if (self.navigationController.navigationBar.isHidden) {
        [self showNavBarAndStatusBar];
    }else{
        [self hideNavBarAndStatusBar];
    }
}
#pragma mark ---  隐藏或者显示导航栏
-(void)showNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
}
-(void)hideNavBarAndStatusBar{
    self.navigationController.navigationBar.hidden = YES;
    [UIApplication sharedApplication].statusBarHidden = YES;
}
/**
 *  放大缩小
 *
 *  @param doubleTap 双击
 */
-(void)doubleTapOnScrollView:(UITapGestureRecognizer *)doubleTap{
    
    UIScrollView * scrollView = (UIScrollView *)doubleTap.view;
    CGFloat scale = 1;
    if (scrollView.zoomScale != 3) {
        scale = 3;
    }else{
        scale = 1;
    }
    [self CGRectForScale:scale WithCenter:[doubleTap locationInView:doubleTap.view] ScrollView:scrollView Completion:^(CGRect Rect) {
        [scrollView zoomToRect:Rect animated:YES];
    }];
}
-(void)CGRectForScale:(CGFloat)scale WithCenter:(CGPoint)center ScrollView:(UIScrollView *)scrollView Completion:(void(^)(CGRect Rect))completion{
    CGRect Rect;
    Rect.size.height = scrollView.frame.size.height / scale;
    Rect.size.width  = scrollView.frame.size.width  / scale;
    Rect.origin.x    = center.x - (Rect.size.width  /2.0);
    Rect.origin.y    = center.y - (Rect.size.height /2.0);
    completion(Rect);
}
#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

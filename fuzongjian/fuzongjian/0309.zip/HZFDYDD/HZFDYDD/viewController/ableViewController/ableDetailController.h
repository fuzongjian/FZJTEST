//
//  ableDetailController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/8.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ableModel.h"

typedef void (^takeOrderSuccessOrFail)(BOOL state);

@interface ableDetailController : UIViewController
@property(nonatomic,strong)ableModel * model;
@property(nonatomic,strong)NSMutableDictionary * dic;

@property(nonatomic,copy)takeOrderSuccessOrFail block;

-(void)returnYesOrNo:(takeOrderSuccessOrFail)block;



@end

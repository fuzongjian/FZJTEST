//
//  ableViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ableViewController.h"
#import "ableCustomCell.h"
#import "ableModel.h"
#import "ableDAO.h"
#import "personDataController.h"
#import "ableDetailController.h"

#import <BaiduMapAPI_Radar/BMKRadarManager.h>
#import <BaiduMapAPI_Location/BMKLocationService.h>

#import <BaiduMapAPI_Search/BMKGeocodeSearch.h>

typedef void(^getCityName) (NSString * cityName);


@interface ableViewController ()<UITableViewDelegate,UITableViewDataSource,customCellBtnClicked,BMKLocationServiceDelegate,BMKRadarManagerDelegate,BMKGeoCodeSearchDelegate,UIGestureRecognizerDelegate>
@property(nonatomic,strong)UITableView * ableTable;
@property(nonatomic,strong)UIView * backgroundView;//背后半透明的遮盖
@property(nonatomic,strong)UIView * popView;//弹出视图；
@property(nonatomic,strong)UIView * bigView;//上班按钮后面的背景视图
@property(nonatomic,strong)StateManager * stateManager;
/**
 *  数据源
 */
@property(nonatomic,strong)NSMutableArray * dataArr;
/**
 *  订单排序方式 0 默认按发布时间  1 则按服务时间排序
 */
@property(nonatomic,assign)BOOL sortState;
/** 百度定位地图服务 */
@property (nonatomic, strong) BMKLocationService *bmkLocationService;
/** 百度定位地图雷达 */
@property(nonatomic,strong)BMKRadarManager * radarManager;
/**
 *  地理位置编码器
 */
@property(nonatomic,strong)BMKGeoCodeSearch * codeSearch;

@property(nonatomic,assign)CLLocationCoordinate2D  location;

@property(nonatomic,copy)getCityName block;
/**
 *  判断有没有下一页
 */
@property(nonatomic,assign)BOOL nextPage;
@end

@implementation ableViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    /*  判断是否为上班状态  是否显示右边下班按钮  数据加载已经放在这个方法中了 */
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:ENTERBACKGROUND] intValue]) {
        
        [[NSUserDefaults standardUserDefaults] setObject:@1 forKey:ENTERBACKGROUND];
        [self startWorkingTestWorkState];
        
    }else{
        [self judgeWorkState];
    }

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self stopMJRefresh:YES andMessage:nil];
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    /*  判断是否为上班状态  */
    
    _stateManager = [StateManager defaultManager];
    
    
    [self configAbleViewControllerUI];
    [self addHeaderAndFooterMJRefesh];
    
    [self gotoWorkView];
    
//    [self judgeWorkState];

}
#pragma mark --
#pragma mark 初始化UI
-(void)configAbleViewControllerUI{
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    [self setCustomTitle:@"可接订单"];
    _dataArr = [NSMutableArray array];
    
/************************************************************************************/

    /* 创建发布时间和服务时间两个button */
    float btnHeight = 30;
    if (iPHone6Plus || iPHone6) {
        
        btnHeight = 38;
        
    }
//    for (int i = 0; i < 2; i ++) {
//        
//        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
//        btn.layer.cornerRadius = FIXWIDTHORHEIGHT((btnHeight - 4)/2.0);
//        btn.layer.masksToBounds = YES;
//        
//        
//        btn.frame = CGRectMake((SCREEN_WIDTH/2.0) * i, 64 + FIXWIDTHORHEIGHT(2), SCREEN_WIDTH/2.0, FIXWIDTHORHEIGHT(btnHeight - 4));
//
//        if (i == 0) {
//            
//            [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//            CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//            CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
//            [btn.layer setBorderColor:color];
//            [btn setBackgroundColor:[UIColor whiteColor]];
//            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//            
//            [btn setTitle:@"发布时间" forState:UIControlStateNormal];
//            
//        }else{
//            [btn setTitle:@"服务时间" forState:UIControlStateNormal];
//            [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
//        }
//        btn.tag = 789465 +i;
//       
//        [btn addTarget:self action:@selector(publishAndSeverBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
//        [self.view addSubview:btn];
//    }
    
    /*  创建tableView  */
    
    float margin = 0;
    if (iPHone6) {
        
        margin = 6;
    }
    if (iPHone6Plus) {
        
        margin = 11;
        
    }
/************************************************************************************/
    
    btnHeight = 0,margin = 0;
    
    _ableTable = [[UITableView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(btnHeight) - margin, SCREEN_WIDTH,SCREEN_HEIGHT - FIXWIDTHORHEIGHT(btnHeight)- 49 + margin) style:UITableViewStylePlain];
    _ableTable.delegate = self;
    _ableTable.dataSource = self;
    [self.view addSubview:_ableTable];
    
    //去掉分割线 滚动条
    _ableTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _ableTable.showsVerticalScrollIndicator = NO;
    _ableTable.backgroundColor = RGBCOLOR(240, 240, 240);
    _ableTable.tableFooterView = [UIView new];
    
    //添加手势
    UISwipeGestureRecognizer * swipeLight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeLight)];
    swipeLight.direction = UISwipeGestureRecognizerDirectionRight;
    [_ableTable addGestureRecognizer:swipeLight];
    UISwipeGestureRecognizer * swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionLeft;
    [_ableTable addGestureRecognizer:swipeRight];

    //点击tap
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapTableView)];
    tap.numberOfTapsRequired = 1;
    tap.delegate = self;
    [_ableTable addGestureRecognizer:tap];
    
}
#pragma mark  --  增加上拉下拉刷新
-(void)addHeaderAndFooterMJRefesh{
    __weak __typeof(self) weakSelf = self;
    /**
     *  下拉刷新
     */
    _ableTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [weakSelf loadAbleViewControllerData];
        
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([weakSelf.ableTable.mj_header isRefreshing]) {
                [weakSelf stopMJRefresh:NO andMessage:@"没有可接订单"];
            }
        });
    }];
    
    /**
     *  上拉刷新
     */
    _ableTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        
        [weakSelf footerRefreshing];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([weakSelf.ableTable.mj_footer isRefreshing]) {
                
                [weakSelf stopMJRefresh:NO andMessage:@"没有数据啦"];
            }
        });
        
    }];
    
}
#pragma mark -- 下拉刷新纪录所有的数据 上拉只加载最新数据
-(void)footerRefreshing{
    
    __weak __typeof(self) weakSelf = self;
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    
    if (_nextPage) {
        
        [self isOpenBmkLocationService:^(BOOL state) {
            if (state) {
                NSMutableDictionary * dic = [NSMutableDictionary dictionary];
                [weakSelf BaiDuMapGeoCodeSearch:^(NSString *cityName) {
                    
                    [dic setObject:cityName forKey:@"sercityname"];
                    [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
                    ableModel * model = [_dataArr lastObject];
                    [dic setObject:model.creationTime forKey:@"createtime"];
                    [AFNConnection GetAbleData:[NSString stringWithFormat:@"%@%@",IPDERSS,ABLEORDER] body:dic block:^(id backData) {
                        
                        _nextPage = [[backData objectForKey:@"nextpage"] intValue];
                        NSArray * array = [backData objectForKey:@"dataArr"];
                        
                        if (array.count) {
                            if (weakSelf.sortState) {//  订单排序
                                [_dataArr addObjectsFromArray:array];
                                [weakSelf sortAbleOrderDataArr:_dataArr completion:^(id data) {
                                    _dataArr = [NSMutableArray arrayWithArray:data];
                                }];
                            }else{
                                [_dataArr addObjectsFromArray:array];
                            }
                            [weakSelf stopMJRefresh:YES andMessage:@"刷新成功"];
                            [weakSelf.ableTable reloadData];
                        }else{
                            [weakSelf stopMJRefresh:NO andMessage:@"没有数据啦"];
                        }
                    } error:^(NSError *error) {
                        [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
                    }];
                    
                }];
            }
        }];

    }else{
        [self stopMJRefresh:NO andMessage:@"已经是最后一页了"];
    }

}
#pragma mark -- 上班的视图及其按钮
-(void)gotoWorkView{
    
    // 750*892   300 * 356.8  85*85
    
    
    // 750*892
    
    float scale = SCREEN_WIDTH / 750.0;//缩小的倍数
    
    UIView * bigView = [[UIView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64 - 49)];
    _bigView = bigView;
    bigView.backgroundColor = RGBCOLOR(240, 240, 240);
    UIImageView * bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 49 - 64 - 892 * scale , SCREEN_WIDTH, 892 * scale)];
    bgView.image = [UIImage imageNamed:@"work-bg"];
    bgView.userInteractionEnabled = YES;
    [bigView addSubview:bgView];
    
    
    
    
    if (iPHone4oriPHone4s) {
        CGRect frame = CGRectMake(SCREEN_WIDTH * 0.05, SCREEN_HEIGHT - 49 - 64 - 892 * 0.4 , SCREEN_WIDTH * 0.9, 892 * 0.4);
        bgView.frame = frame;
    }
    
    
    UIButton * workBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect frame ;
    if (iPHone5) {
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.25), FIXWIDTHORHEIGHT(bgView.size.width * 0.28), FIXWIDTHORHEIGHT(bgView.size.width * 0.28));
    }else if(iPHone6){
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.213), FIXWIDTHORHEIGHT(bgView.size.width * 0.24), FIXWIDTHORHEIGHT(bgView.size.width * 0.24));
    }else if(iPHone6Plus){
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.195), FIXWIDTHORHEIGHT(bgView.size.width * 0.214), FIXWIDTHORHEIGHT(bgView.size.width * 0.214));
    }else{
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width), FIXWIDTHORHEIGHT(bgView.size.height * 0.25), FIXWIDTHORHEIGHT(bgView.size.width * 0.28), FIXWIDTHORHEIGHT(bgView.size.width * 0.285));
    }
    workBtn.frame = frame;
    CGPoint center = workBtn.center;
    center.x = self.view.center.x;
    workBtn.center = center;
    
    if (iPHone4oriPHone4s) {
        workBtn.frame = frame;
        CGPoint center = workBtn.center;
        center.x = self.view.center.x - 16.5;
        center.y += 1;
        
        workBtn.center = center;
    }
    
    
    [workBtn setBackgroundImage:[UIImage imageNamed:@"press-to-work"] forState:UIControlStateNormal];
    [workBtn setBackgroundImage:[UIImage imageNamed:@"press-to-work-h"] forState:UIControlStateHighlighted];
    [workBtn addTarget:self action:@selector(gotoWorkBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:workBtn];
    
    
    //添加手势
    UISwipeGestureRecognizer * swipeLight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeLight)];
    swipeLight.direction = UISwipeGestureRecognizerDirectionRight;
    [bigView addGestureRecognizer:swipeLight];
    UISwipeGestureRecognizer * swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionLeft;
    [bigView addGestureRecognizer:swipeRight];
    
    bigView.alpha = 0;
    [self.view addSubview:bigView];
    
    
    
}
-(void)test{
    // 750*892   300 * 356.8  85*85
    
    
    // 750*892
    
    float scale = SCREEN_WIDTH / 750.0;//缩小的倍数
    
    UIView * bigView = [[UIView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64 - 49)];
    _bigView = bigView;
    bigView.backgroundColor = RGBCOLOR(240, 240, 240);
    UIImageView * bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 49 - 64 - 892 * scale , SCREEN_WIDTH, 892 * scale)];
    bgView.image = [UIImage imageNamed:@"work-bg"];
    bgView.userInteractionEnabled = YES;
    [bigView addSubview:bgView];
    
    
    
    
    if (iPHone4oriPHone4s) {
        CGRect frame = CGRectMake(0, SCREEN_HEIGHT - 49 - 64 - 892 * 0.4 , SCREEN_WIDTH, 892 * 0.4);
        bgView.frame = frame;
    }
    
    
    
    
    
    UIButton * workBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGRect frame ;
    if (iPHone5) {
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.25), FIXWIDTHORHEIGHT(bgView.size.width * 0.28), FIXWIDTHORHEIGHT(bgView.size.width * 0.28));
    }else if(iPHone6){
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.213), FIXWIDTHORHEIGHT(bgView.size.width * 0.24), FIXWIDTHORHEIGHT(bgView.size.width * 0.24));
    }else if(iPHone6Plus){
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.195), FIXWIDTHORHEIGHT(bgView.size.width * 0.214), FIXWIDTHORHEIGHT(bgView.size.width * 0.214));
    }else{
        frame = CGRectMake(FIXWIDTHORHEIGHT(bgView.size.width * 0.3), FIXWIDTHORHEIGHT(bgView.size.height * 0.25), FIXWIDTHORHEIGHT(bgView.size.width * 0.28), FIXWIDTHORHEIGHT(bgView.size.width * 0.265));
    }
    workBtn.frame = frame;
    CGPoint center = workBtn.center;
    center.x = self.view.center.x;
    workBtn.center = center;
    
    [workBtn setBackgroundImage:[UIImage imageNamed:@"press-to-work"] forState:UIControlStateNormal];
    [workBtn setBackgroundImage:[UIImage imageNamed:@"press-to-work-h"] forState:UIControlStateHighlighted];
    [workBtn addTarget:self action:@selector(gotoWorkBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:workBtn];
    
    
    //添加手势
    UISwipeGestureRecognizer * swipeLight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeLight)];
    swipeLight.direction = UISwipeGestureRecognizerDirectionRight;
    [bigView addGestureRecognizer:swipeLight];
    UISwipeGestureRecognizer * swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionLeft;
    [bigView addGestureRecognizer:swipeRight];
    
    bigView.alpha = 0;
    [self.view addSubview:bigView];
    
    

}
#pragma mark -- 上班按钮点击事件(需要判断是否注册过)（接口）
-(void)gotoWorkBtnClicked{
    __weak __typeof(self) weakSelf = self;
    if (_stateManager.reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    [SVProgressHUD showWithStatus:@"处理中..."];
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,WORKON] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {//判断上班是否请求成功
            [SVProgressHUD dismiss];
             NSDictionary * dic = [backData objectForKey:@"result"];
            [weakSelf workOnJudgeTrueNameAndQualitification:dic nameState:[[dic objectForKey:@"istatus"] intValue] qualifyState:[[dic objectForKey:@"qstatus"] intValue]];
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"上班失败"];
        NSLog(@"上班按钮点击事件error:%@",error);
    }];
}
#pragma mark--传入参数判断用户有没有实名认证、资格认证状态
-(void)workOnJudgeTrueNameAndQualitification:(NSDictionary *)dic nameState:(int)name qualifyState:(int)qualify{
    /**
     *  存储认证状态呢
     */
    [[NSUserDefaults standardUserDefaults] setObject:@(name) forKey:@"nameState"];
    [[NSUserDefaults standardUserDefaults] setObject:@(qualify) forKey:@"qualify"];
    
    int state = 0;// 0 未认证  1 认证没有通过  2 审核中  3 通过
    
    if(name == 3 && qualify == 3){
        state = 3;
    }else if((name == 3 && qualify == 2) ||(name == 2 && qualify == 2) ||(name == 2 && qualify == 3) ){
        state = 2;
    }else if(name == 4 || qualify == 4){
        state = 1;
    }else{
        state = 0;
    }
    
    switch (state) {
        case 0:
            _stateManager.workState = NO;
            [self createAlertPopView];
            break;
        case 1:
            _stateManager.workState = NO;
            [self createAlertPopView];
            break;
        case 2:
            [SVProgressHUD showErrorWithStatus:@"资料审核中..."];
            break;
        case 3:
            [SVProgressHUD showSuccessWithStatus:@"工作愉快!"];
            [[NSUserDefaults standardUserDefaults] setObject:@1 forKey:WORKSTATE];
            [self judgeWorkState];
            break;
        default:
            break;
    }
}
#pragma mark--开始上班的时候初始化百度地图、上传用户位置
-(void)initBaiduMap{
    // 初始化位置百度位置服务
    self.bmkLocationService = [[BMKLocationService alloc] init];
    // 2.打开定位服务
    [self.bmkLocationService startUserLocationService];
    self.bmkLocationService.delegate = self;
    _radarManager = [BMKRadarManager getRadarManagerInstance];

    _radarManager.userId = [NSString stringWithFormat:@"%@",_stateManager.userId];
    
    [_radarManager addRadarManagerDelegate:self];
    
/**
 *启动自动上传用户位置信息
 *必须实现回调方法@see getRadarAutoUploadInfo，获取@see BMKRadarUploadInfo
 *@param interval 时间间隔，不小于5s（小于强制设为5s）
*/
    
    [_radarManager startAutoUpload:5];
}
#pragma mark--下班要及时停止百度地图的一切定位服务
-(void)stopBaiduMap{
    
//    - (BOOL)clearMyInfoRequest
    [_radarManager clearMyInfoRequest];//清除位置信息
    [_radarManager removeRadarManagerDelegate:self];
    [BMKRadarManager releaseRadarManagerInstance];
    self.bmkLocationService.delegate = nil;
    self.codeSearch.delegate = nil;
}
#pragma mark ---  是否打开了定位服务
-(void)isOpenBmkLocationService:(void(^)(BOOL state))completion{
    
    if ([CLLocationManager locationServicesEnabled] && ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways
         || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse)) {
            
            completion(YES);
        NSLog(@"已经打开了定位服务");
        
        }
    else if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied){
        [SVProgressHUD showErrorWithStatus:@"请在iPhone的\"设置-隐私-定位服务\"中允许访问位置信息"];
        [_ableTable.mj_header endRefreshing];
        [_ableTable.mj_footer endRefreshing];
        NSLog(@"定位功能不可用");
    }
}
#pragma mark -- 创建弹出视图

-(void)createAlertPopView{
    float popFontSize = FIXWIDTHORHEIGHT(15);
    UIColor * color = RGBCOLOR(105, 105, 105);
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    _backgroundView = bgView;
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.3, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.4)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    _popView = popView;
    
    
    UIImageView * warnImage = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, FIXWIDTHORHEIGHT(5), popView.size.width * 0.3, popView.size.width * 0.3)];
    warnImage.image = [UIImage imageNamed:@"warning"];
    [popView addSubview:warnImage];
    
    UILabel * lableOne = [[UILabel alloc]initWithFrame:CGRectMake(0, warnImage.origin.y + warnImage.size.height + FIXWIDTHORHEIGHT(0), popView.size.width, SCREEN_HEIGHT * 0.05)];
    lableOne.text = @"您还没有实名认证和资格认证";
    lableOne.font = [UIFont systemFontOfSize:popFontSize];
    lableOne.textAlignment = NSTextAlignmentCenter;
    lableOne.textColor = color;
    [popView addSubview:lableOne];
    
    UILabel * lableTwo = [[UILabel alloc]initWithFrame:CGRectMake(0, lableOne.origin.y + lableOne.size.height, popView.size.width, SCREEN_HEIGHT * 0.05)];
    lableTwo.text = @"马上进行实名认证和资格认证";
    lableTwo.font = [UIFont systemFontOfSize:popFontSize];
    lableTwo.textAlignment = NSTextAlignmentCenter;
    lableTwo.textColor = color;
    [popView addSubview:lableTwo];
    
    //[btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//    CGColorRef borderColor = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
    // [btn.layer setBorderColor:color];
    
    
    UIButton * cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancleBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(10), popView.size.height * 0.8, popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), popView.size.height * 0.14);
    cancleBtn.layer.cornerRadius = popView.size.height * 0.07;
    cancleBtn.layer.masksToBounds = YES;
    [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
    cancleBtn.titleLabel.font = [UIFont systemFontOfSize:popFontSize];
    [cancleBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [cancleBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [cancleBtn.layer setBorderColor:borderColor];
    [cancleBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [cancleBtn addTarget:self action:@selector(popViewCancleBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [popView addSubview:cancleBtn];
    
    UIButton * sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(popView.size.width * 0.5 + FIXWIDTHORHEIGHT(5), popView.size.height * 0.8, popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), popView.size.height * 0.14);
    sureBtn.layer.cornerRadius = popView.size.height * 0.07;
    sureBtn.layer.masksToBounds = YES;
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    sureBtn.titleLabel.font = [UIFont systemFontOfSize:popFontSize];
    [sureBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [sureBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [sureBtn.layer setBorderColor:borderColor];
    [sureBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [sureBtn addTarget:self action:@selector(popViewSureBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    [popView addSubview:sureBtn];
    

}
#pragma mark --  弹出视图的确定取消点击事件
-(void)popViewCancleBtnClicked{
    [_popView removeFromSuperview];
    [_backgroundView removeFromSuperview];
    NSLog(@"弹出视图的取消点击事件");
}
-(void)popViewSureBtnClicked{
    
    [_popView removeFromSuperview];
    [_backgroundView removeFromSuperview];
   
    
    personDataController * personData = [[personDataController alloc]init];
    [self.view.window.rootViewController presentViewController:personData animated:YES completion:^{
        
    }];
    NSLog(@"弹出视图的确定点击事件");
}
#pragma mark--添加手势实现的方法
-(void)swipeRight{
    [self.superDelegate openOrCloseDrawer:NO];
}
-(void)swipeLight{
    [self.superDelegate openOrCloseDrawer:YES];
}
#pragma mark-- 重写父类右侧下班按钮点击事件(接口)
-(void)rightBtnClicked{
    
    __weak typeof(self) weakSelf = self;
    if (_stateManager.reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
/*********************************下班接口测试***********************************************************/
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,WORKOFF] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:WORKSTATE];
            [weakSelf judgeWorkState];//
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
        
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"下班失败"];
        NSLog(@"下班error:%@",error);
    }];
   
    
}
#pragma mark --- 重写父类的通知方法（登陆后发出的通知）
-(void)uploadPersonData:(NSNotification *)notify{
    [self judgeWorkState];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载 每次数据刷新必需要判断是否开启定位服务
-(void)loadAbleViewControllerData{
    __weak typeof (self) weakSelf = self;
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    
    [self isOpenBmkLocationService:^(BOOL state) {
        if (state) {
            
            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            
            [weakSelf BaiDuMapGeoCodeSearch:^(NSString *cityName) {
                
                [dic setObject:cityName forKey:@"sercityname"];
                [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];

                [AFNConnection GetAbleData:[NSString stringWithFormat:@"%@%@",IPDERSS,ABLEORDER] body:dic block:^(id backData) {
                    
                    _nextPage = [[backData objectForKey:@"nextpage"] intValue];
                    _dataArr = [NSMutableArray arrayWithArray:[backData objectForKey:@"dataArr"]];
                    
                    if (_dataArr.count) {
                        if (weakSelf.sortState) {//需要进行订单排序
                            [weakSelf sortAbleOrderDataArr:backData completion:^(id data) {
                                [weakSelf stopMJRefresh:YES andMessage:@"刷新成功"];
                                [_ableTable reloadData];
                            }];
                        }else{
                            [weakSelf stopMJRefresh:YES andMessage:@"刷新成功"];
                            [_ableTable reloadData];
                        }
                        
                    }else{
                        [weakSelf stopMJRefresh:NO andMessage:@"没有可接订单"];
                        [_ableTable reloadData];
                    }
                } error:^(NSError *error) {
                    [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
                }];

            }];
            
        }
    }];
    
}
/**
 *  停止刷新
 */
-(void)stopMJRefresh:(BOOL)state andMessage:(NSString *)message{
    
    
    if (!state && ([_ableTable.mj_header isRefreshing]||[_ableTable.mj_footer isRefreshing])) {
        [SVProgressHUD showErrorWithStatus:message];
    }
    
    if ([_ableTable.mj_footer isRefreshing]) {
        [_ableTable.mj_footer endRefreshing];
    }
    if ([_ableTable.mj_header isRefreshing]) {
        [_ableTable.mj_header endRefreshing];
    }
}
#pragma mark -- 订单排序
-(void)sortAbleOrderDataArr:(NSMutableArray *)dataArr completion:(void(^)(id data))completion{
    NSMutableArray * transform = [NSMutableArray arrayWithArray:dataArr];
    NSDateFormatter * formatter = [NSDateFormatter new];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    for (int i = 0; i < transform.count - 1;  i ++) { //需要排序的次数
        for (int j = i + 1; j < dataArr.count; j ++ ) {
            ableModel * modelOne = transform[i];
            ableModel * modelTwo = transform[j];
            long state = [[formatter dateFromString:modelOne.startTime] timeIntervalSinceDate:[formatter dateFromString:modelTwo.startTime]];
            if (state > 0) {
                [transform exchangeObjectAtIndex:i withObjectAtIndex:j];
            }
        }
    }
    completion(transform);
}
#pragma mark--
#pragma mark 事件
#pragma mark --上班状态的判断（上班状态则请求数据）（接口）
-(void)judgeWorkState{
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:WORKSTATE] intValue]) {
        _stateManager.workState = YES;
    }else{
        _stateManager.workState = NO;
    }
    
    
    if (_stateManager.workState) {
        [self initBaiduMap];
        [self loadAbleViewControllerData];
        self.bigView.alpha = 0.0;
        self.rightBtn.hidden = NO;
        
    }else{
        
        self.bigView.alpha = 1.0;
        self.rightBtn.hidden = YES;
        [self stopBaiduMap];
        
    }
    
}
-(void)startWorkingTestWorkState{
    
  
    if (_stateManager.reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    [SVProgressHUD showWithStatus:@"获取上班状态..."];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([[StateManager defaultManager].userId intValue]) forKey:@"servicerid"];
    
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,GETINFO] body:dic  block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD dismiss];
            int status = [[[[backData objectForKey:@"result"] objectForKey:@"servicer"] objectForKey:@"status"] intValue];
            if (status == 1) {
                [[NSUserDefaults standardUserDefaults] setObject:@1 forKey:WORKSTATE];
            }else{
                [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:WORKSTATE];
            }
            [self judgeWorkState];
        }else{
            [SVProgressHUD showErrorWithStatus:@"获取数据失败"];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"获取数据失败"];
    }];
    
}
#pragma mark ---  服务时间和发布时间按钮点击事件
-(void)publishAndSeverBtnClicked:(UIButton *)btn{
    
    UIButton * btnOne = [self.view viewWithTag:789465];
    UIButton * btnTwo = [self.view viewWithTag:789466];
    
    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    CGColorRef colorOne = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
    CGColorRef colorTwo = CGColorCreate(colorSpaceRef, (CGFloat[]){0,0,0,0});
     [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [btn.layer setBorderColor:color];

    if (btn.tag == 789465) {
        
        [btnOne setBackgroundColor:[UIColor whiteColor]];
        [btnOne setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnOne.layer setBorderColor:colorOne];
        
        [btnTwo setBackgroundColor:RGBCOLOR(240, 240, 240)];
        [btnTwo setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [btnTwo.layer setBorderColor:colorTwo];
        self.sortState = 0;
        NSLog(@"发布时间");
        
    }else{
        
        [btnOne setBackgroundColor:RGBCOLOR(240, 240, 240)];
        [btnOne setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [btnOne.layer setBorderColor:colorTwo];
        
        
        [btnTwo setBackgroundColor:[UIColor whiteColor]];
        [btnTwo setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btnTwo.layer setBorderColor:colorOne];
        
        self.sortState = 1;
        NSLog(@"服务时间");
    }
    [_ableTable.mj_header beginRefreshing];
    [self loadAbleViewControllerData];
}
#pragma mark--
#pragma mark  代理
#pragma mark--百度地图代理
-(void)didFailToLocateUserWithError:(NSError *)error{
    NSLog(@"%@",error);
}
/**
 *  用户位置更新后，会调用此函数
 *  @param userLocation 新的用户位置
 */
-(void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation{
    
    self.location = userLocation.location.coordinate;

}
/**
 *  用户方向更新后，会调用此函数
 *  @param userLocation 新的用户位置
 */
-(void)didUpdateUserHeading:(BMKUserLocation *)userLocation{
    
    self.location = userLocation.location.coordinate;
    
}
/**
 *  雷达自动上传位置代理
 *
 *  @return 地理位置
 */
- (BMKRadarUploadInfo*)getRadarAutoUploadInfo{
    BMKRadarUploadInfo * info = [[BMKRadarUploadInfo alloc]init];
    info.pt = self.location;
    return info;
}

/**
 *  返回雷达上传的结果
 *
 *  @param error 结果
 */
- (void)onGetRadarUploadResult:(BMKRadarErrorCode) error{
    
}
/**
 *  地理位置反编码
 *
 *  @param completion 城市名
 */
-(void)BaiDuMapGeoCodeSearch:(getCityName)cityBlock{
    
    self.block = cityBlock;
    
    _codeSearch = [[BMKGeoCodeSearch alloc] init];
    /**
     *  用完之后nil掉，会影响内存释放
     */
    _codeSearch.delegate = self;
    /**
     *  初始化逆地理编码类
     */
    BMKReverseGeoCodeOption * codeOption = [[BMKReverseGeoCodeOption alloc] init];
    /**
     *  需要逆地理编码的坐标位置
     */
    codeOption.reverseGeoPoint = self.location;
    
    [_codeSearch reverseGeoCode:codeOption];
    
}
-(void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error{
    
    if (self.block && [result.addressDetail.city length]) {
        self.block(result.addressDetail.city);
    }
}
/**
 *  下班后要清除位置信息 清除位置的回调
 *
 *  @param error
 */
- (void)onGetRadarClearMyInfoResult:(BMKRadarErrorCode) error{
    
}
#pragma mark--表格代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * ableId = @"ableId";
    
    ableCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:ableId];
    if (!cell) {
        cell = [[ableCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ableId];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = RGBCOLOR(240, 240, 240);

    /*  拿到自定义cell的代理 */
    cell.cellDelegate = self;
    cell.cellRow = indexPath.row;
    
        
    ableModel * model = _dataArr[indexPath.row];
    
    cell.sum.text = [NSString stringWithFormat:@"%@",model.money];
    cell.durationTime.text = [NSString stringWithFormat:@"服务时长:%.1f小时",[model.duration floatValue]];
    cell.aimHospital.text = [NSString stringWithFormat:@"目标医院:%@",model.hospitalName];
    cell.startTime.text = [NSString stringWithFormat:@"开始时间:%@",model.startTime];
    
    
    if ([model.shuttle intValue]) {
        cell.shuttleView.alpha = 1.0;
    }else{
        cell.shuttleView.alpha = 0.0;
    }
    
    cell.star.text = [NSString stringWithFormat:@"%@",model.serviceTypeName];
    cell.starView.backgroundColor = RGBCOLOR([model.red floatValue], [model.green floatValue], [model.blue floatValue]);
    

        return cell;
}
#pragma mark--表格代理订单详情(界面跳转)
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
   
    if (!_stateManager.drawerState) {
        
        ableDetailController * ableDetail = [[ableDetailController alloc]init];
        
        [ableDetail returnYesOrNo:^(BOOL state) {
            if (state) {
                [_dataArr removeObject:_dataArr[indexPath.row]];
                [self.ableTable reloadData];
            }
        }];
        
        ableModel * model = _dataArr[indexPath.row];
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
        [dic setObject:model.Nid forKey:@"orderid"];
        ableDetail.dic = dic;
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:ableDetail animated:YES];
        self.hidesBottomBarWhenPushed = NO;
        
    }else{
        [self closeDrawer];
    }
    
    NSLog(@"表格点击事件   选中第%d行",(int)indexPath.row);
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return FIXWIDTHORHEIGHT(100);
}
#pragma mark--接单（接口）
/*     实现自定义cell的协议方法    */
-(void)customBtnClicked:(NSInteger)cellRow{
    
    if (_stateManager.reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    
    [SVProgressHUD showWithStatus:@"处理中..."];
    
/*******************************接单测试接口（需要在数据源删除该订单）**********************************/

    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    ableModel * model = _dataArr[cellRow];
    [dic setObject:model.Nid forKey:@"orderid"];
    NSLog(@"%@",dic);
    
    
    /*       需要在数据源里获取订单编号      [NSString stringWithFormat:@"%@%@",IPDERSS,TAKERORDER] */

    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,TAKERORDER] body:dic block:^(id backData) {
        
        NSLog(@"接单success:%@",[backData objectForKey:@"msg"]);
        
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            for (int i = (int)_dataArr.count - 1; i > 0 || i == 0; i --) {
                if (i == cellRow) {
                    [_dataArr removeObject:_dataArr[i]];
                    [self.ableTable reloadData];
                }
            }
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];

        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"接单失败"];
        NSLog(@"接单error:%@",error);
    }];
    
    
}
-(void)tapTableView{
    if (_stateManager.drawerState){
        [self closeDrawer];
    }
}
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (_stateManager.drawerState) {
        return YES;
    }else{
        return NO;
    }
}
-(void)closeDrawer{
    if(self.navigationController)
    {
        if(self.navigationController.tabBarController)
        {
            if([self.navigationController.tabBarController respondsToSelector:@selector(close)])
            {
                [self.navigationController.tabBarController performSelector:@selector(close)];
            }
        }
    }
}
#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

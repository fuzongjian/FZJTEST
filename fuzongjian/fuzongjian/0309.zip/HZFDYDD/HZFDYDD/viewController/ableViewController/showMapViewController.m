//
//  showMapViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/21.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "showMapViewController.h"
#import <BaiduMapAPI_Map/BMKMapView.h>
#import <BaiduMapAPI_Search/BMKGeocodeSearch.h>

#import <BaiduMapAPI_Map/BMKAnnotation.h>
#import <BaiduMapAPI_Map/BMKPointAnnotation.h>
#import <BaiduMapAPI_Map/BMKPinAnnotationView.h>

//#import <BaiduMapAPI_Map/BMKShape.h>

typedef void(^MapViewBlock) (CLLocationCoordinate2D coordinate);

@interface showMapViewController ()<BMKMapViewDelegate,BMKGeoCodeSearchDelegate>
@property(nonatomic,strong)BMKMapView * mapView;
/**
 *  地理位置编码器
 */
@property(nonatomic,strong)BMKGeoCodeSearch * codeSearch;
@property(nonatomic,copy)MapViewBlock block;
@end

@implementation showMapViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.mapView viewWillAppear];
    self.mapView.delegate = self;
     _codeSearch.delegate = self;
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.mapView viewWillDisappear];
    self.mapView.delegate = nil;
    self.codeSearch.delegate = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configShowMapViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configShowMapViewControllerUI{
    
    //设置标题
    self.navigationItem.titleView = [Tool setCustomViewTitle:@"位置详情"];
    
     [self.navigationController.navigationBar setBackgroundColor:RGBCOLOR(240, 240, 240)];
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 45, 45);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(ongoingBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    
    _mapView = [[BMKMapView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    _mapView.zoomLevel = 15;
    [self.view addSubview:_mapView];
    
    __weak __typeof(self) weakSelf = self;
    [self BaiDuMapGeoCodeSearch:^(CLLocationCoordinate2D coordinate) {
        //显示位置
        weakSelf.mapView.centerCoordinate = coordinate;
        //添加标记
        [weakSelf createPointAnnotationWithCoordinate:coordinate];
        
    }];
}
/**
 *  只有在添加大头针的时候才会调用
 */
-(BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation{
    
    if ([annotation isKindOfClass:[BMKPointAnnotation class]]) {
        BMKPinAnnotationView * annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"annotation"];
        annotationView.pinColor = BMKPinAnnotationColorPurple;
        // 从天上掉下效果
        annotationView.animatesDrop = YES;
        // 不可拖拽
        annotationView.draggable = YES;
        return annotationView;
    }
    
    return nil;
}
/**
 *  添加一个大头针 显示用户位置
 *
 *  @param location
 */
-(BMKPointAnnotation *)createPointAnnotationWithCoordinate:(CLLocationCoordinate2D)coordate{
    BMKPointAnnotation * point = [[BMKPointAnnotation alloc] init];
    point.coordinate = coordate;
    point.title = self.location;
    [self.mapView addAnnotation:point];
    return point;
}
//- (BMKPointAnnotation *)creatPointWithLocaiton:(CLLocation *)location title:(NSString *)title;
//{
//    BMKPointAnnotation * point = [[BMKPointAnnotation alloc] init];
//    point.coordinate = location.coordinate;
//    point.title = title;
//    [self.mapView addAnnotation:point];
//    NSLog(@"添加一个大头针");
//    return point;
//}

-(void)BaiDuMapGeoCodeSearch:(MapViewBlock)mapBlock{
    
    _codeSearch = [[BMKGeoCodeSearch alloc] init];
    
    BMKGeoCodeSearchOption * codeOption = [[BMKGeoCodeSearchOption alloc] init];
    
    codeOption.city = self.cityName;
    
    codeOption.address = self.location;
    
    [self.codeSearch geoCode:codeOption];
    
    self.block = mapBlock;
}
-(void)onGetGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error{
    
    if (self.block && result.location.longitude != 0.0) {
        
        self.block(result.location);
        
    }
    
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)ongoingBackBtnClicked{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

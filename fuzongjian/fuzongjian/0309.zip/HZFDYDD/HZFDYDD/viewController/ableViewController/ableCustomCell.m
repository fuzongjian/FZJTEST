//
//  ableCustomCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/13.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ableCustomCell.h"

@implementation ableCustomCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self configAbleCustomCellUI];
        
    }
    return  self;
}

-(void)configAbleCustomCellUI{
    
    /* 背景图片 */
    UIImageView * bgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg-1"]];
    bgView.userInteractionEnabled = YES;
    bgView.frame = CGRectMake(0, 0,SCREEN_WIDTH, FIXWIDTHORHEIGHT(100));
    [self.contentView addSubview:bgView];
    
    /* 总额 */
    float sumFontSize = FIXWIDTHORHEIGHT(15);//总额行的字体大小
    UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(20))];
    lable.text = @"总额:";
    [bgView addSubview:lable];
    lable.font = [UIFont systemFontOfSize:sumFontSize];
    _sum = [[UILabel alloc]initWithFrame:CGRectMake(lable.origin.x + lable.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(50), FIXWIDTHORHEIGHT(20))];
    _sum.text = @"300元";
    _sum.textColor = [UIColor redColor];
    _sum.font = [UIFont systemFontOfSize:sumFontSize];
    [bgView addSubview:_sum];
    
    /*服务等级*/
    _starView = [[UIView alloc]initWithFrame:CGRectMake(bgView.size.width * 0.8, 0, bgView.size.width * 0.15, FIXWIDTHORHEIGHT(30))];
    _starView.backgroundColor = RGBCOLOR(157, 206, 134);
    _starView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _starView.layer.masksToBounds = YES;
    [bgView addSubview:_starView];
    _star = [[UILabel alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(5), bgView.size.width * 0.15, FIXWIDTHORHEIGHT(20))];
    _star.text = @"普通";
    _star.font = [UIFont systemFontOfSize:sumFontSize];
    _star.textColor = [UIColor whiteColor];
    _star.textAlignment = NSTextAlignmentCenter;
    [_starView addSubview:_star];
    
    _shuttleView = [[UIView alloc]initWithFrame:CGRectMake(bgView.size.width * 0.6, 0, bgView.size.width * 0.15, FIXWIDTHORHEIGHT(30))];
    _shuttleView.backgroundColor = RGBCOLOR(157, 206, 134);
    _shuttleView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _shuttleView.layer.masksToBounds = YES;
    [bgView addSubview:_shuttleView];
    
    _shuttle = [[UILabel alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(5), bgView.size.width * 0.15, FIXWIDTHORHEIGHT(20))];
    _shuttle.text = @"接送";
    _shuttle.font = [UIFont systemFontOfSize:sumFontSize];
    _shuttle.textColor = [UIColor whiteColor];
    _shuttle.textAlignment = NSTextAlignmentCenter;
    [_shuttleView addSubview:_shuttle];
    
    
    
    
    /*分割线*/
    UIView * small = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), _sum.origin.y + _sum.size.height + FIXWIDTHORHEIGHT(5), bgView.size.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(1))];
    small.backgroundColor = RGBCOLOR(240, 240, 240);
    [bgView addSubview:small];
    
    /*目标医院*/
    float fontSize = FIXWIDTHORHEIGHT(12);//目标医院及以下的lable字体大小
    _aimHospital = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), small.origin.y + FIXWIDTHORHEIGHT(5), bgView.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _aimHospital.text = @"目标医院：浙江大学第一附属医院";
    _aimHospital.font = [UIFont systemFontOfSize:fontSize];
    _aimHospital.textColor = RGBCOLOR(142, 142, 142);
    [bgView addSubview:_aimHospital];
    
     /*开始时间*/
    _startTime = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), _aimHospital.origin.y + _aimHospital.size.height, bgView.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _startTime.text = @"开始时间：2015-11-11  15:30";
    _startTime.font = [UIFont systemFontOfSize:fontSize];
    _startTime.textColor = RGBCOLOR(142, 142, 142);
    [bgView addSubview:_startTime];
    
    /*服务时间*/
    _durationTime = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), _startTime.origin.y + _startTime.size.height, bgView.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _durationTime.text = @"服务时长：3个小时";
    _durationTime.font = [UIFont systemFontOfSize:fontSize];
    _durationTime.textColor = RGBCOLOR(142, 142, 142);
    [bgView addSubview:_durationTime];
    
    /* 接单按钮 */
    UIButton * takeOrder = [UIButton buttonWithType:UIButtonTypeCustom];
    takeOrder.frame = CGRectMake(bgView.size.width * 0.75, bgView.size.height * 0.6, bgView.size.width * 0.2, bgView.size.height * 0.3);
    [takeOrder setTitle:@"接单" forState:UIControlStateNormal];
    [takeOrder setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    takeOrder.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    takeOrder.layer.masksToBounds = YES;
    [takeOrder addTarget:self action:@selector(takeOrderBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:takeOrder];
//    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//    CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
//    [takeOrder.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [takeOrder.layer setBorderColor:color];
    [takeOrder setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
}

/* 接单按扭点击事件 */
-(void)takeOrderBtnClicked{

    if (_cellDelegate != nil && [_cellDelegate respondsToSelector:@selector(customBtnClicked:)]) {
        
        [_cellDelegate customBtnClicked:_cellRow];
        
    }
    
    
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  ableDetailController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/8.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "ableDetailController.h"
#import "showMapViewController.h"

@interface ableDetailController ()

@property(nonatomic,strong)UILabel * contactName;

@property(nonatomic,strong)UILabel * contactPhone;

@property(nonatomic,strong)UILabel * patientName;

@property(nonatomic,strong)UILabel * hospital;

@property(nonatomic,strong)UILabel * startTime;

@property(nonatomic,strong)UILabel * duration;

@property(nonatomic,strong)UILabel * type;

@property(nonatomic,strong)UILabel * sum;

@property(nonatomic,strong)UIButton * takeBtn;

@property(nonatomic,strong)UILabel * shuttlePlace;

@property(nonatomic,strong)UITextView * shuttlePlaceTextView;
/**
 *  接单是否成功
 */
@property(nonatomic,assign)BOOL takeState;

@property(nonatomic,strong)UIButton * locationBtn;
@property(nonatomic,strong)NSDictionary * detailOrder;

@property(nonatomic,strong)UILabel * shuttlePlaceLable;
@end

@implementation ableDetailController
#pragma mark-- 内存测试
-(void)dealloc{
    NSLog(@"内存测试");
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configAbleDetailControllerUI];
    [self loadAbleDetailControllerData];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configAbleDetailControllerUI{
    [self.navigationController.navigationBar setBackgroundColor:RGBCOLOR(240, 240, 240)];
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 45, 45);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(ongoingBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    //设置标题
    self.navigationItem.titleView = [Tool setCustomViewTitle:@"订单详情"];
    
    UIScrollView * scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(3), SCREEN_WIDTH, SCREEN_HEIGHT - FIXWIDTHORHEIGHT(3))];
    scroll.backgroundColor = RGBCOLOR(240, 240, 240);
    
    [self.view addSubview:scroll];
    //字体大小
    
    float detailFontSize = 15.0;
    UIColor * color = RGBCOLOR(50, 50, 50);
    
    //设置订单详情界面一
    
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0,  FIXWIDTHORHEIGHT(2), SCREEN_WIDTH, FIXWIDTHORHEIGHT(160))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    [scroll addSubview:bgViewOne];
    bgViewOne.userInteractionEnabled = YES;
    
    /*联系人*/
    
    UILabel * contact = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, bgViewOne.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    contact.text = @"联系人：";
    contact.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    contact.textColor = color;
    _contactName = contact;
    [bgViewOne addSubview:contact];
    
    /*  联系方式  */
    
    UILabel * call = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), contact.origin.y + contact.size.height, bgViewOne.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    call.text = @"联系方式：";
    call.textColor = color;
    call.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    //    call.backgroundColor = [UIColor redColor];
    _contactPhone = call;
    [bgViewOne addSubview:call];
    
    /*  电话按钮 */
    
    UIButton * callBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    callBtn.frame = CGRectMake(bgViewOne.size.width - FIXWIDTHORHEIGHT(40), contact.origin.y + contact.size.height + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(20));
    [callBtn setBackgroundImage:[UIImage imageNamed:@"call1"] forState:UIControlStateNormal];
    [callBtn addTarget:self action:@selector(ongingCallBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewOne addSubview:callBtn];
    
    /* 就医者 */
    
    UILabel * patient = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), call.origin.y + call.size.height +FIXWIDTHORHEIGHT(1), bgViewOne.size.width - 40, FIXWIDTHORHEIGHT(39))];
    patient.text = @"就医者：";
    patient.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    patient.textColor = color;
    [bgViewOne addSubview:patient];
    _patientName = patient;
    /* 就诊医院 */
    
    UILabel * hospital = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), patient.origin.y + patient.size.height + FIXWIDTHORHEIGHT(1), bgViewOne.size.width - 40, FIXWIDTHORHEIGHT(39))];
    hospital.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    hospital.textColor = color;
    hospital.text = @"就诊医院：";
    [bgViewOne addSubview:hospital];
    _hospital = hospital;
    /* 分割线 */
    if (iPHone6 || iPHone6Plus) {
        for (int i = 0; i < 3; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(45 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewOne addSubview:view];
        }
    }else{
        for (int i = 0; i < 3; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewOne addSubview:view];
        }
    }
    
    
    //设置订单详情界面二
    
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgViewOne.origin.y + bgViewOne.size.height, SCREEN_WIDTH, FIXWIDTHORHEIGHT(160))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    [scroll addSubview:bgViewTwo];
    
    
    /*开始时间*/
    
    UILabel * startTime = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    startTime.text = [NSString stringWithFormat:@"开始时间：%@",_model.startTime];//@"开始时间：2015-11-11  15:30";
    startTime.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    startTime.textColor = color;
    [bgViewTwo addSubview:startTime];
    _startTime = startTime;
    
    /*服务时间*/
    
    UILabel * durationTime =[[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), startTime.origin.y + startTime.size.height, bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    durationTime.text = @"服务时长：";
    durationTime.textColor = color;
    durationTime.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    [bgViewTwo addSubview:durationTime];
    _duration = durationTime;

    
    
    UILabel * typeLable = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), durationTime.origin.y + durationTime.size.height, bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    _type = typeLable;
    typeLable.text = @"服务类型：";
    typeLable.textColor = color;
    typeLable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    [bgViewTwo addSubview:typeLable];
    
    /* 订单总额 */
    
    UILabel * sum = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), typeLable.origin.y + typeLable.size.height, bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(39))];
    sum.text = @"订单总额：";
    sum.textColor = color;
    sum.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    [bgViewTwo addSubview:sum];
    _sum = sum;
    
    /* 分割线 */
    if (iPHone6 || iPHone6Plus) {
        for (int i = 0; i < 3; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(45 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewTwo addSubview:view];
        }

    }else{
        for (int i = 0; i < 3; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewTwo addSubview:view];
        }

    }
    
    /**
        接送地点显示
     */
    UIImageView * bgViewThree = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgViewTwo.origin.y + bgViewTwo.size.height, SCREEN_WIDTH, FIXWIDTHORHEIGHT(60))];
    bgViewThree.image = [UIImage imageNamed:@"bg-5"];
    bgViewThree.userInteractionEnabled = YES;
    [scroll addSubview:bgViewThree];
    
    UILabel * shuttlePlace = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(75), FIXWIDTHORHEIGHT(40))];
    shuttlePlace.text = [NSString stringWithFormat:@"接送地点："];
    shuttlePlace.textColor = color;
    shuttlePlace.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    [bgViewThree addSubview:shuttlePlace];
    _shuttlePlace = shuttlePlace;
    
    UILabel * shuttlePlaceLable = [[UILabel alloc] initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(90), FIXWIDTHORHEIGHT(2), SCREEN_WIDTH - FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(56))];
    shuttlePlaceLable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(detailFontSize)];
    shuttlePlaceLable.numberOfLines = 0;
    _shuttlePlaceLable = shuttlePlaceLable;
    [bgViewThree addSubview:shuttlePlaceLable];
    
    
    UIButton * locationBtn = [UIButton createSystemButton];
    locationBtn.frame = CGRectMake(0, 0, SCREEN_WIDTH, FIXWIDTHORHEIGHT(60));
    [locationBtn setClickAction:^{
        [self locationBtnClicked];
    }];
    locationBtn.enabled = NO;
    _locationBtn = locationBtn;
    [bgViewThree addSubview:locationBtn];
    
    
    //设置补全资料按钮
    UIButton * wait = [UIButton buttonWithType:UIButtonTypeCustom];
    if (iPHone4oriPHone4s) {
        wait.frame = CGRectMake(FIXWIDTHORHEIGHT(30), bgViewThree.origin.y + bgViewThree.size.height + FIXWIDTHORHEIGHT(10), SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    }else if (iPHone5){
        wait.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT - FIXWIDTHORHEIGHT(130), SCREEN_WIDTH- FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    }else{
        wait.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT - FIXWIDTHORHEIGHT(120), SCREEN_WIDTH- FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    }
    
    wait.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    wait.layer.masksToBounds = YES;
    [wait setTitle:@"接单" forState:UIControlStateNormal];
    [wait setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [wait setBackgroundColor:[UIColor redColor]];
    wait.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(16)];
    [wait addTarget:self action:@selector(waitBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    _takeBtn = wait;
    [scroll addSubview:wait];
    
    scroll.contentSize = CGSizeMake(SCREEN_WIDTH, wait.origin.y + wait.size.height + FIXWIDTHORHEIGHT(5));
    
}

#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载
-(void)loadAbleDetailControllerData{
 
    [SVProgressHUD showWithStatus:@"加载中..."];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,ORDERINFO] body:self.dic block:^(id backData) {
        if ([backData objectForKey:@"status"]) {
            [SVProgressHUD dismiss];
            _detailOrder = [[backData objectForKey:@"result"] objectForKey:@"order"];
            [self uploadData:[[backData objectForKey:@"result"] objectForKey:@"order"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"获取订单详情失败"];
    }];
    
}
-(void)uploadData:(NSDictionary *)dic{
    NSLog(@"---%@",dic);
    _contactName.text = [NSString stringWithFormat:@"联系人：%@",[dic objectForKey:@"contactsName"]];
    
    _contactPhone.text = [NSString stringWithFormat:@"联系方式：%@",[dic objectForKey:@"contactsPhone"]];
    
    _patientName.text = [NSString stringWithFormat:@"就医者：%@",[dic objectForKey:@"patientName"]];
    
    _hospital.text = [NSString stringWithFormat:@"就诊医院：%@",[dic objectForKey:@"hospitalName"]];
    
    _startTime.text = [NSString stringWithFormat:@"开始时间：%@",[dic objectForKey:@"startTime"]];
    
    _duration.text = [NSString stringWithFormat:@"服务时长：%@小时",[dic objectForKey:@"duration"]];
    
    if ([[dic objectForKey:@"shuttle"] intValue]) {
        _shuttlePlaceLable.text = [NSString stringWithFormat:@"%@%@",[NSString stringWithFormat:@"%@",[dic objectForKey:@"shuttlePlace"]],[dic objectForKey:@"shuttleDetail"]];
        _locationBtn.enabled = YES;
    }else{
        _shuttlePlaceLable.text = @"无";
        _locationBtn.enabled = NO;
    }
    _type.text = [NSString stringWithFormat:@"服务类型：%@",[dic objectForKey:@"serviceTypeName"]];
    
    _sum.text = [NSString stringWithFormat:@"订单总额：%@",[dic objectForKey:@"money"]];
}
#pragma mark--
#pragma mark 事件
-(void)ongoingBackBtnClicked{
    if (self.block) {
        self.block(YES);
    }
    [self.navigationController popViewControllerAnimated:YES];
    
}
-(void)ongingCallBtnClicked{
    
    
    NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",[[_contactPhone.text componentsSeparatedByString:@"："] lastObject]];
    UIWebView * callWebView = [[UIWebView alloc]init];
    [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebView];
    
    
    
//    NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",[[_contactPhone.text componentsSeparatedByString:@"："] lastObject]];
//    
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    
    NSLog(@"打电话");
}
-(void)waitBtnClicked{
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    
    _takeBtn.enabled = NO;
    [SVProgressHUD showWithStatus:@"加载中"];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,TAKERORDER] body:self.dic block:^(id backData) {
        
        NSLog(@"接单success:%@",[backData objectForKey:@"msg"]);
        
        if ([[backData objectForKey:@"status"] intValue]) {
            _takeState = YES;
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            [_takeBtn setTitle:@"接单成功" forState:UIControlStateNormal];
        }else{
            _takeBtn.enabled = YES;
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
        
        
    } error:^(NSError *error) {
        NSLog(@"接单error:%@",error);
        _takeBtn.enabled = YES;
        [SVProgressHUD showErrorWithStatus:@"接单失败"];
    }];
    
    NSLog(@"接单");
}
-(void)returnYesOrNo:(takeOrderSuccessOrFail)block{
    self.block = block;
}

-(void)locationBtnClicked{
    NSLog(@"接入百度地图");
    
    NSLog(@"接入百度地图");
    showMapViewController * showMap = [[showMapViewController alloc] init];
    showMap.location = [_detailOrder objectForKey:@"shuttlePlace"];
    showMap.cityName = [_detailOrder objectForKey:@"city"];
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:showMap animated:YES];
}

#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

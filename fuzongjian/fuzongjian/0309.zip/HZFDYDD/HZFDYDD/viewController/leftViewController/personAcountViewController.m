//
//  personAcountViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/12.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "personAcountViewController.h"
#import "acountCustomCell.h"
#import "accountModel.h"
@interface personAcountViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView * acountTable;
@property(nonatomic,strong)StateManager * stateManager;
@property(nonatomic,strong)NSMutableArray * dataArr;
@property(nonatomic,strong)UILabel * sumLable;
@end

@implementation personAcountViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self loadAcountViewControllerData];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [SVProgressHUD dismiss];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configPersonAcountViewControllerUI];
    [self addHeaderAndFooterMJRefesh];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configPersonAcountViewControllerUI{
    
    _stateManager = [StateManager defaultManager];
    _dataArr = [NSMutableArray array];
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"我的账户"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    [self.view addSubview:title];
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];

    
    /*   累计盈利    */
    
    //背景图片
    UIImageView * bgSum = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(60))];
    bgSum.image = [UIImage imageNamed:@"bg-2"];
    [self.view addSubview:bgSum];
    
    //左侧图标  UIImageView
    UIImageView * smallImage = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(40))];
    smallImage.image = [UIImage imageNamed:@"profit"];
    [bgSum addSubview:smallImage];
    
    //累计盈利  UILabel
    UILabel * sumProfit = [[UILabel alloc]initWithFrame:CGRectMake(smallImage.origin.x + smallImage.size.width + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    sumProfit.text = @"累计盈利:";
    sumProfit.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [bgSum addSubview:sumProfit];
    
    //累计盈利  钱  UILabel
    UILabel * sum = [[UILabel alloc]initWithFrame:CGRectMake(sumProfit.origin.x + sumProfit.size.width + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(bgSum.size.width - sumProfit.origin.x - sumProfit.size.width - FIXWIDTHORHEIGHT(20)), FIXWIDTHORHEIGHT(40))];
    sum.text = @"￥0元";
    sum.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    sum.textColor = [UIColor redColor];
    _sumLable = sum;
    [bgSum addSubview:sum];
    
    /*   创建acountTable   */
    _acountTable = [[UITableView alloc]initWithFrame:CGRectMake(0, bgSum.origin.y + bgSum.size.height + FIXWIDTHORHEIGHT(10), SCREEN_WIDTH, SCREEN_HEIGHT - (bgSum.origin.y + bgSum.size.height + FIXWIDTHORHEIGHT(10))) style:UITableViewStylePlain];
    _acountTable.delegate = self;
    _acountTable.dataSource = self;
    _acountTable.backgroundColor = RGBCOLOR(240, 240, 240);
    _acountTable.showsVerticalScrollIndicator = NO;
    _acountTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _acountTable.tableFooterView = [UIView new];
    //[_acountTable registerClass:[acountCustomCell class] forCellReuseIdentifier:@"ACCOUNT"];
    [self.view addSubview:_acountTable];
    
    
}
#pragma mark  --  增加上拉下拉刷新
-(void)addHeaderAndFooterMJRefesh{
    /**
     *  下拉刷新
     */
    _acountTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{

        [self loadAcountViewControllerData];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([_acountTable.mj_header isRefreshing]) {
               [self stopMJRefresh:NO andMessage:@"刷新失败"];
            }
        });
    }];
    
    /**
     *  上拉刷新
     */
    _acountTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        
        [self loadAcountViewControllerData];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([_acountTable.mj_footer isRefreshing]) {
                [self stopMJRefresh:NO andMessage:@"刷新失败"];
            }
        });
        
    }];
    
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载(接口)
-(void)loadAcountViewControllerData{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    
    [AFNConnection getAccontData:[NSString stringWithFormat:@"%@%@",IPDERSS,ACCOUNT] body:dic block:^(id backData) {
        
        NSArray * array = [NSArray arrayWithArray:[backData objectForKey:@"dataArr"]];
        
        
        if (array.count) {
            
             _sumLable.text = [NSString stringWithFormat:@"%@元",[backData objectForKey:@"all"]];
            _dataArr = [NSMutableArray arrayWithArray:array];
            
            [self stopMJRefresh:YES andMessage:@"刷新成功"];
            
            [_acountTable reloadData];
            
        }else{
            [self stopMJRefresh:NO andMessage:@"当前没有结算的账单"];
        }
        
    } error:^(NSError *error) {
        NSLog(@"个人账户数据获取error:%@",error);
    }];
    
}
/**
 *  停止刷新
 */
-(void)stopMJRefresh:(BOOL)state andMessage:(NSString *)message{
    
    
    if ([_acountTable.mj_header isRefreshing]||[_acountTable.mj_footer isRefreshing]) {
        
        if (state) {
            [SVProgressHUD showSuccessWithStatus:message];
        }else{
            [SVProgressHUD showErrorWithStatus:message];
        }
        
    }

    if ([_acountTable.mj_footer isRefreshing]) {
        [_acountTable.mj_footer endRefreshing];
    }
    if ([_acountTable.mj_header isRefreshing]) {
        [_acountTable.mj_header endRefreshing];
    }
}
#pragma mark--
#pragma mark 事件
#pragma mark  返回按钮事件
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * acount = @"ACCOUNT";
    
    acountCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:acount];
    
    if (!cell) {
        cell = [[acountCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:acount];
    }
    cell.backgroundColor = RGBCOLOR(240, 240, 240);
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    accountModel * model = _dataArr[indexPath.row];
    
    cell.timeDisplay.text = [NSString stringWithFormat:@"%@",model.serviceTime];
    cell.taxDisplay.text = [NSString stringWithFormat:@"%@",model.charge];
    cell.sumDisplay.text = [NSString stringWithFormat:@"%@",[model.realEarn description]];
    cell.orderDisplay.text = [NSString stringWithFormat:@"%@",model.allmoney];
    cell.monthDisplay.text = [NSString stringWithFormat:@"%@~%@",[[model.firstDay componentsSeparatedByString:@" "] firstObject],[[model.lastDay componentsSeparatedByString:@" "] firstObject]];
    
    return  cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return FIXWIDTHORHEIGHT(125);
    
}

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

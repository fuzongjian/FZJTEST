//
//  messageViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "messageViewController.h"
#import "messageCustomCell.h"
#import "messageModel.h"
#import "messageDetailController.h"
@interface messageViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView * messageTable;
@property(nonatomic,strong)NSMutableArray * dataArr;

@property(nonatomic,assign)NSInteger  selectIndex;

@end

@implementation messageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configMessageViewControllerUI];
    [self addHeaderAndFooterMJRefesh];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self loadMessageViewControllerData];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [SVProgressHUD dismiss];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configMessageViewControllerUI{
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    self.selectIndex = 0;
    
    //标题
    
    
    UIView * bigview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 64)];
    bigview.backgroundColor = RGBCOLOR(230, 230, 230);
    [self.view addSubview:bigview];
    
    UILabel * title = [[UILabel alloc] init];
    title.frame = CGRectMake(50, 20, SCREEN_WIDTH - 100, 44);
    title.text = @"消息";
    title.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(18)];
    title.textAlignment = NSTextAlignmentCenter;
    title.textColor = [UIColor redColor];
    [self.view addSubview:title];
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];

    //创建tableView
    _messageTable = [[UITableView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(0), 64 + FIXWIDTHORHEIGHT(5), SCREEN_WIDTH, SCREEN_HEIGHT - 64 - FIXWIDTHORHEIGHT(5))];
    _messageTable.backgroundColor = RGBCOLOR(240, 240, 240);
    [self.view addSubview:_messageTable];
    _messageTable.delegate = self;
    _messageTable.dataSource = self;
    _messageTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _messageTable.showsVerticalScrollIndicator = NO;
    _messageTable.tableFooterView = [UIView new];

 
}
-(void)addHeaderAndFooterMJRefesh{
    
    _messageTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self loadMessageViewControllerData];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([_messageTable.mj_header isRefreshing]) {
                [_messageTable.mj_header endRefreshing];
                [self stopRefreshingWithState:NO showString:@"刷新失败"];
            }
        });
    }];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载
-(void)loadMessageViewControllerData{

    if ([StateManager defaultManager].reachState == 0) {
        [self stopRefreshingWithState:NO showString:@"网络不可用"];
        return;
    }

    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    
    [dic setObject:@([[StateManager defaultManager].userId intValue]) forKey:@"userid"];
    [dic setObject:@2 forKey:@"type"];
    
    [AFNConnection getMessageData:[NSString stringWithFormat:@"%@%@",IPDERSS,MESSAGE] body:dic block:^(id backData) {
        if ([(NSArray *)backData count]) {
            _dataArr = [NSMutableArray arrayWithArray:backData];
            [_messageTable reloadData];
            [self stopRefreshingWithState:YES showString:@"刷新成功"];
        }else{
            [self stopRefreshingWithState:YES showString:[backData objectForKey:@"msg"]];
            NSLog(@"%@",[backData objectForKey:@"msg"]);
        }
     } error:^(NSError *error) {
         [self stopRefreshingWithState:NO showString:@"获取数据失败"];
    }];
}
-(void)stopRefreshingWithState:(BOOL)state showString:(NSString *)message{
    if (state) {
        [SVProgressHUD dismiss];
    }else{
        [SVProgressHUD showErrorWithStatus:message];
    }
    
    
    if ([_messageTable.mj_header isRefreshing]) {
        [_messageTable.mj_header endRefreshing];
    }
    if ([_messageTable.mj_footer isRefreshing]) {
        [_messageTable.mj_footer endRefreshing];
    }
    
}
#pragma mark--
#pragma mark 事件
#pragma mark  返回按钮事件
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * messageID = @"messageID";
    messageCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:messageID];
    if (!cell) {
        cell = [[messageCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:messageID];
    }
    cell.backgroundColor = RGBCOLOR(240, 240, 240);
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    messageModel * model = _dataArr[indexPath.row];
    cell.category.text = [NSString stringWithFormat:@"%@",model.title];
    cell.time.text = [NSString stringWithFormat:@"%@",model.createTime];
    cell.orderStatus.text = [NSString stringWithFormat:@"%@",model.content];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    messageDetailController * messageDetail = [[messageDetailController alloc]init];
    messageDetail.model = _dataArr[indexPath.row];
    [self presentViewController:messageDetail animated:YES completion:nil];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat addWidth = 0;
    
    return FIXWIDTHORHEIGHT(63) + addWidth;
}
#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark--  菊花残
-(void)popBigIndicatorToShowProgress{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = [UIColor clearColor];
    bgView.alpha = 0.9;
    bgView.tag = 14504823;
    [self.view addSubview:bgView];
    //菊花
    UIView * midle = [[UIView alloc]init];
    midle.size = CGSizeMake(60, 60);
    midle.center = self.view.center;
    midle.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    midle.layer.masksToBounds = YES;
    midle.backgroundColor = RGBCOLOR(108, 108, 108);
    [bgView addSubview:midle];
    UIActivityIndicatorView * activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activity.frame = CGRectMake(10, 10, 40, 40);
    
    [midle addSubview:activity];
    [activity startAnimating];
}
-(void)hidenBigIndicatorToShowProgress{
    
    for (UIView * view in self.view.subviews) {
        if (view.tag == 14504823) {
            [view removeFromSuperview];
        }
    }
}
#pragma mark--弹出提示窗口
-(void)popSuccessOrFailMessage:(NSString *)message andState:(BOOL)state{
    
    NSInteger second = 1;//几秒之后消失
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    bgView.tag = 41025787;
    [self.view addSubview:bgView];
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [bgView addSubview:popView];
    
    UIImageView * success = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, popView.size.height * 0.1, popView.size.width * 0.3, popView.size.width * 0.3)];
    if (state) {
        success.image = [UIImage imageNamed:@"sucess@2x_47"];
    }else{
        success.image = [UIImage imageNamed:@"warning"];
        second = 2;
    }
    
    [popView addSubview:success];
    
    UILabel * warn = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(5),success.size.height, popView.size.width - FIXWIDTHORHEIGHT(10), popView.size.height - popView.size.width * 0.3)];
    warn.text = message;
    warn.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
    warn.numberOfLines = 0;
    warn.textAlignment = NSTextAlignmentCenter;
    [popView addSubview:warn];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapWarnBtn)];
    tap.numberOfTapsRequired = 1;
    [bgView addGestureRecognizer:tap];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(second * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [bgView removeFromSuperview];
    });
    
}
-(void)tapWarnBtn{
    
    for (UIView * view in self.view.subviews) {
        if (view.tag == 41025787) {
            [view removeFromSuperview];
        }
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

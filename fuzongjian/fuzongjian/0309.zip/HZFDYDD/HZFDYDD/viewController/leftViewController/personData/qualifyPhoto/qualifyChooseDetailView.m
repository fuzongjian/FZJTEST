//
//  qualifyChooseDetailView.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/5.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "qualifyChooseDetailView.h"
#import "qualificationViewController.h"
#import "chooseDetailCell.h"
#import "chooseModel.h"

@interface qualifyChooseDetailView ()<UICollectionViewDataSource,customCellBtnClicked,UICollectionViewDelegate>
/**
 *  创建collect用于视图展示
 */
@property(nonatomic,strong)UICollectionView * collect;

@property(nonatomic,strong)UIView * toolView;//显示选择状态
@property(nonatomic,strong)UIButton * preview;
@property(nonatomic,strong)UIButton * finish;
@property(nonatomic,strong)UILabel * numLable;//显示张数

/**
 *  存储已经选择的照片
 */
@property(nonatomic,strong)NSMutableArray * selectArr;

/**
 *  存放大图
 */
@property(nonatomic,strong)NSMutableArray * bigPhoto;
@end

@implementation qualifyChooseDetailView

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configQualifyChooseDetailViewUI];
}

#pragma mark --
#pragma mark 初始化UI
-(void)configQualifyChooseDetailViewUI{
    
    NSLog(@"第一次");
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _selectArr = [NSMutableArray array];
    _bigPhoto = [NSMutableArray array];
    
    //设置标题
    UILabel * title = [Tool setCustomViewTitle:self.titleStr];
    title.textColor = [UIColor blackColor];
    title.frame = CGRectMake(0, 0, SCREEN_WIDTH, 44);
    self.navigationItem.titleView = title;
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(BackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    //创建collectionVew
    UICollectionViewFlowLayout * flowLayOut = [[UICollectionViewFlowLayout alloc]init];
    [flowLayOut setScrollDirection: UICollectionViewScrollDirectionVertical];
    _collect = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 49) collectionViewLayout:flowLayOut];
    [self.view addSubview:_collect];
    _collect.delegate = self;
    _collect.dataSource = self;
    _collect.backgroundColor = [UIColor whiteColor];
    
    //注册
    [self.collect registerClass:[chooseDetailCell class] forCellWithReuseIdentifier:@"cell"];
    
    /*    照片完成和预览     */
    _toolView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 49, SCREEN_WIDTH, 49)];
    _toolView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_toolView];
    
    //显示选择张数
    UILabel * numLable = [[UILabel alloc]initWithFrame:CGRectMake(_toolView.size.width * 0.3, 0, _toolView.size.width * 0.4, 49)];
    numLable.text = [NSString stringWithFormat:@"0/%d",(int)self.addNum];
    numLable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    numLable.textAlignment = NSTextAlignmentCenter;
    numLable.textColor = [UIColor blueColor];
    [_toolView addSubview:numLable];
    _numLable = numLable;
    
    //完成按钮
    UIButton * finish = [UIButton buttonWithType:UIButtonTypeSystem];
    finish.frame = CGRectMake(SCREEN_WIDTH - 49 - FIXWIDTHORHEIGHT(10), 0, 49, 49);
    [finish setTitle:@"完成" forState:UIControlStateNormal];
    finish.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [finish addTarget:self action:@selector(finishBtn) forControlEvents:UIControlEventTouchUpInside];
    [_toolView addSubview:finish];
    _finish = finish;
    _finish.enabled = NO;

    
    //取消按钮设置
    UIButton  * cancle = [UIButton buttonWithType:UIButtonTypeSystem];
    cancle.frame = CGRectMake(0, 0, 44, 44);
    [cancle setTitle:@"取消" forState:UIControlStateNormal];
    cancle.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:cancle];
    [cancle addTarget:self action:@selector(cancleBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
}


#pragma mark--
#pragma mark 数据回调


#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)BackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
    
    //[self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--取消按钮设置
-(void)cancleBtnClicked{
    
    NSArray * arr = self.navigationController.viewControllers;
    [self.navigationController popToViewController:arr[0] animated:YES];
    
}
#pragma mark--完成按钮设置
/**
 *  点击完成后回到资质认证界面
 */
-(void)finishBtn{
    

//    [self dismissViewControllerAnimated:YES completion:nil];
//    
//    if (self.dismissblock) {
//        
//        self.dismissblock();
//        
//    }
    


    NSArray * arr = self.navigationController.viewControllers;

    [self.navigationController popToViewController:arr[0] animated:YES];
    
    
    if (self.returnPhotoArr) {
        
        self.returnPhotoArr(_selectArr);
        
    }
    
    
    
}
-(void)returnDismiss:(dismiss)block{
    
    self.dismissblock = block;
    
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.fetchResult.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * identify = @"cell";
    chooseDetailCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
    [cell sizeToFit];
    if (!cell) {
        NSLog(@"------------");
    }
    
    chooseModel * model = _arr[indexPath.row];
    PHAsset *asset = model.asset;
    
    CGSize size = cell.frame.size;
    size.width *= 2;
    size.height *= 2;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:asset size:size resizeMode:PHImageRequestOptionsResizeModeFast completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.bgView.image = result;
            });
        }];
    });
    cell.cellDelegate = self;
    cell.cellRow = indexPath.row;
    
    if (model.selected) {
        cell.btnN.hidden = YES;
        cell.btnY.hidden = NO;
    }else{
        cell.btnN.hidden = NO;
        cell.btnY.hidden = YES;
    }
    
    return cell;
    
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (iPHone6) {
        return CGSizeMake(87, 87);
    }else if (iPHone6Plus){
        return CGSizeMake(97, 97);
    }else{
        return CGSizeMake(100, 100);
    }
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(5, 5, 0, 5);//上左下右
    
}
// 单元格最小间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}
// 单元格最小行距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}
#pragma mark--实现自定义cell的协议方法
-(void)customBtnClicked:(NSInteger)cellRow{
    
    chooseModel * model = _arr[cellRow];
    
    PHAsset * asset = model.asset;
    //取到外面该行的cell
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:cellRow inSection:0];
    chooseDetailCell * cell = (chooseDetailCell *)[_collect cellForItemAtIndexPath:indexPath];
    
    if(cell.state && _selectArr.count == self.addNum){//选择照片达到上限
        cell.btnN.hidden = NO;
        cell.btnY.hidden = YES;
        [self popWarningMessage:[NSString stringWithFormat:@"本次最多选择%d张",(int)self.addNum]];
    }else if (_selectArr.count == 0){//第一次添加
        
        [_selectArr addObject:asset];
        [self addbigPhoto:asset];
        
    }else if (cell.state){
        if (![self searchDataFrom:asset]) {
            
            [_selectArr addObject:asset];
            model.selected = YES;
            [self addbigPhoto:asset];
            
        }
    }else if (!cell.state){
        if ([self searchDataFrom:asset]) {
            
            [self removeBigPhoto:[self searchDataFrom:asset]];
            [_selectArr removeObject:asset];
            model.selected = NO;
        }
    }
    if (_selectArr.count == 0) {
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _finish.enabled = NO;
    }else{
        _numLable.text = [NSString stringWithFormat:@"%d/%d",(int)_selectArr.count,(int)self.addNum];
        _finish.enabled = YES;
    }

}
-(NSInteger)searchDataFrom:(PHAsset *)fetchResult{
    
    NSInteger intger = 0;
    
    for (int i = 0; i < _selectArr.count; i ++) {
        if ([[_selectArr[i] valueForKey:@"filename"] isEqualToString:[fetchResult valueForKey:@"filename"]]) {
            intger = i;
        }
    }
    return intger;
}
-(void)addbigPhoto:(PHAsset *)asset{
    
//    [[PhotoTool sharePhotoTool] requestImageForAsset:asset size:PHImageManagerMaximumSize resizeMode:PHImageRequestOptionsResizeModeFast completion:^(UIImage *result) {
//        [_bigPhoto addObject:result];
//    }];
    
}
-(void)removeBigPhoto:(NSInteger)num{
    
//    UIImage * image = _selectArr[num];
//    [_bigPhoto removeObject:image];
    
}
#pragma mark--弹出警示窗口
-(void)popWarningMessage:(NSString *)message{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.9;
    bgView.tag = 41025787;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [bgView addSubview:popView];
    
    UIImageView * success = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, popView.size.height * 0.1, popView.size.width * 0.3, popView.size.width * 0.3)];
    success.image = [UIImage imageNamed:@"warning"];
    [popView addSubview:success];
    
    UILabel * warn = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(5),success.size.height, popView.size.width - FIXWIDTHORHEIGHT(10), popView.size.height - popView.size.width * 0.3)];
    warn.text = message;
    warn.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
    warn.numberOfLines = 0;
    warn.textAlignment = NSTextAlignmentCenter;
    [popView addSubview:warn];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapBtn)];
    tap.numberOfTapsRequired = 1;
    [bgView addGestureRecognizer:tap];
    
}
-(void)tapBtn{
    
    for (UIView * view in [UIApplication sharedApplication].keyWindow.subviews) {
        if (view.tag == 41025787) {
            [view removeFromSuperview];
        }
    }
    
}

#pragma mark--
#pragma mark 通知注册及销毁

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

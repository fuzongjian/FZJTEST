//
//  qualifyChooseView.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/5.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  定义block
 *
 *  @param dataArr 返回的照片数组
 */
typedef void (^DoneBlock)(NSArray * dataArr);


@interface qualifyChooseView : UIViewController
/**
 *  照片相关数据
 */
@property(nonatomic,strong)NSArray * arr;
/**
 *  传递可加载的图片数量
 */
@property(nonatomic,assign)NSInteger addNum;

/**
 *  选择照片之后的回调
 */
@property(nonatomic,copy)DoneBlock returnPhotoArr;

-(void)returnPhotoArr:(DoneBlock)block;


@end

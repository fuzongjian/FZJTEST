//
//  qualifyChooseView.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/5.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "qualifyChooseView.h"
#import "chooseCustomCell.h"
#import "qualifyChooseDetailView.h"
#import "chooseModel.h"
@interface qualifyChooseView ()<UITableViewDataSource,UITableViewDelegate>
/**
 *  创建tableView
 */
@property(nonatomic,strong)UITableView * chooseTable;
@end

@implementation qualifyChooseView

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configQualifyChooseViewUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configQualifyChooseViewUI{
    
    self.view.backgroundColor = [UIColor whiteColor];

    //设置标题
    UILabel * album = [Tool setCustomViewTitle:@"相簿"];
    album.textColor = [UIColor blackColor];
    self.navigationItem.titleView = album;
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(BackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];


    _chooseTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [self.view addSubview:_chooseTable];
    _chooseTable.dataSource = self;
    _chooseTable.delegate = self;
    _chooseTable.tableFooterView = [UIView new];
    _chooseTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
}
#pragma mark--
#pragma mark 数据回调
-(void)returnPhotoArr:(DoneBlock)block{
    self.returnPhotoArr = block;
}
#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)BackBtnClicked{
    
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _arr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * photo = @"photo";
    
    chooseCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:photo];
    if (!cell) {
        cell = [[chooseCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:photo];
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSeparatorStyleNone;
    
    PhotoAblumList * ablumList = _arr[indexPath.row];
    cell.title.text = ablumList.title;
    cell.subTitle.text = [NSString stringWithFormat:@"%d",(int)ablumList.count];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[PhotoTool sharePhotoTool] requestImageForAsset:ablumList.headImageAsset size:CGSizeMake(FIXWIDTHORHEIGHT(46), FIXWIDTHORHEIGHT(46)) resizeMode:PHImageRequestOptionsResizeModeFast completion:^(UIImage *result) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.iconImage.image = result;
            });
        }];
    });

    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return FIXWIDTHORHEIGHT(50);
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    NSLog(@"fuzongjian");
    
    
    qualifyChooseDetailView * chooseDetail = [[qualifyChooseDetailView alloc]init];
    
    PhotoAblumList * ablumList = _arr[indexPath.row];
    
    chooseDetail.titleStr = ablumList.title;
    
    
    chooseDetail.fetchResult = [[PhotoTool sharePhotoTool] fetchAssetsInAssetCollection:ablumList.assetCollection ascending:YES];
    
    PHFetchResult * fetch = [[PhotoTool sharePhotoTool] fetchAssetsInAssetCollection:ablumList.assetCollection ascending:YES];
    NSMutableArray * dataArr = [NSMutableArray array];
    for (PHAsset * asset in fetch) {
        chooseModel * model = [[chooseModel alloc]init];
        model.asset = asset;
        model.selected = NO;
        [dataArr addObject:model];
    }
    chooseDetail.arr = dataArr;
    chooseDetail.addNum = self.addNum;
    chooseDetail.returnPhotoArr = self.returnPhotoArr;//block的传递

    
    [self.navigationController pushViewController:chooseDetail animated:YES];
    
    //[self presentViewController:chooseDetail animated:YES completion:nil];
    
}
#pragma mark--
#pragma mark 通知注册及销毁

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

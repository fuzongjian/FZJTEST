//
//  UnderQualificationViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "UnderSuperViewController.h"
typedef void (^returnQualitifyBlock)(BOOL state);
@interface UnderQualificationViewController : UnderSuperViewController

@property(nonatomic,copy)returnQualitifyBlock block;

-(void)returnState:(returnQualitifyBlock)block;

@end

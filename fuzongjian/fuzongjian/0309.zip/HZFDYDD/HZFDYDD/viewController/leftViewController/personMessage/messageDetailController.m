//
//  messageDetailController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/15.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "messageDetailController.h"
#import "messageModel.h"
@interface messageDetailController ()

@end

@implementation messageDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configMessageDetailControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configMessageDetailControllerUI{
     self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"消息详情"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    [self.view addSubview:title];

    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];

    //背景
    
    UIImageView * bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(60))];
    bgView.image = [UIImage imageNamed:@"bg-2"];
    [self.view addSubview:bgView];
    
    //消息类别
    UILabel * category = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(5), SCREEN_WIDTH * 0.5, FIXWIDTHORHEIGHT(20))];
    category.text = self.model.title;
    category.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [bgView addSubview:category];
    
    //消息时间
    UILabel * time = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.53, FIXWIDTHORHEIGHT(5), SCREEN_WIDTH * 0.4, FIXWIDTHORHEIGHT(20))];
    time.text = self.model.createTime;
    time.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12)];
    time.textAlignment = NSTextAlignmentRight;
    [bgView addSubview:time];

    UILabel * orderStatus = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(30), SCREEN_WIDTH * 0.8, FIXWIDTHORHEIGHT(20))];
    orderStatus.text = self.model.content;
    orderStatus.numberOfLines = 0;
    orderStatus.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(13)];
    CGRect  frame = orderStatus.frame;
    frame.size = CGSizeMake(SCREEN_WIDTH * 0.8, 10000);
    orderStatus.frame = frame;
    [orderStatus sizeToFit];
    [bgView addSubview:orderStatus];
    
    CGRect bgFrame = bgView.frame;
    bgFrame.size = CGSizeMake(SCREEN_WIDTH, FIXWIDTHORHEIGHT(60) + orderStatus.size.height - FIXWIDTHORHEIGHT(20));
    bgView.frame = bgFrame;
    
    //底部logo
    UIImageView * logo = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.44, SCREEN_HEIGHT * 0.86, SCREEN_WIDTH * 0.12,SCREEN_HEIGHT * 0.125)];
    logo.image = [UIImage imageNamed:@"logo2"];
    [self.view addSubview:logo];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

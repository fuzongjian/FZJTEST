//
//  messageCustomCell.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/17.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface messageCustomCell : UITableViewCell
@property(nonatomic,strong)UILabel * category;//消息类别
@property(nonatomic,strong)UILabel * time;//消息时间
@property(nonatomic,strong)UILabel * orderStatus;//订单状态
@property(nonatomic,strong)UIImageView * smallImage;
@property(nonatomic,strong)UIImageView * bgView;
@property(nonatomic,assign)BOOL isOpen;//展开状态
@end

//
//  messageCustomCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/17.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "messageCustomCell.h"

@implementation messageCustomCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configMessageCustomCellUI];
    }
    return self;
}

-(void)configMessageCustomCellUI{
    
    //背景
    UIImageView * bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, FIXWIDTHORHEIGHT(60))];
    _bgView = bgView;
    bgView.image = [UIImage imageNamed:@"bg-2"];
    [self.contentView addSubview:bgView];
    bgView.userInteractionEnabled = YES;
    
    //消息类别
    UILabel * category = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(5), SCREEN_WIDTH * 0.5, FIXWIDTHORHEIGHT(20))];
    category.text = @"您的订单已被抢";
    category.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [bgView addSubview:category];
    _category = category;
    
    //消息时间
    UILabel * time = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.53, FIXWIDTHORHEIGHT(5), SCREEN_WIDTH * 0.4, FIXWIDTHORHEIGHT(20))];
    time.text = @"2015-11-11 12:30:30";
    time.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12)];
    time.textAlignment = NSTextAlignmentRight;
    [bgView addSubview:time];
    _time = time;
    
    //订单状态
    UILabel * orderStatus = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(30), SCREEN_WIDTH * 0.8, FIXWIDTHORHEIGHT(20))];
    orderStatus.text = @"订单状态：已完成";
    orderStatus.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(12)];
    orderStatus.numberOfLines = 0;
    [bgView addSubview:orderStatus];
    _orderStatus = orderStatus;
    //小箭头
    UIImageView * smallImage = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.9, FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(15))];
    smallImage.image = [UIImage imageNamed:@"more"];
    // UIImageOrientationDown 旋转180   UIImageOrientationUp 保持来的状态 UIImageOrientationLeft 逆转90  UIImageOrientationRight 顺转90
    // smallImage.image = [UIImage imageWithCGImage:smallImage.image.CGImage scale:1 orientation:UIImageOrientationRight];
    [bgView addSubview:smallImage];
    _smallImage = smallImage;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

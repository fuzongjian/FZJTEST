//
//  messageDetailController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/15.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>
@class messageModel;
@interface messageDetailController : UIViewController
@property(nonatomic,strong)messageModel * model;
@end

//
//  acountCustomCell.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/16.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface acountCustomCell : UITableViewCell

@property(nonatomic,strong)UILabel * timeDisplay;//服务时长
@property(nonatomic,strong)UILabel * orderDisplay;//订单总额
@property(nonatomic,strong)UILabel * taxDisplay;//代缴费用
@property(nonatomic,strong)UILabel * sumDisplay;//所得金额
@property(nonatomic,strong)UILabel * monthDisplay;//时间显示
@end

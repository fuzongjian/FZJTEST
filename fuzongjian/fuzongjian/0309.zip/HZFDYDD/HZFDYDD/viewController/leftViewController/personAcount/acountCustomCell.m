//
//  acountCustomCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/16.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "acountCustomCell.h"

@implementation acountCustomCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self configAcountCustomCellUI];
    }
    return self;
}

-(void)configAcountCustomCellUI{
    
    //月份显示  UIImageView
    UIImageView * month = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(40))];
    month.image = [UIImage imageNamed:@"month-title"];
    [self.contentView addSubview:month];
    
    //月份显示
    float margin = -7;
    if (iPHone6) {
        margin = -8;
    }
    if (iPHone6Plus) {
        margin = -9;
    }
    _monthDisplay = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(margin), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(40))];
    _monthDisplay.text = @"2015-11-11~2015-12-10";
    _monthDisplay.textColor = RGBCOLOR(155, 155, 155);
    _monthDisplay.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(13)];
    _monthDisplay.textAlignment = NSTextAlignmentCenter;
    
    [month addSubview:_monthDisplay];
    
    float lableFont = FIXWIDTHORHEIGHT(11);
    float valueFont = FIXWIDTHORHEIGHT(15);
    UIColor * color = RGBCOLOR(107, 107, 107);
    
    /*   本月服务时长   */
    
    //图标  UIImageView
    UIImageView * timeImage = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20),FIXWIDTHORHEIGHT(35), FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(30))];
    timeImage.image = [UIImage imageNamed:@"service-time"];
    [self.contentView addSubview:timeImage];
    UILabel * timeLable = [[UILabel alloc]initWithFrame:CGRectMake(timeImage.origin.x + timeImage.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    timeLable.text = @"本月服务时长";
    timeLable.textColor = color;
    timeLable.textAlignment = NSTextAlignmentCenter;
    timeLable.font = [UIFont systemFontOfSize:lableFont];
    [self.contentView addSubview:timeLable];
    //时间显示
    UILabel * timeDisplay = [[UILabel alloc]initWithFrame:CGRectMake(timeImage.origin.x + timeImage.size.width + FIXWIDTHORHEIGHT(5),timeLable.size.height, FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    timeDisplay.text = @"150小时";
    timeDisplay.font = [UIFont systemFontOfSize:valueFont];
    timeDisplay.textAlignment = NSTextAlignmentCenter;
    _timeDisplay = timeDisplay;
    [self.contentView addSubview:timeDisplay];

     /*   本月订单总额   */
    
    
    //图标
    UIImageView * orderImage = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.5 + FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(35), FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(30))];
    orderImage.image = [UIImage imageNamed:@"month-order"];
    [self.contentView addSubview:orderImage];
    UILabel * orderLable = [[UILabel alloc]initWithFrame:CGRectMake(orderImage.origin.x + orderImage.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    orderLable.text = @"本月订单总额";
    orderLable.textColor = color;
    orderLable.textAlignment = NSTextAlignmentCenter;
    orderLable.font = [UIFont systemFontOfSize:lableFont];
    [self.contentView addSubview:orderLable];
    //总额显示
    UILabel * orderDisplay = [[UILabel alloc]initWithFrame:CGRectMake(orderImage.origin.x + orderImage.size.width + FIXWIDTHORHEIGHT(5),orderLable.size.height, FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    orderDisplay.text = @"￥6800元";
    orderDisplay.textAlignment = NSTextAlignmentCenter;
    orderDisplay.font = [UIFont systemFontOfSize:valueFont];
    _orderDisplay = orderDisplay;
    [self.contentView addSubview:orderDisplay];
    
    //分割线
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10),timeLable.size.height + timeDisplay.size.height + FIXWIDTHORHEIGHT(-8), SCREEN_WIDTH - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(1))];
    view.backgroundColor = RGBCOLOR(226, 226, 226);
    [self.contentView addSubview:view];
    
    /*   代扣代缴费用   */
    
    //图标
    UIImageView * taxImage = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), view.origin.y + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(30))];
    taxImage.image = [UIImage imageNamed:@"cost"];
    [self.contentView addSubview:taxImage];
    UILabel * taxLable = [[UILabel alloc]initWithFrame:CGRectMake(taxImage.origin.x + taxImage.size.width + FIXWIDTHORHEIGHT(5), view.origin.y + FIXWIDTHORHEIGHT(-5), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    taxLable.text = @"代扣代缴费用";
    taxLable.font = [UIFont systemFontOfSize:lableFont];
    taxLable.textAlignment = NSTextAlignmentCenter;
    taxLable.textColor = color;
    [self.contentView addSubview:taxLable];
    //代扣代缴费用显示
    UILabel * taxDisplay = [[UILabel alloc]initWithFrame:CGRectMake(taxImage.origin.x + taxImage.size.width + FIXWIDTHORHEIGHT(5), taxLable.size.height + FIXWIDTHORHEIGHT(45), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    taxDisplay.text = @"￥800元";
    taxDisplay.font = [UIFont systemFontOfSize:valueFont];
    taxDisplay.textAlignment = NSTextAlignmentCenter;
    _taxDisplay = taxDisplay;
    [self.contentView addSubview:taxDisplay];
    
    /*   实际所得金额   */
    
    //图标
    UIImageView * sumImage = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.5 + FIXWIDTHORHEIGHT(30), view.origin.y + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(30))];
    sumImage.image = [UIImage imageNamed:@"income"];
    [self.contentView addSubview:sumImage];
    UILabel * sumLable = [[UILabel alloc]initWithFrame:CGRectMake(sumImage.origin.x + sumImage.size.width + FIXWIDTHORHEIGHT(5), view.origin.y + FIXWIDTHORHEIGHT(-5), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    sumLable.text = @"实际所得金额";
    sumLable.textAlignment = NSTextAlignmentCenter;
    sumLable.font = [UIFont systemFontOfSize:lableFont];
    sumLable.textColor = color;
    [self.contentView addSubview:sumLable];
    //实际所得金额显示
    UILabel * sumDisplay = [[UILabel alloc]initWithFrame:CGRectMake(sumImage.origin.x + sumImage.size.width + FIXWIDTHORHEIGHT(5), sumLable.size.height + FIXWIDTHORHEIGHT(45), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(40))];
    sumDisplay.text = @"￥6000元";
    sumDisplay.font = [UIFont systemFontOfSize:valueFont];
    sumDisplay.textAlignment = NSTextAlignmentCenter;
    sumDisplay.textColor = [UIColor redColor];
    _sumDisplay = sumDisplay;
    [self.contentView addSubview:sumDisplay];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  leftViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "leftViewController.h"
#import "personAcountViewController.h"
#import "personDataController.h"
#import "settingViewController.h"
#import "messageViewController.h"

#import "UIImageView+WebCache.h"

#import "UIButton+WebCache.h"

@interface leftViewController ()<UIAlertViewDelegate>
@property(nonatomic,strong)UIButton * iconBtn;
@property(nonatomic,strong)UILabel * nameLable;
@end

@implementation leftViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self configIconUI];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configLeftViewControllerUI];
    [self registerNotification];
    
}

#pragma mark --
#pragma mark 初始化UI
-(void)configLeftViewControllerUI{
    
    //背景颜色
    self.view.backgroundColor = RGBCOLOR(53, 53, 53);
    
    //头像设置
    
    UIButton * iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    iconBtn.frame = CGRectMake(leftWidth * 0.2, FIXWIDTHORHEIGHT(34), leftWidth * 0.6, leftWidth * 0.6);
    [iconBtn setBackgroundImage:[UIImage imageNamed:@"default-face-拷贝"] forState:UIControlStateNormal];
    [iconBtn addTarget:self action:@selector(iconBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    iconBtn.layer.cornerRadius = leftWidth * 0.3;
    iconBtn.layer.masksToBounds = YES;
    _iconBtn = iconBtn;
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:ICONPATH] length]) {
        [_iconBtn sd_setImageWithURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:ICONPATH]] forState:UIControlStateNormal];
    }
    [self.view addSubview:iconBtn];
    
    //姓名设置
    UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(0), iconBtn.origin.y + iconBtn.size.height, leftWidth - FIXWIDTHORHEIGHT(1), FIXWIDTHORHEIGHT(40))];
    _nameLable = nameLabel;
    _nameLable.text = [[NSUserDefaults standardUserDefaults] objectForKey:NAME];
    
    nameLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    nameLabel.textColor = RGBCOLOR(219,219, 219);
    [self.view addSubview:nameLabel];
    
   //分割线
    UIView * line = [[UIView alloc]initWithFrame:CGRectMake(leftWidth * 0.1, nameLabel.origin.y + nameLabel.size.height, leftWidth * 0.8, FIXWIDTHORHEIGHT(2))];
    line.backgroundColor = RGBCOLOR(70, 70, 70);
    [self.view addSubview:line];

    //加载图片及标题
    NSArray * photoArr = [NSArray arrayWithObjects:@"account",@"setup",@"message",@"exit",nil];
    NSArray * titleArr = [NSArray arrayWithObjects:@"账户",@"设置",@"消息",@"退出",nil];
    for (int i = 0; i < 4; i++) {
        
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(leftWidth * 0.2, line.origin.y + line.size.height + FIXWIDTHORHEIGHT(15 + (40 + 15) * i) , leftWidth * 0.6, leftWidth * 0.3)];
        
        //选项图标
        UIImageView * img = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(0), leftWidth * 0.3, leftWidth * 0.3)];
        img.image = [UIImage imageNamed:photoArr[i]];
        [view addSubview:img];
        
        //选项标题
        UILabel * title = [[UILabel alloc]initWithFrame:CGRectMake(leftWidth * 0.3, FIXWIDTHORHEIGHT(0), leftWidth * 0.3, leftWidth * 0.3)];
        title.text = titleArr[i];
        title.textColor = RGBCOLOR(155, 155, 155);
        title.textAlignment = NSTextAlignmentCenter;
        title.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(leftWidth * 0.12)];
        if (iPHone6Plus) {
            title.font = [UIFont systemFontOfSize:18];
        }
        [view addSubview:title];
        
        [self.view addSubview:view];
        
        UIButton * viewBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        viewBtn.frame = CGRectMake(leftWidth * 0.2, line.origin.y + line.size.height + FIXWIDTHORHEIGHT(15 + (40 + 15) * i) , leftWidth * 0.6, leftWidth * 0.3);
        viewBtn.tag = 12345 + i;
        [viewBtn addTarget:self action:@selector(viewBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:viewBtn];
        
    }
    //底部logo设置
        
   
    UIImageView * logo = [[UIImageView alloc]initWithFrame:CGRectMake(leftWidth * 0.3, self.view.size.height - FIXWIDTHORHEIGHT(80), leftWidth * 0.4, leftWidth * 0.7)];
    logo.image = [UIImage imageNamed:@"logo2"];
    [self.view addSubview:logo];
    
    
    [self configIconUI];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件

-(void)viewBtnClicked:(UIButton *)btn{

    switch (btn.tag) {
        case 12345:
            [self pushPersonAcountViewController];
            NSLog(@"账户");
            break;
         case 12346:
            [self pushSettingViewController];
            NSLog(@"设置");
            break;
        case 12347:
            [self pushMessageViewController];
            NSLog(@"消息");
            break;
        case 12348:
            [self accordingToIosVersionToDroup];
            NSLog(@"退出");
            break;
        default:
            break;
    }
    
}
/**
 *   个人账户
 */
-(void)pushPersonAcountViewController{
    
    personAcountViewController * personAcount = [[personAcountViewController alloc]init];
    [self.view.window.rootViewController presentViewController:personAcount animated:YES completion:^{
        [[NSNotificationCenter defaultCenter]postNotificationName:@"close" object:self userInfo:@{@"close":@0}];
    }];
    
}
/**
 *  设置界面
 */
-(void)pushSettingViewController{
    
    settingViewController * setting = [[settingViewController alloc]init];
    [self.view.window.rootViewController presentViewController:setting animated:YES completion:^{
        [[NSNotificationCenter defaultCenter]postNotificationName:@"close" object:self userInfo:@{@"close":@0}];
    }];
    
}
/**
 *  消息界面
 */
-(void)pushMessageViewController{
    
    messageViewController * message = [[messageViewController alloc]init];
    [self.view.window.rootViewController presentViewController:message animated:YES completion:^{
        [[NSNotificationCenter defaultCenter]postNotificationName:@"close" object:self userInfo:@{@"close":@0}];
    }];
    
}
#pragma mark--退出(接口)
-(void)accordingToIosVersionToDroup{
    if (IOSVERSION >= 8.0) {//版本号高于8.0才能调用此方法
        [self dropOutYesOrNoMoreEightViesion];
    }else{
        [self belowEightVersion];
    }
}


-(void)dropOutYesOrNoMoreEightViesion{
    __weak __typeof(self) weakSelf = self;
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"确定退出？" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * sure = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [weakSelf dropOut];
    }];
    UIAlertAction * cancle = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alert addAction:cancle];
    [alert addAction:sure];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)belowEightVersion{
    UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"确定退出?" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertView show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        [self dropOut];
    }
}
/**
 *  退出接口
 */
-(void)dropOut{
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    __weak __typeof(self) weakSelf = self;
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:@2 forKey:@"type"];
    [dic setObject:@"" forKey:@"userid"];
    [dic setObject:@([[[NSUserDefaults standardUserDefaults] objectForKey:@"user"] intValue]) forKey:@"servicerid"];
    
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,DROPOUT] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [weakSelf clearUserInfo];
            [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:LOGINSTATE];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"close" object:weakSelf userInfo:@{@"close":@1}];
            
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"退出失败"];
    }];
    
}
/**
 *  退出之后清除用户个人信息
 */
-(void)clearUserInfo{
    NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
    [userInfo setObject:@0 forKey:@"nameState"];
    [userInfo setObject:@0 forKey:@"qualify"];
    
}

#pragma mark  头像点击事件
-(void)iconBtnClicked:(UIButton *)btn{
    NSLog(@"头像点击事件");
    [self pushPersonDataViewController];
}
-(void)pushPersonDataViewController{

    personDataController * personData = [[personDataController alloc]init];
    
    [self.view.window.rootViewController presentViewController:personData animated:YES completion:^{
        [[NSNotificationCenter defaultCenter]postNotificationName:@"close" object:self userInfo:@{@"close":@0}];
    }];
    
}
#pragma mark--头像照片的存储
-(void)configIconUI{
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:WORKSTATE] intValue]) {
        return;
    }
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    __weak __typeof(self) weakSelf = self;
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([[StateManager defaultManager].userId intValue]) forKey:@"servicerid"];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,GETINFO] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]){
            NSDictionary * Dic = [[backData objectForKey:@"result"] objectForKey:@"servicer"];
            weakSelf.nameLable.text = [Dic objectForKey:@"name"];
            if ([[Dic objectForKey:@"icon"] length]) {
                [weakSelf.iconBtn sd_setImageWithURL:[NSURL URLWithString:[Dic objectForKey:@"icon"]] forState:UIControlStateNormal];
            }else{
                [weakSelf.iconBtn setNormalImage:[UIImage imageNamed:@"default-face-拷贝"]];
            }
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"获取信息失败"];
    }];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
-(void)registerNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(uploadPersonData:) name:UPLOADPERSONDATA object:nil];
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UPLOADPERSONDATA object:nil];
}
-(void)uploadPersonData:(NSNotification *)notify{
        _nameLable.text = [[NSUserDefaults standardUserDefaults] objectForKey:NAME];
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:ICONPATH] length]) {
        [_iconBtn sd_setImageWithURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:ICONPATH]] forState:UIControlStateNormal];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  settingViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "settingViewController.h"
#import "feedbackController.h"
@interface settingViewController ()

@end

@implementation settingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configSettingViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configSettingViewControllerUI{
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"设置"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    [self.view addSubview:title];
    
    NSArray * titleArr = [NSArray arrayWithObjects:@"关于",@"服务中心",@"反馈", nil];
    
    UIImageView * bgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(120))];
    bgView.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgView];
    bgView.userInteractionEnabled = YES;
    //分割线
    float margin = 39;
    if (iPHone6Plus) {
        margin = 48;
    }
    if(iPHone6){
        
        margin = 44;
        
    }
    for (int i = 0; i < 2; i ++) {
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(margin + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
        view.backgroundColor = RGBCOLOR(245, 245, 245);
        [bgView addSubview:view];
    }

    for (int i = 0; i < 3 ; i ++) {
        //小箭头
        UIImageView * smallImage = [[UIImageView alloc]initWithFrame:CGRectMake(bgView.size.width * 0.9, FIXWIDTHORHEIGHT(11.5) + i * FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(13))];
        smallImage.image = [UIImage imageNamed:@"more"];
        [bgView addSubview:smallImage];
        
        //标题
        UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), i * FIXWIDTHORHEIGHT(40), bgView.size.width * 0.5, FIXWIDTHORHEIGHT(40))];
        lable.text = titleArr[i];
        lable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
        lable.textColor = RGBCOLOR(65, 65, 65);
        [bgView addSubview:lable];
        
        //透明按钮
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, i * FIXWIDTHORHEIGHT(40), bgView.size.width, FIXWIDTHORHEIGHT(40));
        btn.tag = 1425412 + i;
        [btn addTarget:self action:@selector(setttingBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [bgView addSubview:btn];
    }
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
    //退出
//    UIButton * testBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    testBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.9, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
//    [testBtn setTitle:@"退出" forState:UIControlStateNormal];
//    [testBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [testBtn setBackgroundColor:[UIColor redColor]];
//    testBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
//    testBtn.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(16)];
//    testBtn.layer.masksToBounds = YES;
//    [testBtn addTarget:self action:@selector(testBtnClicked) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:testBtn];
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark-- 退出按钮点击事件
-(void)testBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--三个选项按钮点击事件
-(void)setttingBtnClicked:(UIButton *)btn{
    
    switch (btn.tag) {
        case 1425412:
            NSLog(@"关于");
            break;
        case 1425413:
            NSLog(@"服务中心");
            break;
        case 1425414:
            [self pushFeedbookViewController];
            NSLog(@"反馈");
            break;
        default:
            break;
    }
    
}
-(void)pushFeedbookViewController{
    feedbackController * feedback = [[feedbackController alloc]init];
    [self presentViewController:feedback animated:YES completion:nil];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

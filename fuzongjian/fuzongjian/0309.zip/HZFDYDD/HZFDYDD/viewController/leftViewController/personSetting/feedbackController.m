//
//  feedbackController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/17.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "feedbackController.h"
#import "ButtonCall.h"
@interface feedbackController ()<UITextViewDelegate>
@property(nonatomic,strong)UITextView * titleField;
@property(nonatomic,strong)UITextView * bgTitleField;
@property(nonatomic,strong)UITextView * contentField;
@property(nonatomic,strong)UITextView * bgContentField;
@property(nonatomic,strong)UIButton * testBtn;
@end

@implementation feedbackController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configFeedbookControllerUI];
    // Do any additional setup after loading the view.
}
#pragma mark --
#pragma mark 初始化UI
-(void)configFeedbookControllerUI{
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"反馈"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    title.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(18)];
    [self.view addSubview:title];
    
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];

    
    
    //背景一
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(80))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewOne];
    bgViewOne.userInteractionEnabled = YES;
    
    //分割线
    UIView * viewOne = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewOne.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewOne addSubview:viewOne];
    
    //小箭头
    UIImageView * smallImage = [[UIImageView alloc]initWithFrame:CGRectMake(bgViewOne.size.width * 0.9, FIXWIDTHORHEIGHT(12.5)  , FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(15))];
    smallImage.image = [UIImage imageNamed:@"more"];
    [bgViewOne addSubview:smallImage];
    
    
    for (int i = 0; i < 2; i ++) {
        UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), i * FIXWIDTHORHEIGHT(40), bgViewOne.size.width * 0.5, FIXWIDTHORHEIGHT(40))];
        lable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
        lable.textColor = RGBCOLOR(65, 65, 65);
        [bgViewOne addSubview:lable];
        if (i == 0) {
            lable.text = @"使用帮助";
        }else{
            lable.text = @"客服电话";
        }
    }
    
    //使用帮助点击按钮
    UIButton * help = [UIButton buttonWithType:UIButtonTypeSystem];
    help.frame = CGRectMake(0, 0, bgViewOne.size.width, FIXWIDTHORHEIGHT(40));
    [bgViewOne addSubview:help];
    [help addTarget:self action:@selector(helpBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    //客服电话按钮
    float marginOne = 40,marginTwo = -220;
    if (iPHone6) {
        marginOne = 25;
        marginTwo = - 200;
    }
    if (iPHone6Plus) {
        marginOne = 15;
        marginTwo = - 190;
    }
    UIButton * phone = [UIButton buttonWithType:UIButtonTypeSystem];
    phone.frame = CGRectMake(SCREEN_WIDTH * 0.45, FIXWIDTHORHEIGHT(40), SCREEN_WIDTH * 0.55, FIXWIDTHORHEIGHT(40));
    [phone setTitle:@"4008-123-123" forState:UIControlStateNormal];
    [phone setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [phone setImage:[[UIImage imageNamed:@"call1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]forState:UIControlStateNormal];
    [phone addTarget:self action:@selector(callPhoneBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [phone setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, FIXWIDTHORHEIGHT(marginOne))];//上左下右
    [phone setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, FIXWIDTHORHEIGHT(marginTwo))];
    [bgViewOne addSubview:phone];
    
    
    //背景二
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgViewOne.origin.y + bgViewOne.size.height, SCREEN_WIDTH, FIXWIDTHORHEIGHT(160))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewTwo];
    bgViewTwo.userInteractionEnabled = YES;
    //分割线
    UIView * viewTwo = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewTwo.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewTwo addSubview:viewTwo];
    
    
    
    _bgTitleField = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(5), bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(30))];
    _bgTitleField.text = @"主题";
    _bgTitleField.textColor = RGBCOLOR(160, 160, 160);
    _bgTitleField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [bgViewTwo addSubview:_bgTitleField];
    
    _titleField = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(5), bgViewTwo.size.width - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(30))];
    _titleField.backgroundColor = [UIColor clearColor];
    _titleField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    _titleField.delegate = self;
    [bgViewTwo addSubview:_titleField];
    
    
    
    _bgContentField = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(46), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(100))];
    _bgContentField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    _bgContentField.text = @"反馈内容";
    _bgContentField.textColor = RGBCOLOR(160, 160, 160);
    [bgViewTwo addSubview:_bgContentField];
    
    _contentField = [[UITextView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(46), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(100))];
    _contentField.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    _contentField.backgroundColor = [UIColor clearColor];
    _contentField.delegate = self;
    [bgViewTwo addSubview:_contentField];
    
    
    
    //
    UIButton * testBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    testBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.9, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    [testBtn setTitle:@"提交" forState:UIControlStateNormal];
    [testBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [testBtn setBackgroundColor:[UIColor redColor]];
    testBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    testBtn.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(16)];
    testBtn.layer.masksToBounds = YES;
    [testBtn addTarget:self action:@selector(testBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testBtn];
    _testBtn = testBtn;
    //添加手势
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(feedBackTap)];
    tap.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tap];

}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件

#pragma mark--返回按钮点击事件
-(void)personBackBtnClicked{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark-- 提交按钮点击事件（接口）
-(void)testBtnClicked{
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    if ([NSString stringContainsEmoji:_titleField.text] || [NSString stringContainsEmoji:_contentField.text]) {
        [SVProgressHUD showErrorWithStatus:@"输入的文字不能含有表情"];
        return;
    }
    
    [SVProgressHUD showWithStatus:@"资料提交中..."];
    _testBtn.enabled = NO;
/*****************************反馈测试接口***********************************************/
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:_titleField.text forKey:@"title"];
    [dic setObject:_contentField.text forKey:@"content"];
    [dic setObject:@1 forKey:@"servicerid"];
    __weak __typeof(self) weakSelf = self;
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,FEEDBACK] body:dic block:^(id backData) {
        NSLog(@"%@",backData);
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD showSuccessWithStatus:[backData  objectForKey:@"msg"]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        }else{
            [SVProgressHUD showErrorWithStatus:[backData  objectForKey:@"msg"]];
            _testBtn.enabled = YES;
        }
        
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"提交失败"];
        _testBtn.enabled = YES;
    }];
}
#pragma mark--点击屏幕收回键盘
-(void)feedBackTap{
    [_titleField resignFirstResponder];
    [_contentField resignFirstResponder];
}
#pragma mark--使用帮助点击事件
-(void)helpBtnClicked{
    NSLog(@"使用帮助点击事件");
}
#pragma mark--客服电话点击事件
-(void)callPhoneBtnClicked{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    
    
    [_titleField resignFirstResponder];
    [_contentField resignFirstResponder];
    __weak __typeof(self) weakSelf = self;
    [AFNConnection GetData:[NSString stringWithFormat:@"%@%@",IPDERSS,GETCALLNUMBER] block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            if ([backData objectForKey:@"result"]) {
                if ([[backData objectForKey:@"result"] objectForKey:@"phonelist"]) {
                    [weakSelf createCallPhotoList:[[backData objectForKey:@"result"] objectForKey:@"phonelist"]];
                }
            }
        }else{
            [SVProgressHUD showErrorWithStatus:[backData  objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        NSLog(@"客服电话error:%@",error);
    }];
    
}



#pragma mark--传参获取电话列表
-(void)createCallPhotoList:(NSArray *)arr{
    NSMutableArray * numberArr = [NSMutableArray array];
    for (NSDictionary * dic in arr) {
        if ([dic objectForKey:@"phone"]) {
            [numberArr addObject:[dic objectForKey:@"phone"]];
        }
    }
    
    
    NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",[numberArr firstObject]];
    UIWebView * callWebView = [[UIWebView alloc]init];
    [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebView];
    
    
    //[self alterChoosePhotoToCall:numberArr];
    NSLog(@"一共%d个电话---%@",(int)arr.count,numberArr);
}
#pragma mark--传参弹出窗口选择号码
-(void)alterChoosePhotoToCall:(NSArray *)arr{
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = [UIColor clearColor];//RGBCOLOR(108, 108, 108);
    bgView.tag = 487512;
    [self.view addSubview:bgView];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [bgView addGestureRecognizer:tap];
    tap.numberOfTapsRequired = 1;
    
    //80 离底部距离 
    CGFloat height = FIXWIDTHORHEIGHT(40 * arr.count);
    NSLog(@"---%.f",height);
    UIView * content = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT - height - FIXWIDTHORHEIGHT(80), SCREEN_WIDTH - FIXWIDTHORHEIGHT(120), height)];
    content.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    content.layer.masksToBounds = YES;
    content.backgroundColor = RGBCOLOR(211, 211, 211);
    [bgView addSubview:content];
    
    
    float marginOne = 40,marginTwo = -220;
    if (iPHone6) {
        marginOne = 40;
        marginTwo = - 215;
    }
    if (iPHone6Plus) {
        marginOne = 40;
        marginTwo = - 215;
    }

    for (int i = 0; i < arr.count; i ++) {
        
        ButtonCall * btn = [ButtonCall buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, FIXWIDTHORHEIGHT( 40 * i ), content.width, FIXWIDTHORHEIGHT(40));
        [content addSubview:btn];
        btn.phoneNumber = arr[i];
        btn.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitle:arr[i] forState:UIControlStateNormal];
//        [btn setImage:[[UIImage imageNamed:@"call1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]forState:UIControlStateNormal];
//        [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, FIXWIDTHORHEIGHT(marginOne))];//上左下右
//        [btn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, FIXWIDTHORHEIGHT(marginTwo))];
        
        [btn addTarget:self action:@selector(callPhotoBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        if (i != 0) {
            
            UIView * small = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(39 * i), content.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(1))];
            small.backgroundColor = [UIColor whiteColor];
            [content addSubview:small];
            
        }
    
    }
    
}
#pragma mark--电话点击事件
-(void)callPhotoBtnClicked:(ButtonCall *)btn{
    
    for (UIView * view in self.view.subviews) {
        if (view.tag == 487512) {
            [view removeFromSuperview];
        }
    }
    NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",@"18842654214"];
    UIWebView * callWebView = [[UIWebView alloc]init];
    [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebView];
    
}
-(void)tap{
    for (UIView * view in self.view.subviews) {
        if (view.tag == 487512) {
            [view removeFromSuperview];
        }
    }
}
#pragma mark--
#pragma mark  代理
#pragma mark--textView代理方法
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    NSLog(@"----%d",(int)range.length);
    if (textView == _titleField) {
        if (![text isEqualToString:@""]) {
            _bgTitleField.hidden = YES;
        }
        if ([text isEqualToString:@""] && range.length == 1 && range.location == 0) {
            _bgTitleField.hidden = NO;
        }
    }else{
        if (![text isEqualToString:@""]) {
            _bgContentField.hidden = YES;
        }
        if ([text isEqualToString:@""] && range.length == 1 && range.location == 0) {
            _bgContentField.hidden = NO;
        }

    }
    return YES;
}
#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  settingViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface settingViewController : UIViewController

@end

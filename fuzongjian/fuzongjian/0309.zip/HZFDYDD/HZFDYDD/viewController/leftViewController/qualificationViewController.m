//
//  qualificationViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "qualificationViewController.h"

#import "qualifyChooseView.h"
#import "photoDisplay.h"

#import "bigPhotoViewController.h"
#import "UnderTableViewController.h"

@interface qualificationViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
/**
 *  名字输入框
 */
@property(nonatomic,strong)UITextField * nameField;
/**
 *  照片数组 存储学历证书、其他相关证书
 */
@property(nonatomic,strong)NSMutableArray * photoArrOne;
@property(nonatomic,strong)NSMutableArray * photoArrTwo;
/**
 *  用scroll来展示图片
 */
@property(nonatomic,strong)UIScrollView * scrollViewOne;
@property(nonatomic,strong)UIScrollView * scrollViewTwo;
/**
 *  动态添加照片的数组
 */
@property(nonatomic,strong)NSArray * transfromArr;
/**
 *  弹框灰色背景图
 */
@property(nonatomic,strong)UIView * backgroundView;
@property(nonatomic,strong)UIView * popView;
/**
 *  记录点击按钮
 */
@property(nonatomic,assign)NSInteger clickNum;
/**
 *  用于上传图片
 */
@property(nonatomic,strong)NSMutableArray * allArr;
/**
 *  保存图片路径
 */
@property(nonatomic,strong)NSMutableArray * photoPath;


@property(nonatomic,assign)NSInteger photoNumber;

@end

@implementation qualificationViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    if (_transfromArr.count != 0) {
        
        [self addPhotoFromPhotoArr];//第一次需要判断
    }

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    _transfromArr = [NSArray array];
    [SVProgressHUD dismiss];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configQualificationViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configQualificationViewControllerUI{
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    
    _photoArrOne = [NSMutableArray array];
    _photoArrTwo = [NSMutableArray array];
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    
    
    //设置标题
    UILabel * album = [Tool setCustomViewTitle:@"资质认证"];
    self.navigationItem.titleView = album;
    
    // 字体大小
    float personFontSize = FIXWIDTHORHEIGHT(15);
    UIColor * color = RGBCOLOR(18, 18, 18);
    
    /*    姓名    */
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64 + FIXWIDTHORHEIGHT(5), SCREEN_WIDTH, FIXWIDTHORHEIGHT(40))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewOne];
    bgViewOne.userInteractionEnabled = YES;
    
    UILabel * name = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, FIXWIDTHORHEIGHT(35), FIXWIDTHORHEIGHT(39))];
    name.text = @"姓名:";
    name.font = [UIFont systemFontOfSize:personFontSize];
    name.textColor = color;
    [bgViewOne addSubview:name];
    _nameField = [[UITextField alloc]initWithFrame:CGRectMake(name.origin.x + name.size.width + FIXWIDTHORHEIGHT(3), 0, bgViewOne.size.width - name.origin.x - name.size.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39))];
    _nameField.placeholder = @"请输入您的名字";
    _nameField.text = [[NSUserDefaults standardUserDefaults] objectForKey:NAME];
    _nameField.font = [UIFont systemFontOfSize:personFontSize];
    [_nameField becomeFirstResponder];
    [bgViewOne addSubview:_nameField];
    
    
    
    
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgViewOne.origin.y + bgViewOne.size.height + FIXWIDTHORHEIGHT(1.5), SCREEN_WIDTH, FIXWIDTHORHEIGHT(130))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewTwo];
    bgViewTwo.userInteractionEnabled = YES;
    //分割线
    UIView * viewTwo = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewTwo.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewTwo addSubview:viewTwo];
    
    UILabel * studyID = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(150), FIXWIDTHORHEIGHT(39))];
    studyID.text = @"学历证书";
    studyID.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewTwo addSubview:studyID];
    UIButton * addBtnOne = [[UIButton alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), studyID.origin.y + studyID.size.height + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70))];
    [addBtnOne setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
    [addBtnOne setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateHighlighted];
    [bgViewTwo addSubview:addBtnOne];
    [addBtnOne addTarget:self action:@selector(addStudyIDPhotoBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    //scroll
    _scrollViewOne = [[UIScrollView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40), bgViewTwo.width - FIXWIDTHORHEIGHT(115), FIXWIDTHORHEIGHT(80))];
    [bgViewTwo addSubview:_scrollViewOne];
    _scrollViewOne.showsHorizontalScrollIndicator = NO;//水平滚动条
    _scrollViewOne.bounces = YES;//弹动效果
    _scrollViewOne.contentSize = CGSizeMake(bgViewTwo.width - FIXWIDTHORHEIGHT(115), FIXWIDTHORHEIGHT(80));
    

    
    UIImageView * bgViewThree = [[UIImageView alloc]initWithFrame:CGRectMake(0,bgViewTwo.origin.y + bgViewTwo.size.height, SCREEN_WIDTH, FIXWIDTHORHEIGHT(130))];
    bgViewThree.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewThree];
    bgViewThree.userInteractionEnabled = YES;
    //分割线
    UIView * viewThree = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewThree.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewThree addSubview:viewThree];
    UILabel * otherID = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(280), FIXWIDTHORHEIGHT(39))];
    otherID.text = @"其他相关证书(医师，技师，护师，职业证书)";
    otherID.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(13)];
    [bgViewThree addSubview:otherID];
    UIButton * addBtnTwo = [[UIButton alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), otherID.origin.y + otherID.size.height + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70))];
    [addBtnTwo setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
    [addBtnTwo setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateHighlighted];
    [bgViewThree addSubview:addBtnTwo];
    [addBtnTwo addTarget:self action:@selector(otherIDPhotoAddBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    //scroll
    _scrollViewTwo = [[UIScrollView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(40), bgViewThree.width - FIXWIDTHORHEIGHT(115), FIXWIDTHORHEIGHT(80))];
    [bgViewThree addSubview:_scrollViewTwo];
    _scrollViewTwo.showsHorizontalScrollIndicator = NO;//水平滚动条
    _scrollViewTwo.bounces = YES;//弹动效果
    _scrollViewTwo.contentSize = CGSizeMake(bgViewThree.width - FIXWIDTHORHEIGHT(115), FIXWIDTHORHEIGHT(80));

    
    //确认提交审核
    UIButton * testBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    testBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.9, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    [testBtn setTitle:@"确认并提交审核" forState:UIControlStateNormal];
    [testBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [testBtn setBackgroundColor:[UIColor redColor]];
    testBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    testBtn.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(18)];
    testBtn.layer.masksToBounds = YES;
    [testBtn addTarget:self action:@selector(testBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testBtn];
    
    
    UITapGestureRecognizer * tapOne = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addScrollViewOne)];
    tapOne.numberOfTapsRequired = 1;
    [_scrollViewOne addGestureRecognizer:tapOne];
    
    UITapGestureRecognizer * tapTwo = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addScrollViewTwo)];
    tapTwo.numberOfTapsRequired = 1;
    [_scrollViewTwo addGestureRecognizer:tapTwo];
    

}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark -- 给scrollView添加手势 进行大图浏览增删改查
-(void)addScrollViewOne{
    _clickNum = 1;
    NSLog(@"addScrollViewOne");
    
    if (_photoArrOne.count != 0) {
        _photoNumber = _photoArrOne.count;
        [self buildBigViewControllerNum:_clickNum completion:^(bigPhotoViewController *bigPhoto) {
            [bigPhoto returnQulityBlock:^(NSMutableArray *arr) {
                if (_photoNumber != arr.count) {
                    [self updateScrollViewBy:_photoArrOne andScrollView:_scrollViewOne];
                }
            }];
            [self.navigationController pushViewController:bigPhoto animated:YES];
        }];
    }
 
}
-(void)addScrollViewTwo{
    
    _clickNum = 2;
    NSLog(@"addScrollViewTwo");

    if (_photoArrTwo.count != 0) {
        _photoNumber = _photoArrTwo.count;
        [self buildBigViewControllerNum:_clickNum completion:^(bigPhotoViewController *bigPhoto) {
            [bigPhoto returnQulityBlock:^(NSMutableArray *arr) {
                if (_photoNumber != arr.count) {
                    [self updateScrollViewBy:_photoArrTwo andScrollView:_scrollViewTwo];
                }
            }];
            [self.navigationController pushViewController:bigPhoto animated:YES];
        }];
    }

}
-(void)buildBigViewControllerNum:(NSInteger) clickNum completion:(void(^)(bigPhotoViewController * bigPhoto))completion{
    
    bigPhotoViewController * bigPhoto = [[bigPhotoViewController alloc] init];
    bigPhoto.qualityState = YES;
    if (clickNum == 1) {
        bigPhoto.bigPhotoArr = _photoArrOne;
    }else{
        bigPhoto.bigPhotoArr = _photoArrTwo;
    }
    completion(bigPhoto);
}
-(void)updateScrollViewBy:(NSMutableArray *)photoArr andScrollView:(UIScrollView *)scroll{
    //删除所有的照片
    for (UIView * view in scroll.subviews) {
        
        if ([view isKindOfClass:[UIImageView class]]) {
            
            [view removeFromSuperview];
        }
    }
    
    //重新加载图片
    scroll.contentSize = CGSizeMake(FIXWIDTHORHEIGHT((70 + 10) * photoArr.count), FIXWIDTHORHEIGHT(70));
    for (int i = 0; i < photoArr.count; i ++) {
        UIImageView * image = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT((70 + 10) * i) , FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70))];
        image.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
        image.layer.masksToBounds = YES;
        [[PhotoTool sharePhotoTool] requestImageForAsset:photoArr[i] size:CGSizeMake(FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70)) resizeMode:PHImageRequestOptionsResizeModeFast completion:^(UIImage *result) {
            image.image = result;
        }];
        [scroll addSubview:image];
    }
    
}
#pragma mark  返回按钮事件
-(void)personBackBtnClicked{
    [_nameField resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark-- 确认并提交审核按钮点击事件---图片上传到服务器并拿到图片路径
-(void)testBtnClicked{
    
   
    _allArr = [NSMutableArray array];
    [_allArr addObjectsFromArray:_photoArrOne];
    [_allArr addObjectsFromArray:_photoArrTwo];
    _photoPath = [NSMutableArray array];
    
    if (![_nameField.text length]) {
        [SVProgressHUD showErrorWithStatus:@"请填写您的姓名"];
    }else if(_allArr.count == 0){
        [SVProgressHUD showErrorWithStatus:@"请添加您的证书"];
    }else{
        
        if ([StateManager defaultManager].reachState == 0) {
            [SVProgressHUD showErrorWithStatus:@"网络不可用"];
            return;
        }
        if ([NSString stringContainsEmoji:_nameField.text]) {
            [SVProgressHUD showErrorWithStatus:@"名字不能含有表情"];
            return;
        }
        [self uploadPhotoFromAllArray];
    }

    
}
#pragma mark--图片上传到服务器并拿到图片路径
-(void)uploadPhotoFromAllArray{
    
    static  NSInteger num = 0;
    [SVProgressHUD showWithStatus:[NSString stringWithFormat:@"图片上传%d/%d",(int)num + 1,(int)_allArr.count] maskType:SVProgressHUDMaskTypeClear];
    [[PhotoTool sharePhotoTool] requestImageForAsset:_allArr[num] size:PHImageManagerMaximumSize resizeMode:PHImageRequestOptionsResizeModeNone completion:^(UIImage *result){
        if (result) {
            NSData * data = UIImageJPEGRepresentation(result, 0.3);
            [AFNConnection UploadPhotoPath:[NSString stringWithFormat:@"%@%@",IPDERSS,UPLOADPHOTO] body:nil data:data block:^(id backData) {
                
                if ([[backData objectForKey:@"status"] intValue]) {
                    
                    [_photoPath addObject:[[backData objectForKey:@"result"] objectForKey:@"path"]];
                    NSLog(@"%@",_photoPath);
                    if (num != _allArr.count - 1) {
                        num ++;
                        [self performSelector:@selector(uploadPhotoFromAllArray)];
                    }else{
                        num = 0;
                        [self uploadQualitifyData];
                        [SVProgressHUD showWithStatus:@"资料上传中..."];
                    }
                }else{
                    [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
                    NSLog(@"--%@",[backData objectForKey:@"msg"]);
                }
            } error:^(NSError *error) {
                [SVProgressHUD showErrorWithStatus:@"图片上传失败"];
            }];
        }
    }];

}
#pragma mark--上传资格认证资料(接口)
-(void)uploadQualitifyData{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    
    
    NSMutableArray * arrOne = [NSMutableArray array];
    NSMutableArray * arrTwo = [NSMutableArray array];
    
    for (int i = 0; i < _photoPath.count; i ++) {
        if (i < _photoArrOne.count) {
            
            [arrOne addObject:_photoPath[i]];
        }else{
            [arrTwo addObject:_photoPath[i]];
        }
    }
    NSArray * keys = [NSArray arrayWithObjects:@"servicerid",@"name",@"edupic",@"cerpic", nil];
    NSArray * values = [NSArray arrayWithObjects:@([[StateManager defaultManager].userId intValue]),_nameField.text,arrOne,arrTwo, nil];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObjects:values forKeys:keys];
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,QUALUFICATION] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {//资料上传成功的话 更改审核状态
            [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self dismissViewControllerAnimated:YES completion:nil];
            });
            
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"上传失败"];
        NSLog(@"上传资格认证资料error:%@",error);
    }];
    
}
/**
 *  界面消失  回调传值
 *
 *  @param block 传值
 */
-(void)returnState:(returnQualitifyBlock)block{
    self.block = block;
}

#pragma mark--学历证书添加点击事件
-(void)addStudyIDPhotoBtnClicked{
    [_nameField resignFirstResponder];

    if (_photoArrOne.count >= 10) {
        
        [SVProgressHUD showErrorWithStatus:@"学历证书最多上传10张"];
        
        
    }else{
        
        [self choosePhotoPopView];
        
    }
    _clickNum = 1;
    
    NSLog(@"学历证书添加点击事件");
}
#pragma mark--其他证书添加点击事件
-(void)otherIDPhotoAddBtnClicked{
    [_nameField resignFirstResponder];
    if (_photoArrTwo.count >= 10) {
        
        [SVProgressHUD showErrorWithStatus:@"证书最多上传10张"];
        
    }else{
        
        [self choosePhotoPopView];
        
    }
    _clickNum = 2;
    
    NSLog(@"其他证书添加点击事件");
}
#pragma mark-- 收缩键盘
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_nameField resignFirstResponder];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 判断软件是否有相册、相机访问权限
- (BOOL)judgeIsHavePhotoAblumAuthority
{
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusRestricted ||
        status == PHAuthorizationStatusDenied) {
        return NO;
    }
    return YES;
}
- (BOOL)judgeIsHaveCameraAuthority
{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (status == AVAuthorizationStatusRestricted ||
        status == AVAuthorizationStatusDenied) {
        return NO;
    }
    return YES;
}
#pragma mark--选择照片弹出视图
-(void)choosePhotoPopView{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.9;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    [self addTapGestureToBackgroundView:bgView];
    _backgroundView = bgView;
    
    
    //弹出的选择框
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = 5;
    popView.layer.masksToBounds = YES;
    popView.alpha = 1;
    _popView = popView;
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
   
    
    float btnHeight = (popView.size.height - (20 + 20 + 5 + 5 ))/3.0;
    
    for (int i = 0; i < 3; i ++) {
        UIButton  * btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(20, 20 + (btnHeight + 5) * i , popView.size.width - 40, btnHeight);
        
        btn.layer.cornerRadius = btnHeight/2.0;
        btn.layer.masksToBounds = YES;
        
//        [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//        CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//        CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
//        [btn.layer setBorderColor:color];
        [btn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
        [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        if (i == 0) {
            [btn setImage:[[UIImage imageNamed:@"camera"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"拍照" forState:UIControlStateNormal];
            
        }else if (i == 1){
            [btn setImage:[[UIImage imageNamed:@"photo"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"从手机相册添加" forState:UIControlStateNormal];
        }else{
            
            [btn setTitle:@"取消" forState:UIControlStateNormal];
        }
        
        btn.tag = 4892472 + i;
        [btn addTarget:self action:@selector(takePhotoOrAlbumOrCancleBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [popView addSubview:btn];
    }
    
    
}
#pragma mark--拍照、从手机相册添加、取消的按钮点击事件
-(void)takePhotoOrAlbumOrCancleBtnClicked:(UIButton *)btn{
    switch (btn.tag) {
        case 4892472:
            [_backgroundView removeFromSuperview];
            [_popView removeFromSuperview];
            [self takePhotoFromiphone];
            break;
        case 4892473:
            [_backgroundView removeFromSuperview];
            [_popView removeFromSuperview];
            [self takePhotoFromAlbum];
            break;
        case 4892474:
            [_backgroundView removeFromSuperview];
            [_popView removeFromSuperview];
            break;
        default:
            break;
    }
}
-(void)addTapGestureToBackgroundView:(UIView *)View{
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureClicked)];
    tap.numberOfTapsRequired = 1;
    [View addGestureRecognizer:tap];
}
-(void)tapGestureClicked{
    [_backgroundView removeFromSuperview];
    [_popView removeFromSuperview];
}
#pragma mark--从手机拍照
-(void)takePhotoFromiphone{
    
    if ([self judgeIsHaveCameraAuthority]) {
        
        UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            UIImagePickerController * picker = [[UIImagePickerController alloc]init];
            picker.delegate = self;
            picker.allowsEditing = NO;
            picker.sourceType = sourceType;
            [self presentViewController:picker animated:YES completion:nil];
        }else{
            NSLog(@"该设备没有摄像头");
        }
        
    }else{
        [SVProgressHUD showErrorWithStatus:@"请在iPhone的\"设置-隐私-相册\"中允许访问相机"];
    }
    
}
#pragma mark--照片代理
/**
 *  将照片写入相册
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    
    UIImage * image = [info objectForKey:UIImagePickerControllerOriginalImage];

    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo{
    
    if(!error){
        
        _transfromArr = [NSArray arrayWithObject:[[[PhotoTool sharePhotoTool] getAllAssetInPhotoAblumWithAscending:YES] lastObject]];
        

        if (_clickNum == 1) {
            
            [_photoArrOne addObjectsFromArray:_transfromArr];
            
        }else{
            
             [_photoArrTwo addObjectsFromArray:_transfromArr];
        }
        
        [self addPhotoFromPhotoArr];
    }
    
}
/**
 *  照相取消按钮 退出照相
 */
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
-(void)addPhotoFromPhotoArr{
    
    if (_clickNum == 1) {
        
        _scrollViewOne.contentSize = CGSizeMake(FIXWIDTHORHEIGHT((70 + 10) * _photoArrOne.count), FIXWIDTHORHEIGHT(70));
        
        for (int i = (int)_photoArrOne.count - (int)_transfromArr.count; i < (int)_photoArrOne.count; i ++) {
            
            [_scrollViewOne addSubview:[self returnImageBy:i andSecond:i - _photoArrOne.count + _transfromArr.count]];
            
        }
        
    }else{
        
        _scrollViewTwo.contentSize = CGSizeMake(FIXWIDTHORHEIGHT((70 + 10) * _photoArrTwo.count), FIXWIDTHORHEIGHT(70));
        
        for (int i = (int)_photoArrTwo.count - (int)_transfromArr.count; i < (int)_photoArrTwo.count; i ++) {
            
            [_scrollViewTwo addSubview:[self returnImageBy:i andSecond:i - _photoArrTwo.count + _transfromArr.count]];
            
        }
        
    }
    
}
#pragma mark-- 传参数拿到图片
-(UIImageView *)returnImageBy:(NSInteger)first andSecond:(NSInteger)second{
    UIImageView * image = [[UIImageView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT((70 + 10) * first) , FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70))];
    image.userInteractionEnabled = YES;
    image.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    image.layer.masksToBounds = YES;
    
    if ([_transfromArr[second] isKindOfClass:[UIImage class]]) {
        image.image = _transfromArr[second];
    }else{
        [[PhotoTool sharePhotoTool] requestImageForAsset:_transfromArr[second] size:CGSizeMake(FIXWIDTHORHEIGHT(70), FIXWIDTHORHEIGHT(70)) resizeMode:PHImageRequestOptionsResizeModeFast completion:^(UIImage *result) {
            image.image = result;
        }];
    }
    return image;
}
#pragma mark--从相册取照片
-(void)takePhotoFromAlbum{
    
    if ([self judgeIsHavePhotoAblumAuthority]) {//如果有相册使用权,进入相册拿到照片跳转到下一个界面
        
        [self enterAlbum];
        
    }else{

        [SVProgressHUD showErrorWithStatus:@"请在iPhone的\"设置-隐私-相册\"中允许访问相册"];
        
    }
    
    
}
-(void)enterAlbum{
    
    
    
    
    
    NSArray <PhotoAblumList *> * albumList = [[PhotoTool sharePhotoTool] getPhotoAblumList];
    
    qualifyChooseView * chooseView = [[qualifyChooseView alloc]init];
    chooseView.arr = albumList;
    
    if (_clickNum == 1) {
        
        chooseView.addNum = 10 - _photoArrOne.count;
        
    }else{
        
        chooseView.addNum = 10 - _photoArrTwo.count;
        
    }

    [chooseView returnPhotoArr:^(NSArray *dataArr) {
        
        _transfromArr = [NSArray arrayWithArray:dataArr];
        
        if (_clickNum == 1) {
            
            [_photoArrOne addObjectsFromArray:dataArr];
            
        }else{
            
            [_photoArrTwo addObjectsFromArray:dataArr];
            
        }
        
    }];
   
    /**
        用导航栏推出界面
     */
//    UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:chooseView];
//    
//   
//    [self presentViewController:nav animated:YES completion:nil];
    
    
     [self.navigationController pushViewController:chooseView animated:YES];
    
    
}






@end

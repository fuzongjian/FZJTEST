//
//  tureNameViewController.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^returnTureNameState)(BOOL state);

@interface tureNameViewController : UIViewController

@property(nonatomic,copy)returnTureNameState block;

-(void)returnTureNameState:(returnTureNameState)block;


@end

//
//  tureNameViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/15.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "tureNameViewController.h"

@interface tureNameViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property(nonatomic,strong)UITextField * nameField;
@property(nonatomic,strong)UITextField * IDCard;
/**
 *   记录点击的按钮
 */
@property(nonatomic,assign)NSInteger clickNum;
/**
 *  存储身份证照片
 */
@property(nonatomic,strong)UIImage * imageOne;
@property(nonatomic,strong)UIImage * imagetwo;

/**
 *  弹框背景
 */
@property(nonatomic,strong)UIView * backgroundView;
/**
 *  照片按钮
 */
@property(nonatomic,strong)UIButton * btnOne;
@property(nonatomic,strong)UIButton * btnTwo;
/**
 *  存放所有的图片
 */
@property(nonatomic,strong)NSMutableArray * allArr;
/**
 *  存放所有图片的路径
 */
@property(nonatomic,strong)NSMutableArray * photoPath;


@end

@implementation tureNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configTureNameViewControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configTureNameViewControllerUI{
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"实名认证"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    [self.view addSubview:title];
    
    // 字体大小
    float personFontSize = FIXWIDTHORHEIGHT(15);
    UIColor * color = RGBCOLOR(18, 18, 18);
    
    /*  姓名身份证号码  */
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(80))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewOne];
    bgViewOne.userInteractionEnabled = YES;
    //分割线
    UIView * viewOne = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewOne.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewOne addSubview:viewOne];
    
    //姓名
    UILabel * name = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, FIXWIDTHORHEIGHT(35), FIXWIDTHORHEIGHT(39))];
    name.text = @"姓名:";
    name.font = [UIFont systemFontOfSize:personFontSize];
    name.textColor = color;
    [bgViewOne addSubview:name];
    
    _nameField = [[UITextField alloc]initWithFrame:CGRectMake(name.origin.x + name.size.width + FIXWIDTHORHEIGHT(3), 0, bgViewOne.size.width - name.origin.x - name.size.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39))];
    _nameField.placeholder = @"请输入您的名字";
    _nameField.text = [[NSUserDefaults standardUserDefaults] objectForKey:NAME];
    _nameField.font = [UIFont systemFontOfSize:personFontSize];
    [_nameField becomeFirstResponder];
    [bgViewOne addSubview:_nameField];
    
    //身份证号码
    //姓名
    UILabel * idcard = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(50), FIXWIDTHORHEIGHT(39))];
    idcard.text = @"身份证:";
    idcard.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewOne addSubview:idcard];
    
    _IDCard = [[UITextField alloc]initWithFrame:CGRectMake(idcard.origin.x + idcard.size.width + FIXWIDTHORHEIGHT(3), FIXWIDTHORHEIGHT(40), bgViewOne.size.width - name.origin.x - name.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(39))];
    _IDCard.placeholder = @"请输入您的身份证号";
    _IDCard.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewOne addSubview:_IDCard];
    
    
    
    /*  身份证照片  */
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, bgViewOne.origin.y + bgViewOne.size.height, SCREEN_WIDTH, FIXWIDTHORHEIGHT(120))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewTwo];
    bgViewTwo.userInteractionEnabled = YES;
    //分割线
    UIView * viewTwo = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
    viewTwo.backgroundColor = RGBCOLOR(245, 245, 245);
    [bgViewTwo addSubview:viewTwo];
    
    UILabel * IDPhoto = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(0), FIXWIDTHORHEIGHT(150), FIXWIDTHORHEIGHT(39))];
    IDPhoto.text = @"身份证照片(正反面)";
    IDPhoto.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewTwo addSubview:IDPhoto];
    
    for (int i = 0; i < 2; i ++) {
        
        float margin = 10;
        if (iPHone6 || iPHone6Plus) {
            margin = 20 ;
        }
        
        UIButton * addBtnOne = [[UIButton alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20) + i * (FIXWIDTHORHEIGHT(60 + margin)), IDPhoto.origin.y + IDPhoto.size.height + FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(60))];
        addBtnOne.tag = 6123456 + i;
        addBtnOne.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
        addBtnOne.layer.masksToBounds = YES;
        [addBtnOne setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateNormal];
        [addBtnOne setBackgroundImage:[UIImage imageNamed:@"add-photo"] forState:UIControlStateHighlighted];
        [bgViewTwo addSubview:addBtnOne];
        [addBtnOne addTarget:self action:@selector(addPhotoBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        
        if (i == 0) {
            _btnOne = addBtnOne;
        }else{
            _btnTwo = addBtnOne;
        }
        
    }
    
    
    
    //确认提交审核
    UIButton * testBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    testBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.9, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), FIXWIDTHORHEIGHT(40));
    [testBtn setTitle:@"确认并提交审核" forState:UIControlStateNormal];
    [testBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [testBtn setBackgroundColor:[UIColor redColor]];
    testBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    testBtn.titleLabel.font = [UIFont boldSystemFontOfSize:FIXWIDTHORHEIGHT(18)];
    testBtn.layer.masksToBounds = YES;
    [testBtn addTarget:self action:@selector(testBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testBtn];
    
    
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark--返回按钮点击事件
-(void)personBackBtnClicked{
    
    [_IDCard resignFirstResponder];
    [_nameField resignFirstResponder];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark--上传照片的按钮点击事件
-(void)addPhotoBtnClicked:(UIButton *)btn{
    
//    UIButton  * btnOne = [self.view viewWithTag:6123456];
//    UIButton * btnTwo = [self.view viewWithTag:6123457];
    
    if (btn.tag == 6123456) {
        _clickNum = 1;
        NSLog(@"上传第一张");
    }else{
        _clickNum = 2;
        NSLog(@"上传第二张");
    }
    [_nameField resignFirstResponder];
    [_IDCard resignFirstResponder];
    
    [self popViewToChoosePhoto];
}
#pragma mark-- 确认并提交审核按钮点击事件(接口---照片处理)
-(void)testBtnClicked{
    
   
    _allArr = [NSMutableArray array];
    _photoPath = [NSMutableArray array];
    
    if (_imageOne && _imagetwo && [_nameField.text length] && [_IDCard.text length]) {
        [_allArr addObject:_imageOne];
        [_allArr addObject:_imagetwo];
        [self uploadPhotoFromAllarr];
    }else{//如果只有一张照片则弹出提示框
        [SVProgressHUD showErrorWithStatus:@"信息填写不完整"];
    }
    
    //[self dismissViewControllerAnimated:YES completion:nil];
    
}
#pragma mark-- 上传图片 拿到图片路径
-(void)uploadPhotoFromAllarr{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    if ([NSString stringContainsEmoji:_nameField.text]) {
        [SVProgressHUD showErrorWithStatus:@"名字不能含有表情"];
        return;
    }
    __weak __typeof(self) weakSelf = self;
    
    static int num = 0;
    [SVProgressHUD showWithStatus:[NSString stringWithFormat:@"图片上传%d/%d",(int)num + 1,(int)_allArr.count] maskType:SVProgressHUDMaskTypeClear];
    NSData * data = UIImageJPEGRepresentation(_allArr[num], 0.5);
    
    [AFNConnection UploadPhotoPath:[NSString stringWithFormat:@"%@%@",IPDERSS,UPLOADPHOTO] data:data block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [_photoPath addObject:[[backData objectForKey:@"result"] objectForKey:@"path"]];
            if (num != _allArr.count - 1) {
                num ++;
                [weakSelf performSelector:@selector(uploadPhotoFromAllarr)];
            }else{
                num = 0;//防止用户上传失败后的二次上传
                [weakSelf uploadTrueNameData];
                [SVProgressHUD showWithStatus:@"资料上传..."];
            }
        }else{
            num = 0;
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
            NSLog(@"%@",[backData objectForKey:@"msg"]);
        }
    } error:^(NSError *error) {
        num = 0;
        [SVProgressHUD showErrorWithStatus:@"上传图片失败"];
        NSLog(@"上传图片 拿到图片路径error:%@",error);
    }];
}
#pragma mark--上传实名认证资料
-(void)uploadTrueNameData{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }
    
    
    __weak __typeof(self) weakSelf = self;
    
    NSArray * key = [NSArray arrayWithObjects:@"servicerid",@"name", @"idnum",@"cardpic",nil];
    NSArray * value = [NSArray arrayWithObjects:@([[StateManager defaultManager].userId intValue]),_nameField.text,_IDCard.text,_photoPath, nil];
    NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithObjects:value forKeys:key];
    
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,TURENAME] body:dic block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            [SVProgressHUD showSuccessWithStatus:@"上传成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
            
            
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
             NSLog(@"%@",[backData objectForKey:@"msg"]);
        }
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"上传失败"];
         NSLog(@"上传实名认证资料error:%@",error);
    }];
}
-(void)returnTureNameState:(returnTureNameState)block{
    self.block = block;
}
#pragma mark-- 收缩键盘
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_nameField resignFirstResponder];
    [_IDCard resignFirstResponder];
}
#pragma mark--照片处理
-(void)popViewToChoosePhoto{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    _backgroundView = bgView;
    
    
    //弹出的选择框
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.4, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = 5;
    popView.layer.masksToBounds = YES;
    [_backgroundView addSubview:popView];
    
    float btnHeight = (popView.size.height - (20 + 20 + 5 + 5 ))/3.0;
    
    for (int i = 0; i < 3; i ++) {
        UIButton  * btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(20, 20 + (btnHeight + 5) * i , popView.size.width - 40, btnHeight);
        
        btn.layer.cornerRadius = btnHeight/2.0;
        btn.layer.masksToBounds = YES;
        
//        [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//        CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//        CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
//        [btn.layer setBorderColor:color];
//        [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        
        [btn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
        
        if (i == 0) {
            
            [btn setImage:[[UIImage imageNamed:@"camera"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"拍照" forState:UIControlStateNormal];
            
        }else if (i == 1){
            [btn setImage:[[UIImage imageNamed:@"photo"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"从手机相册添加" forState:UIControlStateNormal];
        }else{
            
            [btn setTitle:@"取消" forState:UIControlStateNormal];
        }
        
        btn.tag = 4892472 + i;
        [btn addTarget:self action:@selector(takePhotoOrAlbumOrCancleBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [popView addSubview:btn];
    }
    
    
}
#pragma mark--拍照、从手机相册添加、取消的按钮点击事件
-(void)takePhotoOrAlbumOrCancleBtnClicked:(UIButton *)btn{
    switch (btn.tag) {
        case 4892472:
            [_backgroundView removeFromSuperview];
            [self takePhotoFromiphone];
            break;
        case 4892473:
            [_backgroundView removeFromSuperview];
            [self takePhotoFromAlbum];
            break;
        case 4892474:
            [_backgroundView removeFromSuperview];
            break;
        default:
            break;
    }
}
#pragma mark--从手机拍照
-(void)takePhotoFromiphone{
    
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIImagePickerController * picker = [[UIImagePickerController alloc]init];
        picker.delegate = self;
        picker.allowsEditing = NO;
        picker.sourceType = sourceType;
        [self presentViewController:picker animated:YES completion:nil];
    }else{
        NSLog(@"该设备没有摄像头");
    }
    
}
#pragma mark--从相册取照片
-(void)takePhotoFromAlbum{
    
    UIImagePickerController * picker = [[UIImagePickerController alloc]init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:nil];
    
}
#pragma mark--照片代理(接口)
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    NSLog(@"fuzongjian");
    if (_clickNum == 1) {
        
        _imageOne = image;
        [_btnOne setBackgroundImage:image forState:UIControlStateNormal];
        
    }else{
        _imagetwo = image;
        [_btnTwo setBackgroundImage:image forState:UIControlStateNormal];
    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

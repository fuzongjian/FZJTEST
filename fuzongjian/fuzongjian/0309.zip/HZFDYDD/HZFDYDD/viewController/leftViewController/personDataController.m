//
//  personDataController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/14.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "personDataController.h"
#import "tureNameViewController.h"
#import "qualificationViewController.h"
#import "UIButton+WebCache.h"
#import "UnderQualificationViewController.h"
@interface personDataController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property(nonatomic,strong)UIView * backgroundView;//弹出选择框的灰色背景
@property(nonatomic,strong)UIView * popView;//弹出的选择框
@property(nonatomic,strong)UIButton * iconBtn;//头像
@property(nonatomic,strong)NSString * iconBtnPath;
@property(nonatomic,strong)UILabel * name;//姓名
/**
 *  保存按钮
 */
@property(nonatomic,strong)UIButton * save;
/**
 *  联系电话
 */
@property(nonatomic,strong)UILabel * numberLable;
@property(nonatomic,strong)UITextField * changeNumber;
/**
 *  用户头像
 */
@property(nonatomic,strong)UIImage * iconImage;


@property(nonatomic,strong)UIButton * tureNameBtn;
@property(nonatomic,strong)UIButton * qualifyBtn;

@property(nonatomic,strong)UILabel * tureNameLable;
@property(nonatomic,strong)UILabel * qualifyLable;

@property(nonatomic,strong)UIImageView * imageOne;
@property(nonatomic,strong)UIImageView * imageTwo;

@property(nonatomic,assign)BOOL chooseIconState;

@end

@implementation personDataController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
    int nameState = [[userInfo objectForKey:@"nameState"] intValue],qualityState = [[userInfo objectForKey:@"qualify"] intValue];
    
    NSString * name = [userInfo objectForKey:@"turename"];
    NSString * icon = [userInfo objectForKey:@"iconPath"];
    
    if ((nameState == 3) && (qualityState == 3) && (name.length != 0) && (icon.length != 0)) {
        [self changeState:3 qualifystate:3];
    }else if(!self.chooseIconState){
        [self nameStateAndQualiState];
    }
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [SVProgressHUD dismiss];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configPersonDataControllerUI];
}
#pragma mark --
#pragma mark 初始化UI
-(void)configPersonDataControllerUI{
    
    self.view.backgroundColor = RGBCOLOR(240, 240, 240);
    //标题
    UILabel * title = [Tool setCustomViewTitle:@"个人资料"];
    title.frame = CGRectMake(0, 20, SCREEN_WIDTH, 44);
    [self.view addSubview:title];
    
    //返回按钮设置
    UIButton  * backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(5), 20, 44, 44);
    [backBtn setBackgroundImage:[UIImage imageNamed:@"back"]forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(personBackBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
    
    //保存按钮按钮设置
    UIButton  * save = [UIButton buttonWithType:UIButtonTypeSystem];
    save.frame = CGRectMake(SCREEN_WIDTH - 44 - FIXWIDTHORHEIGHT(10), 20, 44, 44);
    [save setTitle:@"保存" forState:UIControlStateNormal];
    save.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    save.enabled = NO;
    [self.view addSubview:save];
    [save addTarget:self action:@selector(saveToInternet) forControlEvents:UIControlEventTouchUpInside];
    _save = save;
    
    // 字体大小
    float personFontSize = FIXWIDTHORHEIGHT(15);
    UIColor * color = RGBCOLOR(18, 18, 18);
    
    /*  头像姓名  */
    UIImageView * bgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, FIXWIDTHORHEIGHT(120))];
    bgViewOne.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewOne];
    bgViewOne.userInteractionEnabled = YES;
    
    //头像按钮
    UIButton * iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    iconBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(80));
    iconBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(40);
    iconBtn.layer.masksToBounds = YES;
    [iconBtn setBackgroundImage:[UIImage imageNamed:@"default-face-拷贝"] forState:UIControlStateNormal];
    [iconBtn addTarget:self action:@selector(iconBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    _iconBtn = iconBtn;
    [bgViewOne addSubview:iconBtn];
    [self configIconUI];
    
    //姓名
    UILabel * name = [[UILabel alloc]initWithFrame:CGRectMake(iconBtn.origin.x + iconBtn.size.width + FIXWIDTHORHEIGHT(50), FIXWIDTHORHEIGHT(50), FIXWIDTHORHEIGHT(160), FIXWIDTHORHEIGHT(20))];
    name.text = @"刘诺一";
    name.font = [UIFont systemFontOfSize:personFontSize];
    name.textColor = color;
    _name = name;
    [bgViewOne addSubview:name];

    
    /*  个人信息  */
    
    UIImageView * bgViewTwo = [[UIImageView alloc]initWithFrame:CGRectMake(0, 64 + FIXWIDTHORHEIGHT(120), SCREEN_WIDTH, FIXWIDTHORHEIGHT(120))];
    bgViewTwo.image = [UIImage imageNamed:@"bg-5"];
    [self.view addSubview:bgViewTwo];
    bgViewTwo.userInteractionEnabled = YES;
    
    // 联系电话
    UILabel * numberL = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), 0, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(39))];
    numberL.text = @"联系电话";
    numberL.font = [UIFont systemFontOfSize:personFontSize];
    numberL.textColor = color;
    [bgViewTwo addSubview:numberL];
    
    UILabel * numberR = [[UILabel alloc]initWithFrame:CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(190), 0, FIXWIDTHORHEIGHT(150), FIXWIDTHORHEIGHT(39))];
    numberR.text = [[StateManager defaultManager] userNumber];//默认的是登陆电话
    numberR.textAlignment = NSTextAlignmentRight;
    numberR.textColor = color;
    numberR.font = [UIFont systemFontOfSize:personFontSize];
    _numberLable = numberR;
    [bgViewTwo addSubview:numberR];
    
    UIButton * numberBtn = [[UIButton alloc]initWithFrame:CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(190), 0, FIXWIDTHORHEIGHT(150), FIXWIDTHORHEIGHT(39))];
    [numberBtn addTarget:self action:@selector(changePhotoNumber) forControlEvents:UIControlEventTouchUpInside];
    [bgViewTwo addSubview:numberBtn];
    
    //小箭头
    UIImageView * smallImg = [[UIImageView alloc]initWithFrame:CGRectMake(bgViewOne.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(12.5), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(15))];
    smallImg.image = [UIImage imageNamed:@"more"];
    [bgViewTwo addSubview:smallImg];
    
    //实名认证
    UILabel * tureName = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), numberL.origin.y + numberL.size.height, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(39))];
    tureName.text = @"实名认证";
    tureName.font = [UIFont systemFontOfSize:personFontSize];
    tureName.textColor = color;
    [bgViewTwo addSubview:tureName];
    
    UILabel * tureNameR = [[UILabel alloc]initWithFrame:CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(180),  numberL.origin.y + numberL.size.height, FIXWIDTHORHEIGHT(140), FIXWIDTHORHEIGHT(39))];
    tureNameR.textAlignment = NSTextAlignmentRight;
    tureNameR.textColor = color;
    tureNameR.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewTwo addSubview:tureNameR];
    _tureNameLable = tureNameR;
    
    
    UIButton * tureNameBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    tureNameBtn.frame = CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(180),  numberL.origin.y + numberL.size.height, FIXWIDTHORHEIGHT(140), FIXWIDTHORHEIGHT(39));
    [tureNameBtn addTarget:self action:@selector(tureNameBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewTwo addSubview:tureNameBtn];
    _tureNameBtn = tureNameBtn;
    _tureNameBtn.enabled = NO;
    
    //小箭头
    UIImageView * tureImg = [[UIImageView alloc]initWithFrame:CGRectMake(bgViewOne.size.width - FIXWIDTHORHEIGHT(30), numberL.origin.y + numberL.size.height + FIXWIDTHORHEIGHT(12.5), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(15))];
    tureImg.image = [UIImage imageNamed:@"more"];
    [bgViewTwo addSubview:tureImg];
    tureImg.hidden = YES;
    _imageOne = tureImg;
    
    
 
    
    //资格认证
    UILabel * qualification = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), tureName.origin.y + tureName.size.height, FIXWIDTHORHEIGHT(100), FIXWIDTHORHEIGHT(39))];
    qualification.text = @"资格认证";
    qualification.font = [UIFont systemFontOfSize:personFontSize];
    qualification.textColor = color;
    [bgViewTwo addSubview:qualification];
    
    UILabel * qualificationR = [[UILabel alloc]initWithFrame:CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(180),  tureName.origin.y + tureName.size.height, FIXWIDTHORHEIGHT(140), FIXWIDTHORHEIGHT(39))];
    qualificationR.textAlignment = NSTextAlignmentRight;
    qualificationR.textColor = color;
    qualificationR.font = [UIFont systemFontOfSize:personFontSize];
    [bgViewTwo addSubview:qualificationR];
    _qualifyLable = qualificationR;
    

        
    //按钮
    UIButton * qualificationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    qualificationBtn.frame = CGRectMake(bgViewTwo.size.width - FIXWIDTHORHEIGHT(180),  tureName.origin.y + tureName.size.height, FIXWIDTHORHEIGHT(140), FIXWIDTHORHEIGHT(39));
    [qualificationBtn addTarget:self action:@selector(qualificationBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [bgViewTwo addSubview:qualificationBtn];
    _qualifyBtn = qualificationBtn;
    _qualifyBtn.enabled = NO;
    //小箭头
    UIImageView * qualificationImg = [[UIImageView alloc]initWithFrame:CGRectMake(bgViewOne.size.width - FIXWIDTHORHEIGHT(30), tureName.origin.y + tureName.size.height + FIXWIDTHORHEIGHT(12.5), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(15))];
    qualificationImg.image = [UIImage imageNamed:@"more"];
    [bgViewTwo addSubview:qualificationImg];
    qualificationImg.hidden = YES;
    _imageTwo = qualificationImg;
   
    
    /* 分割线 */
    
    if (iPHone5||iPHone4oriPHone4s) {
        
        for (int i = 0; i < 2; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(39 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewTwo addSubview:view];
        }

    }else{
    
        for (int i = 0; i < 2; i ++) {
            UIView * view = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(45 + i * 39), SCREEN_WIDTH - FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(1))];
            view.backgroundColor = RGBCOLOR(245, 245, 245);
            [bgViewTwo addSubview:view];
        }

    
    }
    /**
     *  头像
     */
    [self configIconUI];
    
}
#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载

#pragma mark--
#pragma mark 事件
#pragma mark--更改电话
-(void)changePhotoNumber{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBACOLOR(0, 0, 0, 0.5);
    bgView.alpha = 0.9;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    _backgroundView = bgView;
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapBtn)];
    tap.numberOfTapsRequired = 1;
    [_backgroundView addGestureRecognizer:tap];
    
    
    //弹出的选择框
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.2, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), FIXWIDTHORHEIGHT(110))];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = 5;
    popView.layer.masksToBounds = YES;
    _popView = popView;
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    
    UITextField * changeNumber = [[UITextField alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(10), popView.size.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(40))];
    changeNumber.layer.cornerRadius = 11;
    changeNumber.layer.masksToBounds = YES;
    changeNumber.backgroundColor = RGBCOLOR(204, 204, 204);//
    changeNumber.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    changeNumber.text = _numberLable.text;
    changeNumber.keyboardType = UIKeyboardTypePhonePad;
    [popView addSubview:changeNumber];
    _changeNumber = changeNumber;
    [_changeNumber becomeFirstResponder];
//    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
//    CGColorRef borderColor = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
    
    UIButton * cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancleBtn.frame = CGRectMake(FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(60), popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(40));
    cancleBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    cancleBtn.layer.masksToBounds = YES;
    [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
    cancleBtn.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [cancleBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [cancleBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [cancleBtn.layer setBorderColor:borderColor];
    [cancleBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [popView addSubview:cancleBtn];
    [cancleBtn addTarget:self action:@selector(cancleBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(popView.size.width * 0.5 + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(60), popView.size.width * 0.5 - FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(40));
    sureBtn.layer.cornerRadius = FIXWIDTHORHEIGHT(20);
    sureBtn.layer.masksToBounds = YES;
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    sureBtn.titleLabel.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(15)];
    [sureBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    [sureBtn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
//    [sureBtn.layer setBorderColor:borderColor];
    [sureBtn setBorderWidth:FIXWIDTHORHEIGHT(0.8) andBoredColorR:0 G:0 B:255];
    [popView addSubview:sureBtn];
    [sureBtn addTarget:self action:@selector(sureBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    NSLog(@"更改电话");
}
#pragma mark--更改电话确定取消按钮点击事件
/**
 *  取消
 */
-(void)cancleBtnClicked{
    
    [_changeNumber resignFirstResponder];
    [_backgroundView removeFromSuperview];
    [_popView removeFromSuperview];
    
}
/**
 *  确定
 */
-(void)sureBtnClicked{
    _numberLable.text = _changeNumber.text;
    _save.enabled = YES;
    [_changeNumber resignFirstResponder];
    [_backgroundView removeFromSuperview];
    [_popView removeFromSuperview];
}
-(void)tapBtn{
    [_changeNumber resignFirstResponder];
}
#pragma mark--头像照片的存储及认证状态
-(void)configIconUI{
    //头像存放路径
    NSArray * arr = NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSUserDomainMask, YES);
    NSString * path = [arr lastObject];
    NSString * imageDocPath = [path stringByAppendingPathComponent:@"ImageFile"];
    [[NSFileManager defaultManager]createDirectoryAtPath:imageDocPath withIntermediateDirectories:YES attributes:nil error:nil];
    _iconBtnPath  = [imageDocPath stringByAppendingPathComponent:@"icon.png"];
    
    
    
    if ([UIImage imageWithContentsOfFile:_iconBtnPath] != nil) {
        
        [_iconBtn setBackgroundImage:[UIImage imageWithContentsOfFile:_iconBtnPath] forState:UIControlStateNormal];
        
        _iconImage = [UIImage imageWithContentsOfFile:_iconBtnPath];
    }else if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"iconPath"] length]){
        
        [_iconBtn sd_setBackgroundImageWithURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:@"iconPath"]] forState:UIControlStateNormal];
        
    }
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"turename"] length]) {
        _name.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"turename"];
    }
  
}

#pragma mark -- 认证状态
-(void)nameStateAndQualiState{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeNone];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([[StateManager defaultManager].userId intValue]) forKey:@"servicerid"];
        
    [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,GETINFO] body:dic block:^(id backData) {

        if ([[backData objectForKey:@"status"] intValue]) {
            NSLog(@"%@",backData);
            [SVProgressHUD dismiss];
            int name = [[[backData objectForKey:@"result"] objectForKey:@"istatus"] intValue];
            int qualify = [[[backData objectForKey:@"result"] objectForKey:@"qstatus"] intValue];
            
            if ([[[[backData objectForKey:@"result"] objectForKey:@"servicer"] objectForKey:@"name"] length]) {
                
                _name.text = [[[backData objectForKey:@"result"] objectForKey:@"servicer"] objectForKey:@"name"];
                
                
            }

            if ([[[[backData objectForKey:@"result"] objectForKey:@"servicer"] objectForKey:@"icon"] length]) {
                
                
                [_iconBtn sd_setBackgroundImageWithURL:[NSURL URLWithString:[[[backData objectForKey:@"result"] objectForKey:@"servicer"] objectForKey:@"icon"]] forState:UIControlStateNormal];
                
            }

            [[NSUserDefaults standardUserDefaults] setObject:_name.text forKey:@"turename"];
            [[NSUserDefaults standardUserDefaults] setObject:@(name) forKey:@"qualify"];
            [[NSUserDefaults standardUserDefaults] setObject:@(qualify) forKey:@"qualify"];
            [self changeState:name qualifystate:qualify];
            
        }else{
            
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
            
        }
        
    } error:^(NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"获取失败"];
            NSLog(@"%@",error);
    }];
        
 
}
-(void)changeState:(int)nameState qualifystate:(int)qualityState{

    if (nameState == 3) {
        _imageOne.hidden = YES;
        _tureNameBtn.enabled = NO;
        _tureNameLable.text = @"已认证";
    }else if (nameState == 2){
        _imageOne.hidden = YES;
        _tureNameBtn.enabled = NO;
        _tureNameLable.text = @"审核中";
    }else{
        if (nameState == 4) {
            _tureNameLable.text = @"未通过";
        }else{
            _tureNameLable.text = @"未认证";
        }
        
        _imageOne.hidden = NO;
        _tureNameBtn.enabled = YES;
    }

    
    
    if (qualityState == 3) {
        _qualifyLable.text = @"已认证";
        _imageTwo.hidden = YES;
        _qualifyBtn.enabled = NO;
    }else if (qualityState == 2){
        _imageTwo.hidden = YES;
        _qualifyBtn.enabled = NO;
        _qualifyLable.text = @"审核中";
    }else{
        if (qualityState == 4) {
            _qualifyLable.text = @"未通过";
        }else{
            _qualifyLable.text = @"未认证";
        }
        
        _imageTwo.hidden = NO;
        _qualifyBtn.enabled = YES;
        
    }
    
}
#pragma mark--更换头像点击事件
-(void)iconBtnClicked{
    
    NSLog(@"更换头像点击事件");
    [self changeIconPopView];
    
}
#pragma mark--更换头像弹出视图
-(void)changeIconPopView{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    _backgroundView = bgView;
    
    
    //弹出的选择框
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(30), SCREEN_HEIGHT * 0.4, SCREEN_WIDTH - FIXWIDTHORHEIGHT(60), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = 5;
    popView.layer.masksToBounds = YES;
     [[UIApplication sharedApplication].keyWindow addSubview:popView];
    _popView = popView;
    
    float btnHeight = (popView.size.height - (20 + 20 + 5 + 5 ))/3.0;
    
    for (int i = 0; i < 3; i ++) {
        UIButton  * btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(20, 20 + (btnHeight + 5) * i , popView.size.width - 40, btnHeight);
        
        btn.layer.cornerRadius = btnHeight/2.0;
        btn.layer.masksToBounds = YES;
        
        [btn.layer setBorderWidth:FIXWIDTHORHEIGHT(0.8)];
        CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
        CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){1,0,0,1});
        [btn.layer setBorderColor:color];
        [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        if (i == 0) {
            
            [btn setImage:[[UIImage imageNamed:@"camera"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"拍照" forState:UIControlStateNormal];
            
        }else if (i == 1){
            [btn setImage:[[UIImage imageNamed:@"photo"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ] forState:UIControlStateNormal];
            [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];//上左下右
            [btn setTitle:@"从手机相册添加" forState:UIControlStateNormal];
        }else{
            
            [btn setTitle:@"取消" forState:UIControlStateNormal];
        }
        
        btn.tag = 4892472 + i;
        [btn addTarget:self action:@selector(takePhotoOrAlbumOrCancleBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [popView addSubview:btn];
    }
    
    
}
#pragma mark--拍照、从手机相册添加、取消的按钮点击事件
-(void)takePhotoOrAlbumOrCancleBtnClicked:(UIButton *)btn{
    switch (btn.tag) {
        case 4892472:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            [self takePhotoFromiphone];
            break;
        case 4892473:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            [self takePhotoFromAlbum];
            break;
        case 4892474:
            [_popView removeFromSuperview];
            [_backgroundView removeFromSuperview];
            break;
        default:
            break;
    }
}
#pragma mark--从手机拍照
-(void)takePhotoFromiphone{
    
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIImagePickerController * picker = [[UIImagePickerController alloc]init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = sourceType;
        [self presentViewController:picker animated:YES completion:nil];
    }else{
        NSLog(@"该设备没有摄像头");
    }
    
}
#pragma mark--从相册取照片
-(void)takePhotoFromAlbum{
    
    UIImagePickerController * picker = [[UIImagePickerController alloc]init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:nil];
    
}
#pragma mark--照片代理(接口)
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    
    if (image != nil) {
        
        self.chooseIconState = YES;
        
        _iconImage = image;
        
        _save.enabled = YES;
        
        [_iconBtn setBackgroundImage:image forState:UIControlStateNormal];
        
    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark--(保存按钮)联系电话和头像更改(接口)
-(void)saveToInternet{
    
    
    if ([StateManager defaultManager].reachState == 0) {
        [SVProgressHUD showErrorWithStatus:@"网络不可用"];
        return;
    }

    __weak __typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"保存中" maskType:SVProgressHUDMaskTypeClear];
    NSData * data = UIImageJPEGRepresentation(_iconImage, 0.5);
    _save.enabled = NO;
    [AFNConnection UploadPhotoPath:[NSString stringWithFormat:@"%@%@",IPDERSS,UPLOADPHOTO] data:data block:^(id backData) {
        if ([[backData objectForKey:@"status"] intValue]) {
            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            [dic setObject:[[backData objectForKey:@"result"] objectForKey:@"path"] forKey:@"icon"];
            [dic setObject:_numberLable.text forKey:PHONE];
            [dic setObject:@([[StateManager defaultManager].userId intValue]) forKey:@"servicerid"];
            NSLog(@"%@",dic);
            [AFNConnection PostDataUrl:[NSString stringWithFormat:@"%@%@",IPDERSS,UPLOADINFO] body:dic block:^(id backData) {
                if ([[backData objectForKey:@"status"] intValue]) {
                    [SVProgressHUD showSuccessWithStatus:[backData objectForKey:@"msg"]];
                    [[NSFileManager defaultManager]createFileAtPath:_iconBtnPath contents:data attributes:nil];
                    [[NSUserDefaults standardUserDefaults] setObject:[dic objectForKey:@"icon"] forKey:@"iconPath"];
                }else{
                    [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
                    _save.enabled = YES;
                    [weakSelf configIconUI];
                }
            } error:^(NSError *error) {
                [SVProgressHUD showErrorWithStatus:@"保存失败"];
                _save.enabled = YES;
                [weakSelf configIconUI];
            }];
        }else{
            [SVProgressHUD showErrorWithStatus:[backData objectForKey:@"msg"]];
            _save.enabled = YES;
            [weakSelf configIconUI];
        }
    } error:^(NSError *error) {
        _save.enabled = YES;
        [SVProgressHUD showErrorWithStatus:@"保存失败"];
        [weakSelf configIconUI];
        NSLog(@"联系电话和头像更改error:%@",error);
    }];
    
}
#pragma mark--实名认证按钮事件
-(void)tureNameBtnClicked{
    __weak __typeof(self) weakSelf = self;
    
    tureNameViewController * tureName = [[tureNameViewController alloc]init];
    [tureName returnTureNameState:^(BOOL state) {
        if (state) {
            weakSelf.imageOne.hidden = YES;
            weakSelf.tureNameLable.text = @"审核中";
            weakSelf.tureNameBtn.userInteractionEnabled = NO;
            NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
            [userInfo setObject:@2 forKey:@"nameState"];
        }
    }];
    [self presentViewController:tureName animated:YES completion:nil];
    
    NSLog(@"实名认证按钮事件");
}
#pragma mark--资格认证按钮事件
-(void)qualificationBtnClicked{
    
     __weak __typeof(self) weakSelf = self;
    
    if (IOSVERSION >= 8.0) {//版本高于8.0走这个方法
        qualificationViewController * qualification = [[qualificationViewController alloc]init];
        
        [qualification returnState:^(BOOL state) {
            if (state) {
                weakSelf.qualifyBtn.userInteractionEnabled = NO;
                weakSelf.qualifyLable.text = @"审核中";
                weakSelf.imageTwo.hidden = YES;
                NSUserDefaults * userInfo = [NSUserDefaults standardUserDefaults];
                [userInfo setObject:@2 forKey:@"qualify"];
            }
        }];
        UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:qualification];
        
        [self presentViewController:nav animated:YES completion:nil];
        
        
    }else{//手机版本低走这个方法
        
        UnderQualificationViewController * underQualification = [[UnderQualificationViewController alloc] init];
        
        UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:underQualification];
        
        [self presentViewController:nav animated:YES completion:nil];

    }
    

    
    NSLog(@"资格认证按钮事件");
}
#pragma mark  返回按钮事件
-(void)personBackBtnClicked{
    
     [self dismissViewControllerAnimated:YES completion:nil];
    
}



#pragma mark--  菊花残
-(void)popBigIndicatorToShowProgress{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = [UIColor clearColor];
    bgView.alpha = 0.9;
    bgView.tag = 14504823;
    [self.view addSubview:bgView];
    //菊花
    UIView * midle = [[UIView alloc]init];
    midle.size = CGSizeMake(60, 60);
    midle.center = self.view.center;
    midle.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    midle.layer.masksToBounds = YES;
    midle.backgroundColor = RGBCOLOR(108, 108, 108);
    [bgView addSubview:midle];
    UIActivityIndicatorView * activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activity.frame = CGRectMake(10, 10, 40, 40);
    
    [midle addSubview:activity];
    [activity startAnimating];
}
-(void)hidenBigIndicatorToShowProgress{
    
    for (UIView * view in self.view.subviews) {
        if (view.tag == 14504823) {
            [view removeFromSuperview];
        }
    }
}
#pragma mark--弹出提示窗口
-(void)popSuccessOrFailMessage:(NSString *)message andState:(BOOL)state{
    
    NSInteger second = 1;//几秒之后消失
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    bgView.tag = 41025787;
    [self.view addSubview:bgView];
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [bgView addSubview:popView];
    
    UIImageView * success = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, popView.size.height * 0.1, popView.size.width * 0.3, popView.size.width * 0.3)];
    if (state) {
        success.image = [UIImage imageNamed:@"sucess@2x_47"];
    }else{
        success.image = [UIImage imageNamed:@"warning"];
        second = 2;
    }
    
    [popView addSubview:success];
    
    UILabel * warn = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(5),success.size.height, popView.size.width - FIXWIDTHORHEIGHT(10), popView.size.height - popView.size.width * 0.3)];
    warn.text = message;
    warn.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
    warn.numberOfLines = 0;
    warn.textAlignment = NSTextAlignmentCenter;
    [popView addSubview:warn];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapWarnBtn)];
    tap.numberOfTapsRequired = 1;
    [bgView addGestureRecognizer:tap];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(second * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [bgView removeFromSuperview];
    });
    
}
-(void)tapWarnBtn{
    
    for (UIView * view in self.view.subviews) {
        if (view.tag == 41025787) {
            [view removeFromSuperview];
        }
    }
    
}
#pragma mark  --
#pragma mark--
#pragma mark  代理

#pragma mark--
#pragma mark 通知注册及销毁
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

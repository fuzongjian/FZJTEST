//
//  ongoingViewController.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/11.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ongoingViewController.h"
#import "ongoingCustomCell.h"
#import "ongoingDetailController.h"
#import "ongoingModel.h"


@interface ongoingViewController ()<UITableViewDataSource,UITableViewDelegate,OngoingCustomCellBtnClicked,UIGestureRecognizerDelegate>
@property(nonatomic,strong)UITableView * ongoingTable;
@property(nonatomic,strong)NSMutableArray * dataArr;
@property(nonatomic,strong)StateManager * stateManager;
/**
 *  判断有没有下一页
 */
@property(nonatomic,assign)BOOL nextPage;
@end

@implementation ongoingViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    /*  判断是否为上班状态  */
    [self judgeWorkState];
    
    [self loadOngoingViewControllerData];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
  [self stopMJRefresh:YES andMessage:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _stateManager = [StateManager defaultManager];
    
    /*  判断是否为上班状态  */
    [self judgeWorkState];
    
    [self configOngoingViewControllerUI];
    [self addHeaderAndFooterMJRefesh];

}
#pragma mark --
#pragma mark 初始化UI
-(void)configOngoingViewControllerUI{
    self.view.backgroundColor = [UIColor whiteColor];
    [self setCustomTitle:@"进行中"];
    self.imgView.hidden = YES;
    _dataArr = [NSMutableArray array];
    /*创建tableView*/
    
    _ongoingTable = [[UITableView alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(2), SCREEN_WIDTH, SCREEN_HEIGHT - FIXWIDTHORHEIGHT(2)) style:UITableViewStylePlain];
    _ongoingTable.delegate = self;
    _ongoingTable.dataSource = self;
    [self.view addSubview:_ongoingTable];
    
    //去掉分割线 滚动条
    _ongoingTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _ongoingTable.showsVerticalScrollIndicator = NO;
    _ongoingTable.backgroundColor = RGBCOLOR(240, 240, 240);
    _ongoingTable.tableFooterView = [UIView new];
    
    //添加手势
    UISwipeGestureRecognizer * swipeLight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeLight)];
    swipeLight.direction = UISwipeGestureRecognizerDirectionRight;
    [_ongoingTable addGestureRecognizer:swipeLight];
    UISwipeGestureRecognizer * swipeRight = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionLeft;
    [_ongoingTable addGestureRecognizer:swipeRight];
    
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapOngoingView:)];
    tap.numberOfTapsRequired = 1;
    tap.delegate = self;
    [_ongoingTable addGestureRecognizer:tap];
    
}
#pragma mark  --  增加上拉下拉刷新
-(void)addHeaderAndFooterMJRefesh{
    __weak __typeof(self) weakSelf = self;
    /**
     *  下拉刷新
     */
    _ongoingTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        [weakSelf loadOngoingViewControllerData];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([_ongoingTable.mj_header isRefreshing]) {
                [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
            }
        });
    }];
    
    /**
     *  上拉刷新
     */
    _ongoingTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        
        [weakSelf footerRefreshing];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if ([_ongoingTable.mj_footer isRefreshing]) {
                [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
            }
        });
        
    }];
    
}

#pragma mark--
#pragma mark 数据请求

#pragma mark--
#pragma mark 数据加载(接口)
-(void)loadOngoingViewControllerData{
    
    
    __weak __typeof(self) weakSelf = self;

    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
    [AFNConnection GetOngoingData:[NSString stringWithFormat:@"%@%@",IPDERSS,ORDERING] body:dic block:^(id backData) {
        
        _nextPage = [[backData objectForKey:@"nextpage"] intValue];
        weakSelf.dataArr = [NSMutableArray arrayWithArray:[backData objectForKey:@"dataArr"]];
        
        if (weakSelf.dataArr.count) {
            [weakSelf stopMJRefresh:YES andMessage:@"刷新成功"];
            [_ongoingTable reloadData];
        }else{
            [weakSelf stopMJRefresh:NO andMessage:@"没有进行中订单"];
            [_ongoingTable reloadData];
        }
    } error:^(NSError *error) {
        [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
        NSLog(@"error:%@",error);
    }];
}
-(void)footerRefreshing{
    
    __weak __typeof(self) weakSelf = self;

    if (![[[NSUserDefaults standardUserDefaults] objectForKey:LOGINSTATE] intValue]) {
        return;
    }
    
    if (_stateManager.reachState == 0) {
        [self stopMJRefresh:NO andMessage:@"网络不可用"];
        return;
    }
    
    if (_nextPage) {
        
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
        ongoingModel * model = [_dataArr lastObject];
        [dic setObject:model.creationTime forKey:@"createtime"];
        [AFNConnection GetOngoingData:[NSString stringWithFormat:@"%@%@",IPDERSS,ORDERING] body:dic block:^(id backData) {
            
            _nextPage = [[backData objectForKey:@"nextpage"] intValue];
            NSArray * array = [backData objectForKey:@"dataArr"];
            
            if (array.count) {
                [weakSelf stopMJRefresh:YES andMessage:@"加载成功..,"];
                [weakSelf.dataArr addObjectsFromArray:array];
                [_ongoingTable reloadData];
            }else{
                [weakSelf stopMJRefresh:NO andMessage:@"没有数据"];
            }
            
            
        } error:^(NSError *error) {
            [weakSelf stopMJRefresh:NO andMessage:@"刷新失败"];
        }];
        
        
        
    }else{
        [weakSelf stopMJRefresh:NO andMessage:@"已经是最后一页了"];
    }
    
    
}
/**
 *  停止刷新
 */
-(void)stopMJRefresh:(BOOL)state andMessage:(NSString *)message{
    
    if (!state && ([_ongoingTable.mj_header isRefreshing]||[_ongoingTable.mj_footer isRefreshing])) {
        [SVProgressHUD showErrorWithStatus:message];
    }
    
    
    if ([_ongoingTable.mj_footer isRefreshing]) {
        [_ongoingTable.mj_footer endRefreshing];
    }
    if ([_ongoingTable.mj_header isRefreshing]) {
        [_ongoingTable.mj_header endRefreshing];
    }
}
#pragma mark--
#pragma mark 事件
#pragma mark --上班状态的判断
-(void)judgeWorkState{
    
    StateManager * manager = [StateManager defaultManager];
    
    if (manager.workState) {
        
        self.rightBtn.hidden = YES;
        
    }else{
        
        self.rightBtn.hidden = YES;
    }
}
-(void)swipeRight{
    [self.superDelegate openOrCloseDrawer:NO];
}
-(void)swipeLight{
    [self.superDelegate openOrCloseDrawer:YES];
}
-(void)tapOngoingView:(UITapGestureRecognizer *)tap{
    if (_stateManager.drawerState) {
        [self closeDrawer];
    }
//    else{
//        [tap removeTarget:self action:@selector(tapOngoingView:)];
//    }
//    - (nullable NSArray<NSString *> *)actionsForTarget:(nullable id)target forControlEvent:(UIControlEvents)controlEvent;
    NSLog(@"%@",@"123");
    
    //UIButton * button = [UIButton createCustomButtonTitle:@"adfas"];
   // [button addTarget:self action:@selector(tapOngoingView) forControlEvents:UIControlEventTouchUpInside];
//    [button removeTarget:<#(nullable id)#> action:<#(nullable SEL)#> forControlEvents:<#(UIControlEvents)#>];
    
}
//-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRequireFailureOfGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
//    return NO;
//}
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
//    NSLog(@"1234567890");
//    return NO;//事件响应
////    return YES;//方法来四次 自己的事件响应一次
//}
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (_stateManager.drawerState) {
        return YES;
    }else{
        return NO;
    }
}
#pragma mark--
#pragma mark  代理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * ongoingId = @"ongoingId";
    
    ongoingCustomCell * cell = [tableView dequeueReusableCellWithIdentifier:ongoingId];
    if (!cell) {
        cell = [[ongoingCustomCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ongoingId];
    }
    
    
    /*  拿到自定义cell的代理 */
    cell.cellDelegate = self;
    cell.cellRow = indexPath.row;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = RGBCOLOR(240, 240, 240);
    
    ongoingModel * model = _dataArr[indexPath.row];
    
    cell.sum.text = [NSString stringWithFormat:@"%@",model.money];
    cell.durationTime.text = [NSString stringWithFormat:@"服务时长：%.1f小时",[model.duration floatValue]];
    cell.aimHospital.text = [NSString stringWithFormat:@"目标医院：%@",model.hospitalName];
    cell.startTime.text = [NSString stringWithFormat:@"开始时间：%@",model.startTime];
    cell.name.text = [NSString stringWithFormat:@"联系人：%@",model.contactsName];
    
    if ([model.shuttle intValue]) {
        cell.shuttleView.alpha = 1.0;
    }else{
        cell.shuttleView.alpha = 0.0;
    }
    
    cell.star.text = [NSString stringWithFormat:@"%@",model.serviceTypeName];
    cell.starView.backgroundColor = RGBCOLOR([model.red floatValue], [model.green floatValue], [model.blue floatValue]);
    

    
    int state = [model.status intValue];
    if (state == 2) {
        cell.state.text = @"已接单";
    }else if (state == 3){
        cell.state.text = @"已付款";
    }else if (state == 4){
        cell.state.text = @"服务开始";
    }else if (state == 5){
        cell.state.text = @"服务结束";
    }else if(state == 6){
        cell.state.text = @"等待结账";
    }else{
        cell.state.text = @"等待评价";
    }

    
//    @property(nonatomic,strong)UILabel * sum;//总额
//    @property(nonatomic,strong)UILabel * aimHospital;//目标医院
//    @property(nonatomic,strong)UILabel * startTime;//开始时间
//    @property(nonatomic,strong)UILabel * durationTime;//服务时间
//    @property(nonatomic,strong)UILabel * star;//服务等级
//    @property(nonatomic,strong)UIView * starView;//背景颜色
//    @property(nonatomic,strong)UILabel * name;//联系人名字
//    @property(nonatomic,strong)UIImageView * bgview;//背景图片
//    @property(nonatomic,strong)UILabel * state;//付款状态
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    StateManager * manager = [StateManager defaultManager];//如果抽屉打开取消跳转
    if (!manager.drawerState) {
        ongoingDetailController * ongoingDetail = [[ongoingDetailController alloc]init];
        
        ongoingModel * model = _dataArr[indexPath.row];
        
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        [dic setObject:@([_stateManager.userId intValue]) forKey:@"servicerid"];
        [dic setObject:model.Nid forKey:@"orderid"];
        ongoingDetail.dic = dic;
        
        
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:ongoingDetail animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else{
        [self closeDrawer];
    }
    NSLog(@"表格点击事件   选中第%d行",(int)indexPath.row);
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return FIXWIDTHORHEIGHT(120);
}
/*     实现自定义cell的协议方法    */
-(void)customBtnClicked:(NSInteger)cellRow{
    
    ongoingModel * model = _dataArr[cellRow];

    /**
     打电话无提示窗口
     */
    
    
    NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",model.contactsPhone];
    UIWebView * callWebView = [[UIWebView alloc]init];
    [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebView];
    

    NSLog(@"点了第%d行的电话按钮",(int)cellRow);
    
}
-(void)closeDrawer{
    if(self.navigationController)
    {
        if(self.navigationController.tabBarController)
        {
            if([self.navigationController.tabBarController respondsToSelector:@selector(close)])
            {
                [self.navigationController.tabBarController performSelector:@selector(close)];
            }
        }
    }

}

#pragma mark--
#pragma mark 通知注册及销毁

#pragma mark --- 重写父类的通知方法（登陆后发出的通知）
-(void)uploadPersonData:(NSNotification *)notify{
    NSLog(@"重写父类的通知方法（登陆后发出的通知）");
    [self loadOngoingViewControllerData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

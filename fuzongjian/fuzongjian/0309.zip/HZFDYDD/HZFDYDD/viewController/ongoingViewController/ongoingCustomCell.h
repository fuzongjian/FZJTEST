//
//  ongoingCustomCell.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/13.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

/*定义一个协议来区分表格的点击事件和表格上按钮的点击事件*/

@protocol OngoingCustomCellBtnClicked <NSObject>

-(void)customBtnClicked:(NSInteger)cellRow;

@end


@interface ongoingCustomCell : UITableViewCell
@property(nonatomic,strong)UILabel * sum;//总额
@property(nonatomic,strong)UILabel * aimHospital;//目标医院
@property(nonatomic,strong)UILabel * startTime;//开始时间
@property(nonatomic,strong)UILabel * durationTime;//服务时间
@property(nonatomic,strong)UILabel * star;//服务等级
@property(nonatomic,strong)UIView * starView;//背景颜色
@property(nonatomic,strong)UILabel * name;//联系人名字
@property(nonatomic,strong)UIImageView * bgview;//背景图片
@property(nonatomic,strong)UILabel * state;//付款状态

@property(nonatomic,strong)UIView * shuttleView;
@property(nonatomic,strong)UILabel * shuttle;

@property(nonatomic,assign)id<OngoingCustomCellBtnClicked>cellDelegate;
@property(nonatomic,assign)NSInteger cellRow;

@end

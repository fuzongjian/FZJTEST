//
//  ongoingCustomCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/13.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ongoingCustomCell.h"

@implementation ongoingCustomCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self configOngoingCustomCellUI];
        
    }
    return  self;
}
-(void)configOngoingCustomCellUI{
    
    /*背景图片*/
    
    _bgview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, FIXWIDTHORHEIGHT(120))];
    _bgview.image = [UIImage imageNamed:@"bg-1"];
    [self.contentView addSubview:_bgview];
    _bgview.userInteractionEnabled = YES;
    
    /* 总额 */
    float sumFontSize = FIXWIDTHORHEIGHT(15);//总额行的字体大小
    UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(40), FIXWIDTHORHEIGHT(20))];
    lable.text = @"总额:";
    [_bgview addSubview:lable];
    lable.font = [UIFont systemFontOfSize:sumFontSize];
    _sum = [[UILabel alloc]initWithFrame:CGRectMake(lable.origin.x + lable.size.width + FIXWIDTHORHEIGHT(5), FIXWIDTHORHEIGHT(10), FIXWIDTHORHEIGHT(50), FIXWIDTHORHEIGHT(20))];
    _sum.text = @"300元";
    _sum.textColor = [UIColor redColor];
    _sum.font = [UIFont systemFontOfSize:sumFontSize];
    [_bgview addSubview:_sum];
    
    /*服务等级*/
    _starView = [[UIView alloc]initWithFrame:CGRectMake(_bgview.size.width * 0.8, 0, _bgview.size.width * 0.15, FIXWIDTHORHEIGHT(30))];
    _starView.backgroundColor = RGBCOLOR(157, 206, 134);
    _starView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _starView.layer.masksToBounds = YES;
    [_bgview addSubview:_starView];
    _star = [[UILabel alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(5), _bgview.size.width * 0.15, FIXWIDTHORHEIGHT(20))];
    _star.text = @"普通";
    _star.font = [UIFont systemFontOfSize:sumFontSize];
    _star.textColor = [UIColor whiteColor];
    _star.textAlignment = NSTextAlignmentCenter;
    [_starView addSubview:_star];
    
    _shuttleView = [[UIView alloc]initWithFrame:CGRectMake(_bgview.size.width * 0.6, 0, _bgview.size.width * 0.15, FIXWIDTHORHEIGHT(30))];
    _shuttleView.backgroundColor = RGBCOLOR(157, 206, 134);
    _shuttleView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _shuttleView.layer.masksToBounds = YES;
    [_bgview addSubview:_shuttleView];
    
    _shuttle = [[UILabel alloc]initWithFrame:CGRectMake(0, FIXWIDTHORHEIGHT(5), _bgview.size.width * 0.15, FIXWIDTHORHEIGHT(20))];
    _shuttle.text = @"接送";
    _shuttle.font = [UIFont systemFontOfSize:sumFontSize];
    _shuttle.textColor = [UIColor whiteColor];
    _shuttle.textAlignment = NSTextAlignmentCenter;
    [_shuttleView addSubview:_shuttle];
    
    
    
    /*分割线*/
    UIView * small = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(10), _sum.origin.y + _sum.size.height + FIXWIDTHORHEIGHT(5), _bgview.size.width - FIXWIDTHORHEIGHT(20), FIXWIDTHORHEIGHT(1))];
    small.backgroundColor = RGBCOLOR(240, 240, 240);
    [_bgview addSubview:small];
    

    float fontSize = FIXWIDTHORHEIGHT(12);
    
    /*联系人*/
    _name = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), small.origin.y + FIXWIDTHORHEIGHT(5), _bgview.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _name.text = @"联系人：李明";
    _name.font = [UIFont systemFontOfSize:fontSize];
    _name.textColor = RGBCOLOR(142, 142, 142);;
    [_bgview addSubview:_name];
    
    /*目标医院*/
    _aimHospital = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), _name.origin.y + _name.size.height, _bgview.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _aimHospital.text = @"目标医院：浙江大学第一附属医院";
    _aimHospital.font = [UIFont systemFontOfSize:fontSize];
    _aimHospital.textColor = RGBCOLOR(142, 142, 142);
    [_bgview addSubview:_aimHospital];
    
    /*开始时间*/
    _startTime = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), _aimHospital.origin.y + _aimHospital.size.height, _bgview.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _startTime.text = @"开始时间：2015-11-11  15:30";
    _startTime.font = [UIFont systemFontOfSize:fontSize];
    _startTime.textColor = RGBCOLOR(142, 142, 142);
    [_bgview addSubview:_startTime];
    
    /*服务时间*/
    _durationTime = [[UILabel alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(15), _startTime.origin.y + _startTime.size.height, _bgview.size.width - FIXWIDTHORHEIGHT(30), FIXWIDTHORHEIGHT(18))];
    _durationTime.text = @"服务时长：3个小时";
    _durationTime.font = [UIFont systemFontOfSize:fontSize];
    _durationTime.textColor = RGBCOLOR(142, 142, 142);
    [_bgview addSubview:_durationTime];

    /*电话按钮*/
    UIButton * call = [UIButton buttonWithType:UIButtonTypeCustom];
    call.frame = CGRectMake(_bgview.size.width * 0.83, _bgview.size.height * 0.4, _bgview.size.height * 0.3, _bgview.size.height * 0.3);
    [call setBackgroundImage:[UIImage imageNamed:@"call"] forState:UIControlStateNormal];
    [call addTarget:self action:@selector(callBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [_bgview addSubview:call];
    
    /*付款状态*/
    
    _state = [[UILabel alloc]initWithFrame:CGRectMake(_bgview.size.width * 0.78, _bgview.size.height * 0.7, _bgview.size.width * 0.2, _bgview.size.height * 0.2)];
    _state.text = @"等待中";
    _state.textAlignment = NSTextAlignmentCenter;
    _state.font = [UIFont systemFontOfSize:sumFontSize];
    [_bgview addSubview:_state];
    
}
- (void)awakeFromNib {
    // Initialization code
}
-(void)callBtnClicked{
    NSLog(@"打电话");
    
    if (_cellDelegate != nil && [_cellDelegate respondsToSelector:@selector(customBtnClicked:)]) {
        
        [_cellDelegate customBtnClicked:_cellRow];
        
    }
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

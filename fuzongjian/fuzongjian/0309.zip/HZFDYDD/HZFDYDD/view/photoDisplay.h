//
//  photoDisplay.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/6.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface photoDisplay : UICollectionViewCell
@property(nonatomic,strong)UIImageView * imageView;
@end

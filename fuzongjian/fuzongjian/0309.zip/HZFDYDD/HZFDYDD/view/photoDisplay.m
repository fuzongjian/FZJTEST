//
//  photoDisplay.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/6.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "photoDisplay.h"

@implementation photoDisplay
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self configPhotoDisplay];
        
    }
    return self;
}

-(void)configPhotoDisplay{
    
    _imageView = [[UIImageView alloc]initWithFrame:self.frame];
    _imageView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _imageView.layer.masksToBounds = YES;
    
    [self addSubview:_imageView];
    
}
@end

//
//  historyCheckCell.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/19.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "historyCheckCell.h"

@implementation historyCheckCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self configHistoryDetailCellUI];
        
    }
    return self;
}
-(void)configHistoryDetailCellUI{
    
    _imageView = [[UIImageView alloc] initWithFrame:self.frame];
    
    
    _imageView.top = FIXWIDTHORHEIGHT(1);
    
    _imageView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    _imageView.layer.masksToBounds = YES;
    
    [self addSubview:_imageView];
}
@end

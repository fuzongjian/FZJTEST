//
//  DisplayCollectionViewCell.h
//  FZJALAPhotos
//
//  Created by fdkj0002 on 16/2/1.
//  Copyright © 2016年 FZJ.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisplayCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *ImageView;

@end

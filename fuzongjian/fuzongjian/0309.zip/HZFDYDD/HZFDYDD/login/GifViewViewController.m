//
//  GifViewViewController.m
//  FDYDD
//
//  Created by chensa on 16/1/18.
//  Copyright © 2016年 fdkj0001. All rights reserved.
//

#import "GifViewViewController.h"
#import "GifView.h"


#import "DrawerViewController.h"
#import "homeTabBarController.h"
#import "leftViewController.h"

@interface GifViewViewController ()<GitViewDelegate>
@property(strong,nonatomic)GifView *gifview;

@end

@implementation GifViewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor = RGBCOLOR(250, 246, 243);
    
    
    _gifview  =[[GifView alloc] initWithFrame:CGRectMake(0, 0, 550/2, 550/2) filePath:[[NSBundle mainBundle] pathForResource:@"logo-animated" ofType:@"gif"]];//Gift为第三方组件，pathForResource填文件名字，ofType填文件格式
    _gifview.delegate = self;
    _gifview.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2); //设置GIF播放器的左边界的坐标
    [self.view addSubview:_gifview];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)GitEnd
{
//    用NSUserDefaults判断是否首次登录
    //设置根视图
    DrawerViewController * drawer = [[DrawerViewController alloc]initWithRootViewController:[[homeTabBarController alloc]init] andLeftViewController:[[leftViewController alloc]init] andRightViewController:nil];
    
    [self.navigationController pushViewController:drawer animated:NO];
    
}

@end

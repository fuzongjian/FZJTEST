//
//  FMDBHelper.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//



//@property(nonatomic, copy) NSString * Description;
//@property(nonatomic, strong) NSNumber * hospital;
//@property(nonatomic, copy) NSString * serviceDel;
//@property(nonatomic, copy) NSString * replyTime;
//@property(nonatomic, copy) NSString * payTime;
//@property(nonatomic, strong) NSNumber * status;
//@property(nonatomic, copy) NSString * money;
//@property(nonatomic, copy) NSString * duration;
//@property(nonatomic, copy) NSString * patientName;
//@property(nonatomic, copy) NSString * userRating;
//@property(nonatomic, copy) NSString * userId;


//@property(nonatomic, copy) NSString * endtime;
//@property(nonatomic, copy) NSString * serviceRating;
//@property(nonatomic, copy) NSString * creationTime;
//@property(nonatomic, copy) NSString * endType;
//@property(nonatomic, strong) NSNumber * Id;//1 VIP 2 普通  3 专业
//@property(nonatomic, copy) NSString * serviceUser;
//@property(nonatomic, copy) NSString * contactsName;
//@property(nonatomic, copy) NSString * contactsPhone;
//@property(nonatomic, copy) NSString * serviceType;
//@property(nonatomic, copy) NSString * userDel;
//@property(nonatomic, copy) NSString * healthRecord;
//@property(nonatomic, copy) NSString * serviceContent;
//@property(nonatomic, copy) NSString * startTime;
//@property(nonatomic, copy) NSString * orderLevel;
//insert into able (Description ,hospital ,serviceDel ,replyTime ,payTime ,status ,money ,duration ,patientName ,userRating ,userId ,endtime ,serviceRating ,creationTime ,endType ,Nid ,serviceUser ,contactsName ,contactsPhone ,serviceType ,userDel ,healthRecord ,serviceContent ,startTime ,orderLevel) values ('123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123','123')

#import "FMDBHelper.h"
#import "FMDB.h"

@implementation FMDBHelper
+(FMDatabase *)getCurrentDB{
    static FMDatabase * db;
    if (!db) {
        NSString * path = [NSString stringWithFormat:@"%@/Documents/BDYS.db",NSHomeDirectory()];
        NSLog(@"数据库路径----%@",path);
        
        db = [FMDatabase databaseWithPath:path];
        if ([db open]) {
            if (![db tableExists:@"able"]) {
                
                NSString * creatableSql = @"create table able (id integer primary key autoincrement,Description varchar(100),hospitalId varchar(100),serviceDel varchar(100),replyTime varchar(100),payTime varchar(100),status varchar(100),money varchar(100),duration varchar(100),patientName varchar(100),userRating varchar(100),userId varchar(100),endtime varchar(100),serviceRating varchar(100),creationTime varchar(100),endType varchar(100),Nid varchar(100),serviceUser varchar(100),contactsName varchar(100),contactsPhone varchar(100),serviceType varchar(100),userDel varchar(100),healthRecord varchar(100),serviceContent varchar(100),startTime varchar(100),orderLevel varchar(100),hospitalName varchar(100));";
                [db executeStatements:creatableSql];
            }
        }
        [db close];
    }
    return db;
}
@end

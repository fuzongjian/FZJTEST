//
//  ableDAO.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ableModel;

@interface ableDAO : NSObject

+(BOOL)saveAbleModel:(ableModel *)model;

+(void)updateAbleModel:(ableModel *)model;

+(void)deleteAbleModel:(ableModel *)model;

+(ableModel *)findAbleModel:(ableModel *)model;


+(NSArray *)findAll;

@end

//
//  ableDAO.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "ableDAO.h"
#import "ableModel.h"
#import "FMDB.h"
@implementation ableDAO

+(BOOL)saveAbleModel:(ableModel *)model{
    FMDatabase * db = [FMDBHelper getCurrentDB];
    if (![db open]) {
        return NO;
    }else{
        BOOL success = [db executeUpdate:@"INSERT INTO able(Description,hospitalId,serviceDel,replyTime,payTime,status,money,duration,patientName,userRating,userId,endtime,serviceRating,creationTime,endType,Nid,serviceUser,contactsName,contactsPhone,serviceType,userDel,healthRecord,serviceContent,startTime,orderLevel,hospitalName) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",model.Description,[model.hospitalId description],model.serviceDel,model.replyTime,model.payTime,[model.status description],model.money,model.duration,model.patientName,model.userRating,model.userId,model.endtime,model.serviceRating,model.creationTime,model.endType,[model.Nid description],model.serviceUser,model.contactsName,model.contactsPhone,model.serviceType,model.userDel,model.healthRecord,model.serviceDel,model.startTime,model.orderLevel,model.hospitalName];
        [db close];
        return success;
    }
    return YES;
}

+(void)updateAbleModel:(ableModel *)model{
    
}

+(void)deleteAbleModel:(ableModel *)model{
    
}

+(ableModel *)findAbleModel:(ableModel *)model{
    return [[ableModel alloc]init];
}


+(NSArray *)findAll{
    FMDatabase * db = [FMDBHelper getCurrentDB];
    if (![db open]) {
        return nil;
    }else{
        NSMutableArray * arr = [NSMutableArray array];
        FMResultSet * set = [db executeQuery:@"select * from able"];
        while (set.next) {
            ableModel * model = [[ableModel alloc]init];
            
            model.Description = [set stringForColumnIndex:1];
            model.hospitalId = [set objectForColumnIndex:2];
            model.serviceDel = [set stringForColumnIndex:3];
            model.replyTime = [set stringForColumnIndex:4];
            model.payTime = [set stringForColumnIndex:5];
            model.status = [set objectForColumnIndex:6];
            model.money = [set stringForColumnIndex:7];
            model.duration = [set stringForColumnIndex:8];
            model.patientName = [set stringForColumnIndex:9];
            model.userRating = [set stringForColumnIndex:10];
            model.userId = [set stringForColumnIndex:11];
            model.endtime = [set stringForColumnIndex:12];
            model.serviceRating = [set stringForColumnIndex:13];
            model.creationTime = [set stringForColumnIndex:14];
            model.endType = [set stringForColumnIndex:15];
            model.Nid = [set objectForColumnIndex:16];
            model.serviceUser = [set stringForColumnIndex:17];
            model.contactsName = [set stringForColumnIndex:18];
            model.contactsPhone = [set stringForColumnIndex:19];
            model.serviceType = [set stringForColumnIndex:20];
            model.userDel = [set stringForColumnIndex:21];
            model.healthRecord = [set stringForColumnIndex:22];
            model.serviceContent = [set stringForColumnIndex:23];
            model.startTime = [set stringForColumnIndex:24];
            model.orderLevel = [set stringForColumnIndex:25];
            model.hospitalName = [set stringForColumnIndex:26];
            [arr addObject:model];
            
        }
        [db close];
        return arr;
    }
}

//Description,hospital,serviceDel,replyTime,payTime,status,money,duration,patientName,userRating,userId,endtime,serviceRating,creationTime,endType,Nid,serviceUser,contactsName,contactsPhone,serviceType,userDel,healthRecord,serviceContent,startTime,orderLevel

@end

//
//  FMDBHelper.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/28.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FMDatabase;

@interface FMDBHelper : NSObject

+(FMDatabase *)getCurrentDB;

@end

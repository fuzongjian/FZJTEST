//
//  AFNConnection.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/14.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>

typedef void(^myblock) (id backData);
typedef void(^errorBlock) (NSError *error);

@interface AFNConnection : NSObject

//GET请求
+(void)GetData:(NSString *)string block:(myblock)block error:(errorBlock)errorBlock;
//Post请求
+ (void)PostDataUrl:(NSString *)string body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock;

//图片上传
+(void)UploadPhotoPath:(NSString *)path body:(NSDictionary *)body data:(NSData *)data block:(myblock)block error:(errorBlock)errorBlock;

+(void)UploadPhotoPath:(NSString *)path data:(NSData *)data block:(myblock)block error:(errorBlock)errorBlock;

//获得可接订单数据
+(void)GetAbleData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock ;
//获得历史订单数据
+(void)GetHistoryData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock;
//获得历史订单数据
+(void)GetOngoingData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock;

//获取金额信息数据
+(void)getAccontData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock;
/**
 *  获取信息列表
 */
+(void)getMessageData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock;


@end

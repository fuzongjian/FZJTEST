//
//  AFNConnection.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/14.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "AFNConnection.h"

#import "ableModel.h"
#import "ongoingModel.h"
#import "historyModel.h"
#import "accountModel.h"
#import "messageModel.h"

#import "ableDAO.h"



@implementation AFNConnection

#pragma mark--简单get请求
+(void)GetData:(NSString *)string block:(myblock)block error:(errorBlock)errorBlock
{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [manager GET:string parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSDictionary *obj = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        block(obj);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];
}
#pragma mark--简单post请求
+ (void)PostDataUrl:(NSString *)string body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
    
    
    AFHTTPSessionManager *manager = [self getManager];
    
    [manager POST:string parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
         block(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         errorBlock(error);
    }];
    
}

+(void)UploadPhotoPath:(NSString *)path body:(NSDictionary *)body data:(NSData *)data block:(myblock)block error:(errorBlock)errorBlock{
    
    AFHTTPSessionManager *manager = [self getManager];
    
    [manager POST:path parameters:body constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
    [formData appendPartWithFileData:data name:@"file" fileName:@"icon.png" mimeType:@""];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        block(responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];
    
}
#pragma mark--上传图片
+(void)UploadPhotoPath:(NSString *)path data:(NSData *)data block:(myblock)block error:(errorBlock)errorBlock{
    
    AFHTTPSessionManager *manager = [self getManager];
    
    [manager POST:path parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [formData appendPartWithFileData:data name:@"file" fileName:@"icon.png" mimeType:@""];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        block(responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];

}
#pragma mark--批量上传图片
+(void)uploadManyPhotoPath:(NSString *)path photoArr:(NSArray *)array block:(myblock)block error:(errorBlock)errorBlock{
    
}
#pragma mark--获取可接订单数据
+(void)GetAbleData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
    AFHTTPSessionManager *manager = [self getManager];
    [manager POST:path parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"获取可接订单数据--%@",[responseObject objectForKey:@"msg"]);
        if ([[responseObject objectForKey:@"status"] intValue]) {
            if ([responseObject objectForKey:@"result"]) {
                NSDictionary  * Dic = [responseObject objectForKey:@"result"] ;
                
                if ([Dic objectForKey:@"orderlist"]) {
                    NSMutableArray * dataArr = [NSMutableArray array];
                    NSArray * arr = [Dic objectForKey:@"orderlist"];
                    for (NSDictionary * dic in arr) {
                        ableModel * model = [[ableModel alloc]init];
                        [model setValuesForKeysWithDictionary:dic];
                        [dataArr addObject:model];
                    }
                    NSMutableDictionary * dicData = [NSMutableDictionary dictionary];
                    [dicData setObject:[Dic objectForKey:@"nextpage"] forKey:@"nextpage"];
                    [dicData setObject:dataArr forKey:@"dataArr"];
                    block(dicData);
                }
               
            }
   
        }else{
            block(nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];
    
}
#pragma mark--获取历史订单数据
+(void)GetHistoryData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
    AFHTTPSessionManager * manager = [self getManager];
    [manager POST:path parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"获取历史订单数据--%@",[responseObject objectForKey:@"msg"]);
        if ([[responseObject objectForKey:@"status"] intValue]) {
            if ([responseObject objectForKey:@"result"]) {
                NSDictionary  * Dic = [responseObject objectForKey:@"result"] ;
                if ([Dic objectForKey:@"orderlist"]) {
                    NSMutableArray * dataArr = [NSMutableArray array];
                    NSArray * arr = [Dic objectForKey:@"orderlist"];
                    for (NSDictionary * dic in arr) {
                        historyModel * model = [[historyModel alloc]init];
                        [model setValuesForKeysWithDictionary:dic];
                        [dataArr addObject:model];
                    }
                    NSMutableDictionary * dicData = [NSMutableDictionary dictionary];
                    [dicData setObject:[Dic objectForKey:@"nextpage"] forKey:@"nextpage"];
                    [dicData setObject:dataArr forKey:@"dataArr"];
                    block(dicData);
                }
                
            }
            
        }else{
            block(nil);
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         errorBlock(error);
    }];
}
#pragma mark--获取进行中订单数据
+(void)GetOngoingData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
     AFHTTPSessionManager * manager = [self getManager];
    [manager POST:path parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([[responseObject objectForKey:@"status"] intValue]) {
            if ([responseObject objectForKey:@"result"]) {
                NSDictionary  * Dic = [responseObject objectForKey:@"result"] ;
                if ([Dic objectForKey:@"orderlist"]) {
                    NSMutableArray * dataArr = [NSMutableArray array];
                    NSArray * arr = [Dic objectForKey:@"orderlist"];
                    for (NSDictionary * dic in arr) {
                        ongoingModel * model = [[ongoingModel alloc]init];
                        [model setValuesForKeysWithDictionary:dic];
                        [dataArr addObject:model];
                    }
                    NSMutableDictionary * dicData = [NSMutableDictionary dictionary];
                    [dicData setObject:[Dic objectForKey:@"nextpage"] forKey:@"nextpage"];
                    [dicData setObject:dataArr forKey:@"dataArr"];
                    block(dicData);
                }
                
            }
            
        }else{
            block(nil);
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];
}

#pragma mark--获取金额信息
+(void)getAccontData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
    AFHTTPSessionManager * manager = [self getManager];
    
    [manager POST:path parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"获取金额信息数据--%@",[responseObject objectForKey:@"msg"]);
        
        if ([[responseObject objectForKey:@"status"] intValue]) {
            if ([responseObject objectForKey:@"result"]) {
                NSDictionary  * Dic = [responseObject objectForKey:@"result"] ;
                if ([Dic objectForKey:@"billlist"]) {
                    NSMutableArray * dataArr = [NSMutableArray array];
                    NSArray * arr = [Dic objectForKey:@"billlist"];

                    for (NSDictionary * dic in arr) {
                        accountModel * model = [[accountModel alloc]init];
                        [model setValuesForKeysWithDictionary:dic];
                        [dataArr addObject:model];
                    }
                    NSMutableDictionary * data = [NSMutableDictionary dictionary];
                    [data setObject:dataArr forKey:@"dataArr"];
                    [data setObject:[Dic objectForKey:@"earn"] forKey:@"all"];
                    block(data);
                }
                
            }
        }else{
            block(nil);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];

}
+(void)getMessageData:(NSString *)path body:(NSDictionary *)body block:(myblock)block error:(errorBlock)errorBlock{
    
    AFHTTPSessionManager * manager = [self getManager];
    
    [manager POST:path parameters:body progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([[responseObject objectForKey:@"status"] intValue]) {
            NSArray * array = [[responseObject objectForKey:@"result"] objectForKey:@"messagelist"];
            if (array.count) {
                NSMutableArray * dataArr = [NSMutableArray array];
                for (NSDictionary * dic in array) {
                    messageModel * model = [[messageModel alloc]init];
                    [model setValuesForKeysWithDictionary:dic];
                    [dataArr addObject: model];
                }
                block(dataArr);
            }
        }else{
            block(nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        errorBlock(error);
    }];
    
    
}
+(AFHTTPSessionManager *)getManager{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //申明返回的结果是json类型
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //申明请求的数据是json类型
    manager.requestSerializer= [AFJSONRequestSerializer serializer];
    
    //如果报接受类型不一致请替换一致text/html或别的
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    return manager;
}


@end

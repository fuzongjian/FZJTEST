//
//  StateManager.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/16.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StateManager : NSObject
@property(nonatomic,assign)BOOL workState;//用来判断工作状态
@property(nonatomic,strong)NSString * iconPath;//头像的路径
@property(nonatomic,assign)BOOL drawerState;


@property(nonatomic,strong)NSString * userId;//用户ID
@property(nonatomic,strong)NSString * userNumber;//用户电话号码
@property(nonatomic,strong)NSString * userName;


@property(nonatomic,assign)NSInteger reachState;//0--网络不可用  1--wifi  2--其他网络
////系统照片
//@property(nonatomic,strong)NSDictionary * PhotoDic;
//@property(nonatomic,assign)BOOL photoState;

/**
 *  实名认证状态
 */
@property(nonatomic,assign)NSInteger nameState;

/**
 *  资格认证状态
 */
@property(nonatomic,assign)NSInteger qualifyState;



+(instancetype)defaultManager;

@end

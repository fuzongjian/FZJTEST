//
//  path.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/23.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#ifndef path_h
#define path_h

/*    IP   */
//#define IPDERSS @"http://192.168.31.134:8080/bdys"

//http://192.168.31.134:8080/bdys
//http://192.168.31.134:8081/bdys-app
//http://121.41.117.5:8080/bdys

//#define IPDERSS @"http://192.168.31.134:8081/bdys-app"


#define IPDERSS @"http://121.41.117.5:8080/bdys"


/*  获取验证码 完成  post*/
#define TESTCODE @"/account/verificationcode/getcode"

/*   登陆接口  完成 post*/
#define LOGIN @"/account/auth/login"

/*   上传图片   post*/
#define UPLOADPHOTO @"/event/file/upload"

/*   提交意见反馈*/
#define FEEDBACK @"/event/feedback/sub"

/*   获取服务器当前时间  get*/
#define GRTTIME @"/info/syscfg/getsystime"

/*   提交当前位置信息   */
#define LOCATION @"/account/servicer/getlocation"
//6

/**
 *  更改个人信息
 */

#define UPLOADINFO @"/account/servicer/updateinfo"

/**
 *  获取个人信息
 */
#define GETINFO @"/account/servicer/getinfo"


/*    上班（判断是否通过实名和资格）   */
#define WORKON @"/account/servicer/startwork"

/*   下班   */
#define WORKOFF @"/account/servicer/endwork"

/**
 *  退出
 */
#define DROPOUT @"/account/auth/logout"

/*    填写个人资料  */
#define PERSONINFO @"/account/servicer/servicerinfo"

/*   实名认证   */
#define TURENAME @"/event/identification/update"

/*   资格认证   */
#define QUALUFICATION @"/event/qualification/update"

//10


/*   获取金额信息   */
#define ACCOUNT @"/event/bill/list"

/*   获取可接订单列表   */
#define ABLEORDER @"/event/servicerorder/canaccorderlist"

/*   接单    */
#define TAKERORDER @"/event/servicerorder/accpetorder"

/*   进行中订单列表   */
#define ORDERING @"/event/servicerorder/doingorderlist"

/*   订单详情   */
#define ORDERINFO @"/event/servicerorder/orderinfo"

/*   已完成订单列表    */
#define HISTORYORDER @"/event/servicerorder/overorderlist"

//16

//健康档案详情
#define HEALTHINFO @"/event/healthrecord/info"

/*   填写健康档案   */
#define HEALTH @"/event/healthrecord/update"

//17


/*   获取客服电话   */
#define GETCALLNUMBER @"/info/cservicer/getallphone"

/**
 *  获取消息接口
 */
#define MESSAGE @"/event/pushmessage/getlist"
/**
 *  开始服务
 */
#define START @"/event/servicerorder/start"

/**
 *  结束服务
 */
#define STOP @"/event/servicerorder/end"


#define PROTOCOL @"/html/UserAgreement.html"

#endif /* path_h */

//
//  personInfo.h
//  HZFDYDD
//
//  Created by fdkj0002 on 16/1/9.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#ifndef personInfo_h
#define personInfo_h


/**
 *  消息通知的名字
 */
//个人资料（头像及名字）
#define UPLOADPERSONDATA @"UPLOADPERSONDATA"






/**
 *  存放从网上取下来的头像路径 然后用NSUerDefault存放
 *
 */



//进图后台
#define ENTERBACKGROUND @"enterBackground"

//登陆背景显示状态
#define LOGINSTATE @"loginstate"

//用户手机号码
#define PHONE @"phone"
//用户头像路径
#define ICONPATH @"iconpath"
//用户姓名
#define NAME @"userName"
//工作状态
#define WORKSTATE @"WORKSTATE"

#endif /* personInfo_h */

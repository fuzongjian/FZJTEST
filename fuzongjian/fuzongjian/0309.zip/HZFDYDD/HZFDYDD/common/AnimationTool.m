//
//  AnimationTool.m
//  HZFDYDD
//
//  Created by fdkj0002 on 16/3/1.
//  Copyright © 2016年 fdkj0002. All rights reserved.
//

#import "AnimationTool.h"

@implementation AnimationTool
+ (CAKeyframeAnimation *)addAnimateToButton{
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.3;
    animation.removedOnCompletion = YES;
    animation.fillMode = kCAFillModeForwards;
    animation.values = @[[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.7, 0.7, 1.0)],
                       [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)],
                       [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.8, 0.8, 1.0)],
                       [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    return animation;
}
@end

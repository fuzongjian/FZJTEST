//
//  Tool.h
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/14.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool : NSObject
+(UILabel *)setCustomViewTitle:(NSString *)title;

+(void)popLoginTestCodeView:(NSString *)str;

/**
 *  提醒用户
 *
 *  @param message 提示语
 */
+(void)popWarningMessage:(NSString *)message;



+(void)ShowSuccessOrFailPopString:(NSString *)message;



///**
// *  显示及隐藏菊花残
// */
//+(void)showPopBigIndicatorToShowProgress;
//+(void)hidenPopBigIndicatorToShowProgress;


@end

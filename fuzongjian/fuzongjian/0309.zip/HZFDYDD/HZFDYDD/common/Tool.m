//
//  Tool.m
//  HZFDYDD
//
//  Created by fdkj0002 on 15/12/14.
//  Copyright © 2015年 fdkj0002. All rights reserved.
//

#import "Tool.h"

@implementation Tool
+(UILabel *)setCustomViewTitle:(NSString *)title{
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 44)];
    label.text = title;
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor redColor];
    label.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(18)];
    return label;
}
+(void)popLoginTestCodeView:(NSString *)str{
    
    UIView * bigView = [[UIView alloc]initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    bigView.backgroundColor = [UIColor clearColor];
    [[UIApplication sharedApplication].keyWindow addSubview:bigView];
    
    UILabel * pop = [[UILabel alloc]initWithFrame:CGRectMake(10, SCREEN_HEIGHT * 0.5 - 10, SCREEN_WIDTH - 20, 40)];
    pop.text = str;
    pop.textColor = [UIColor grayColor];
    pop.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(14)];
    pop.textAlignment = NSTextAlignmentCenter;
    [bigView addSubview:pop];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [bigView removeFromSuperview];
    });
}

+(void)popWarningMessage:(NSString *)message{
    
    
    
}
+(void)ShowSuccessOrFailPopString:(NSString *)message{
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = RGBCOLOR(108, 108, 108);
    bgView.alpha = 0.8;
    bgView.tag = 1047214;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    
    //弹出提示视图
    UIView * popView = [[UIView alloc]initWithFrame:CGRectMake(FIXWIDTHORHEIGHT(40), SCREEN_HEIGHT * 0.35, SCREEN_WIDTH - FIXWIDTHORHEIGHT(80), SCREEN_HEIGHT * 0.3)];
    popView.backgroundColor = [UIColor whiteColor];
    popView.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    popView.layer.masksToBounds = YES;
    popView.backgroundColor = RGBCOLOR(237, 237, 237);
    [bgView addSubview:popView];
    
    UIImageView * success = [[UIImageView alloc]initWithFrame:CGRectMake(popView.size.width * 0.35, popView.size.height * 0.1, popView.size.width * 0.3, popView.size.width * 0.3)];
    
    success.image = [UIImage imageNamed:@"sucess@2x_47"];
    [popView addSubview:success];
    
    UILabel * lable = [[UILabel alloc]initWithFrame:CGRectMake(0, success.origin.y + success.size.height + FIXWIDTHORHEIGHT(20) , popView.size.width, 20)];
    lable.font = [UIFont systemFontOfSize:FIXWIDTHORHEIGHT(20)];
    lable.textColor = RGBCOLOR(105, 105, 105);
    lable.text = message;
    lable.textAlignment = NSTextAlignmentCenter;
    [popView addSubview:lable];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [bgView removeFromSuperview];
    });
    
}
#pragma mark--  菊花残
+(void)showPopBigIndicatorToShowProgress{
    
    //背景灰色透明遮盖
    UIView * bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bgView.backgroundColor = [UIColor clearColor];
    bgView.alpha = 0.9;
    bgView.tag = 14504823;
    [[UIApplication sharedApplication].keyWindow addSubview:bgView];
    //菊花
    UIView * midle = [[UIView alloc]init];
    midle.size = CGSizeMake(60, 60);
    midle.center = [UIApplication sharedApplication].keyWindow.center;
    midle.layer.cornerRadius = FIXWIDTHORHEIGHT(5);
    midle.layer.masksToBounds = YES;
    midle.backgroundColor = RGBCOLOR(108, 108, 108);
    [bgView addSubview:midle];
    UIActivityIndicatorView * activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activity.frame = CGRectMake(10, 10, 40, 40);
    
    [midle addSubview:activity];
    [activity startAnimating];
}
+(void)hidenPopBigIndicatorToShowProgress{
    
    for (UIView * view in [UIApplication sharedApplication].keyWindow.subviews) {
        if (view.tag == 14504823) {
            [view removeFromSuperview];
        }
    }
}


@end
